sequenceDiagram
participant Caller
participant AbstractFacade
participant javax.persistence.criteria.CriteriaQuery

Caller->>AbstractFacade: count() : int
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq = getEntityManager().getCriteriaBuilder().createQuery() : javax.persistence.criteria.CriteriaQuery
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq
deactivate AbstractFacade
AbstractFacade->>javax.persistence.criteria.CriteriaQuery: rt = cq.from(entityClass) : javax.persistence.criteria.Root<T>
activate javax.persistence.criteria.CriteriaQuery
javax.persistence.criteria.CriteriaQuery->>AbstractFacade: rt
deactivate javax.persistence.criteria.CriteriaQuery
AbstractFacade->>javax.persistence.criteria.CriteriaQuery: cq.select(getEntityManager().getCriteriaBuilder().count(rt)) : void
activate javax.persistence.criteria.CriteriaQuery
deactivate javax.persistence.criteria.CriteriaQuery
AbstractFacade->>AbstractFacade: q = getEntityManager().createQuery(cq) : javax.persistence.Query
activate AbstractFacade
AbstractFacade->>AbstractFacade: q
deactivate AbstractFacade
AbstractFacade->>Caller: return ((Long) q.getSingleResult()).intValue();
deactivate AbstractFacade
