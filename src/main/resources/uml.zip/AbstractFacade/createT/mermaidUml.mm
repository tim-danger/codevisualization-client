sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: create(entity) : void
activate AbstractFacade
AbstractFacade->>AbstractFacade: getEntityManager().persist(entity) : void
activate AbstractFacade
deactivate AbstractFacade
deactivate AbstractFacade
