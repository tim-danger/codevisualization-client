sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: edit(entity) : void
activate AbstractFacade
AbstractFacade->>AbstractFacade: getEntityManager().merge(entity) : void
activate AbstractFacade
deactivate AbstractFacade
deactivate AbstractFacade
