sequenceDiagram
participant Caller
participant AbstractFacade
participant javax.persistence.criteria.CriteriaQuery

Caller->>AbstractFacade: findAll() : List<T>
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq = getEntityManager().getCriteriaBuilder().createQuery() : javax.persistence.criteria.CriteriaQuery
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq
deactivate AbstractFacade
AbstractFacade->>javax.persistence.criteria.CriteriaQuery: cq.select(cq.from(entityClass)) : void
activate javax.persistence.criteria.CriteriaQuery
deactivate javax.persistence.criteria.CriteriaQuery
AbstractFacade->>Caller: return getEntityManager().createQuery(cq).getResultList();
deactivate AbstractFacade
