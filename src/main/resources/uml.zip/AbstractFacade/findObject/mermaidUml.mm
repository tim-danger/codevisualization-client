sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: find(id) : T
activate AbstractFacade
AbstractFacade->>Caller: return getEntityManager().find(entityClass, id);
deactivate AbstractFacade
