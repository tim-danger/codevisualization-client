sequenceDiagram
participant Caller
participant AbstractFacade
participant javax.persistence.criteria.CriteriaQuery
participant javax.persistence.Query

Caller->>AbstractFacade: findRange(range) : List<T>
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq = getEntityManager().getCriteriaBuilder().createQuery() : javax.persistence.criteria.CriteriaQuery
activate AbstractFacade
AbstractFacade->>AbstractFacade: cq
deactivate AbstractFacade
AbstractFacade->>javax.persistence.criteria.CriteriaQuery: cq.select(cq.from(entityClass)) : void
activate javax.persistence.criteria.CriteriaQuery
deactivate javax.persistence.criteria.CriteriaQuery
AbstractFacade->>AbstractFacade: q = getEntityManager().createQuery(cq) : javax.persistence.Query
activate AbstractFacade
AbstractFacade->>AbstractFacade: q
deactivate AbstractFacade
AbstractFacade->>javax.persistence.Query: q.setMaxResults(range[1] - range[0]) : void
activate javax.persistence.Query
deactivate javax.persistence.Query
AbstractFacade->>javax.persistence.Query: q.setFirstResult(range[0]) : void
activate javax.persistence.Query
deactivate javax.persistence.Query
AbstractFacade->>Caller: return q.getResultList();
deactivate AbstractFacade
