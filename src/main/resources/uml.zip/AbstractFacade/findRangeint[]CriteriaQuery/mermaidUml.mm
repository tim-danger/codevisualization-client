sequenceDiagram
participant Caller
participant AbstractFacade
participant javax.persistence.Query

Caller->>AbstractFacade: findRange(range, query) : List<T>
activate AbstractFacade
AbstractFacade->>AbstractFacade: q = getEntityManager().createQuery(query) : javax.persistence.Query
activate AbstractFacade
AbstractFacade->>AbstractFacade: q
deactivate AbstractFacade
AbstractFacade->>javax.persistence.Query: q.setMaxResults(range[1] - range[0]) : void
activate javax.persistence.Query
deactivate javax.persistence.Query
AbstractFacade->>javax.persistence.Query: q.setFirstResult(range[0]) : void
activate javax.persistence.Query
deactivate javax.persistence.Query
AbstractFacade->>Caller: return q.getResultList();
deactivate AbstractFacade
