sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: getCriteriaBuilder() : CriteriaBuilder
activate AbstractFacade
AbstractFacade->>Caller: return getEntityManager().getCriteriaBuilder();
deactivate AbstractFacade
