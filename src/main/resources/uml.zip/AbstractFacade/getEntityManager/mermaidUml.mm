sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: getEntityManager() : EntityManager
activate AbstractFacade
deactivate AbstractFacade
