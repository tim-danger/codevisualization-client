sequenceDiagram
participant Caller
participant AbstractFacade

Caller->>AbstractFacade: remove(entity) : void
activate AbstractFacade
AbstractFacade->>AbstractFacade: getEntityManager().remove(getEntityManager().merge(entity)) : void
activate AbstractFacade
deactivate AbstractFacade
deactivate AbstractFacade
