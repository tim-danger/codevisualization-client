sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: createPageDataModel() : DataModel
activate AbstractPaginationHelper
deactivate AbstractPaginationHelper
