sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: getItemsCount() : int
activate AbstractPaginationHelper
deactivate AbstractPaginationHelper
