sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: getPageFirstItem() : int
activate AbstractPaginationHelper
AbstractPaginationHelper->>Caller: return page * pageSize;
deactivate AbstractPaginationHelper
