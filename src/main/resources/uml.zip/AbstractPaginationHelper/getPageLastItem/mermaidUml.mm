sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: getPageLastItem() : int
activate AbstractPaginationHelper
AbstractPaginationHelper->>AbstractPaginationHelper: int i = getPageFirstItem() + pageSize - 1
AbstractPaginationHelper->>AbstractPaginationHelper: int count = getItemsCount() - 1
alt i > count
AbstractPaginationHelper->>AbstractPaginationHelper: i = count
end
alt i < 0
AbstractPaginationHelper->>AbstractPaginationHelper: i = 0
end
AbstractPaginationHelper->>Caller: return i;
deactivate AbstractPaginationHelper
