sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: getPageSize() : int
activate AbstractPaginationHelper
AbstractPaginationHelper->>Caller: return pageSize;
deactivate AbstractPaginationHelper
