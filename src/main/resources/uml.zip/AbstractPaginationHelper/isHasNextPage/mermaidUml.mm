sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: isHasNextPage() : boolean
activate AbstractPaginationHelper
AbstractPaginationHelper->>Caller: return (page + 1) * pageSize + 1 <= getItemsCount();
deactivate AbstractPaginationHelper
