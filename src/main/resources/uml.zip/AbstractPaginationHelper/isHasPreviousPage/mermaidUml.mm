sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: isHasPreviousPage() : boolean
activate AbstractPaginationHelper
AbstractPaginationHelper->>Caller: return page > 0;
deactivate AbstractPaginationHelper
