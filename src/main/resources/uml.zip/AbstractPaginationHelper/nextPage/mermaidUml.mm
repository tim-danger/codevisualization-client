sequenceDiagram
participant Caller
participant AbstractPaginationHelper

Caller->>AbstractPaginationHelper: nextPage() : void
activate AbstractPaginationHelper
alt isHasNextPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page++
end
deactivate AbstractPaginationHelper
