sequenceDiagram
participant Caller
participant Address

Caller->>Address: equals(object) : boolean
activate Address
alt !(object instanceof Address)
Address->>Caller: return false;
end
Address->>Address: Address other = (Address) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Address->>Caller: return false;
end
Address->>Caller: return true;
deactivate Address
