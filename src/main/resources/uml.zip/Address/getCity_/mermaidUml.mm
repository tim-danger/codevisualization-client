sequenceDiagram
participant Caller
participant Address

Caller->>Address: getCity() : String
activate Address
Address->>Caller: return city;
deactivate Address
