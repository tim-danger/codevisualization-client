sequenceDiagram
participant Caller
participant Address

Caller->>Address: getCountry() : String
activate Address
Address->>Caller: return country;
deactivate Address
