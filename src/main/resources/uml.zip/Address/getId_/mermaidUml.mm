sequenceDiagram
participant Caller
participant Address

Caller->>Address: getId() : Long
activate Address
Address->>Caller: return id;
deactivate Address
