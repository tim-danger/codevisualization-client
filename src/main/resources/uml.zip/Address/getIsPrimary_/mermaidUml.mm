sequenceDiagram
participant Caller
participant Address

Caller->>Address: getIsPrimary() : boolean
activate Address
Address->>Caller: return isPrimary;
deactivate Address
