sequenceDiagram
participant Caller
participant Address

Caller->>Address: getPerson() : Person
activate Address
Address->>Caller: return person;
deactivate Address
