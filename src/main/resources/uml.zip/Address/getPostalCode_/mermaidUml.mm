sequenceDiagram
participant Caller
participant Address

Caller->>Address: getPostalCode() : String
activate Address
Address->>Caller: return postalCode;
deactivate Address
