sequenceDiagram
participant Caller
participant Address

Caller->>Address: getProvince() : String
activate Address
Address->>Caller: return province;
deactivate Address
