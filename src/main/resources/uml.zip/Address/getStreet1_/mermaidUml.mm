sequenceDiagram
participant Caller
participant Address

Caller->>Address: getStreet1() : String
activate Address
Address->>Caller: return street1;
deactivate Address
