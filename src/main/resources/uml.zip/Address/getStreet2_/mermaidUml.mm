sequenceDiagram
participant Caller
participant Address

Caller->>Address: getStreet2() : String
activate Address
Address->>Caller: return street2;
deactivate Address
