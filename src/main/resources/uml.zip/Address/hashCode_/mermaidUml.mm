sequenceDiagram
participant Caller
participant Address

Caller->>Address: hashCode() : int
activate Address
Address->>Address: int hash = 0
Address->>Address: hash += (id != null ? id.hashCode() : 0)
Address->>Caller: return hash;
deactivate Address
