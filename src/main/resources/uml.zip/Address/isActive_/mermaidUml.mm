sequenceDiagram
participant Caller
participant Address

Caller->>Address: isActive() : boolean
activate Address
Address->>Caller: return active;
deactivate Address
