sequenceDiagram
participant Caller
participant Address

Caller->>Address: setActive(active) : void
activate Address
Address->>Address: this.active = active
deactivate Address
