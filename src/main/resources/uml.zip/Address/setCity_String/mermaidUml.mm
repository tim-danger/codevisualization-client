sequenceDiagram
participant Caller
participant Address

Caller->>Address: setCity(city) : void
activate Address
Address->>Address: this.city = city
deactivate Address
