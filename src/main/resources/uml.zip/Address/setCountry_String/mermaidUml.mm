sequenceDiagram
participant Caller
participant Address

Caller->>Address: setCountry(country) : void
activate Address
Address->>Address: this.country = country
deactivate Address
