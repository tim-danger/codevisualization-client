sequenceDiagram
participant Caller
participant Address

Caller->>Address: setId(id) : void
activate Address
Address->>Address: this.id = id
deactivate Address
