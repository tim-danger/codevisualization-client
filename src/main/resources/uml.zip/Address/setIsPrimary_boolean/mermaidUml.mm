sequenceDiagram
participant Caller
participant Address

Caller->>Address: setIsPrimary(isPrimary) : void
activate Address
Address->>Address: this.isPrimary = isPrimary
deactivate Address
