sequenceDiagram
participant Caller
participant Address

Caller->>Address: setPerson(person) : void
activate Address
Address->>Address: this.person = person
deactivate Address
