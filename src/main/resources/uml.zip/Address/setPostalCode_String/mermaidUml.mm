sequenceDiagram
participant Caller
participant Address

Caller->>Address: setPostalCode(postalCode) : void
activate Address
Address->>Address: this.postalCode = postalCode
deactivate Address
