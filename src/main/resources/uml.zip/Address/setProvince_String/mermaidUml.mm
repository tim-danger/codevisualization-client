sequenceDiagram
participant Caller
participant Address

Caller->>Address: setProvince(province) : void
activate Address
Address->>Address: this.province = province
deactivate Address
