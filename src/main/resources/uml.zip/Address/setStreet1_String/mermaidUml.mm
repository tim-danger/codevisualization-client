sequenceDiagram
participant Caller
participant Address

Caller->>Address: setStreet1(street1) : void
activate Address
Address->>Address: this.street1 = street1
deactivate Address
