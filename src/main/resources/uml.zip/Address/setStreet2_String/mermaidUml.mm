sequenceDiagram
participant Caller
participant Address

Caller->>Address: setStreet2(street2) : void
activate Address
Address->>Address: this.street2 = street2
deactivate Address
