sequenceDiagram
participant Caller
participant Address

Caller->>Address: toString() : String
activate Address
Address->>Caller: return "dukestutoring.entity.Address[id=" + id + "]";
deactivate Address
