sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getAddress() : Address
activate AddressBean
AddressBean->>Caller: return address;
deactivate AddressBean
