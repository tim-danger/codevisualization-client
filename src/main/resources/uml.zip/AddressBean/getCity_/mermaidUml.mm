sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getCity() : String
activate AddressBean
AddressBean->>Caller: return city;
deactivate AddressBean
