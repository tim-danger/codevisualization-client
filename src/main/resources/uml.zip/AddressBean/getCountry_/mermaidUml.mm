sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getCountry() : String
activate AddressBean
AddressBean->>Caller: return country;
deactivate AddressBean
