sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getIsPrimary() : boolean
activate AddressBean
AddressBean->>Caller: return isPrimary;
deactivate AddressBean
