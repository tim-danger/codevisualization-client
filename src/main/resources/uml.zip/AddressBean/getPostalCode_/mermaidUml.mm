sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getPostalCode() : String
activate AddressBean
AddressBean->>Caller: return postalCode;
deactivate AddressBean
