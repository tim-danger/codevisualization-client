sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getProvince() : String
activate AddressBean
AddressBean->>Caller: return province;
deactivate AddressBean
