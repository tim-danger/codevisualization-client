sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getStreet1() : String
activate AddressBean
AddressBean->>Caller: return street1;
deactivate AddressBean
