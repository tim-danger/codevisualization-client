sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: getStreet2() : String
activate AddressBean
AddressBean->>Caller: return street2;
deactivate AddressBean
