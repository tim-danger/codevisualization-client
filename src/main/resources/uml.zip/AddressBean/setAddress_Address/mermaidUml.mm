sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setAddress(address) : void
activate AddressBean
AddressBean->>AddressBean: this.address = address
deactivate AddressBean
