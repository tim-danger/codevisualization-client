sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setCity(city) : void
activate AddressBean
AddressBean->>AddressBean: this.city = city
deactivate AddressBean
