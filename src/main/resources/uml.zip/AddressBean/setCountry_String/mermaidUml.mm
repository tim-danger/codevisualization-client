sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setCountry(country) : void
activate AddressBean
AddressBean->>AddressBean: this.country = country
deactivate AddressBean
