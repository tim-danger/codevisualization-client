sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setIsPrimary(isPrimary) : void
activate AddressBean
AddressBean->>AddressBean: this.isPrimary = isPrimary
deactivate AddressBean
