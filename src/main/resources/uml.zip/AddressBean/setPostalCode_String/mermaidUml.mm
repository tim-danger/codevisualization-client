sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setPostalCode(postalCode) : void
activate AddressBean
AddressBean->>AddressBean: this.postalCode = postalCode
deactivate AddressBean
