sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setProvince(province) : void
activate AddressBean
AddressBean->>AddressBean: this.province = province
deactivate AddressBean
