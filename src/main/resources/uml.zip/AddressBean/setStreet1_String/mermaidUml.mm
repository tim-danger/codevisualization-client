sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setStreet1(street1) : void
activate AddressBean
AddressBean->>AddressBean: this.street1 = street1
deactivate AddressBean
