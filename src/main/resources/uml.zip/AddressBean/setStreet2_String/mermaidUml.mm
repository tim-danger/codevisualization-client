sequenceDiagram
participant Caller
participant AddressBean

Caller->>AddressBean: setStreet2(street2) : void
activate AddressBean
AddressBean->>AddressBean: this.street2 = street2
deactivate AddressBean
