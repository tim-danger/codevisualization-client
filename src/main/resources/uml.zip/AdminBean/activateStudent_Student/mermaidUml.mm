sequenceDiagram
participant Caller
participant AdminBean
participant Student
participant EntityManager

Caller->>AdminBean: activateStudent(student) : String
activate AdminBean
AdminBean->>Student: student.setActive(true) : void
activate Student
Student->>Student: this.active = active
deactivate Student
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "activatedStudent";
deactivate AdminBean
