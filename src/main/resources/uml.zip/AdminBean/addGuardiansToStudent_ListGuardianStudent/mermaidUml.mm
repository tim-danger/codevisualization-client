sequenceDiagram
participant Caller
participant AdminBean
participant Student
participant Guardian
participant EntityManager

Caller->>AdminBean: addGuardiansToStudent(guardians, student) : String
activate AdminBean
loop for Guardian g : guardians
AdminBean->>Student: student.getGuardians().add(g) : void
activate Student
deactivate Student
AdminBean->>Guardian: g.getStudents().add(student) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(g) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "addedGuardians";
deactivate AdminBean
