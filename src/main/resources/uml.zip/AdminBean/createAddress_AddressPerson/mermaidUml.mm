sequenceDiagram
participant Caller
participant AdminBean
participant Person
participant Address
participant EntityManager

Caller->>AdminBean: createAddress(address, person) : String
activate AdminBean
AdminBean->>Person: person.getAddresses().add(address) : void
activate Person
deactivate Person
AdminBean->>Address: address.setPerson(person) : void
activate Address
Address->>Address: this.person = person
deactivate Address
AdminBean->>EntityManager: em.merge(person) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.persist(address) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "createdAddress";
deactivate AdminBean
