sequenceDiagram
participant Caller
participant AdminBean
participant Address
participant Student
participant EntityManager

Caller->>AdminBean: createAddress(street1, street2, city, province, country, postalCode, isPrimary, student) : Address
activate AdminBean
AdminBean->>Address: address = new Address() : Address
activate Address
Address->>AdminBean: address
deactivate Address
AdminBean->>Address: address.setStreet1(street1) : void
activate Address
Address->>Address: this.street1 = street1
deactivate Address
AdminBean->>Address: address.setStreet2(street2) : void
activate Address
Address->>Address: this.street2 = street2
deactivate Address
AdminBean->>Address: address.setCity(city) : void
activate Address
Address->>Address: this.city = city
deactivate Address
AdminBean->>Address: address.setProvince(province) : void
activate Address
Address->>Address: this.province = province
deactivate Address
AdminBean->>Address: address.setCountry(country) : void
activate Address
Address->>Address: this.country = country
deactivate Address
AdminBean->>Address: address.setPostalCode(postalCode) : void
activate Address
Address->>Address: this.postalCode = postalCode
deactivate Address
AdminBean->>Address: address.setIsPrimary(isPrimary) : void
activate Address
Address->>Address: this.isPrimary = isPrimary
deactivate Address
AdminBean->>Address: address.setStreet1(street1) : void
activate Address
deactivate Address
AdminBean->>Address: address.setStreet1(street1) : void
activate Address
deactivate Address
AdminBean->>Address: address.setPerson(student) : void
activate Address
Address->>Address: this.person = person
deactivate Address
AdminBean->>Student: student.getAddresses().add(address) : void
activate Student
deactivate Student
AdminBean->>Address: address.setPerson(student) : void
activate Address
deactivate Address
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.persist(address) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return address;
deactivate AdminBean
