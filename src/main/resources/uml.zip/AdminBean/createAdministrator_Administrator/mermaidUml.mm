sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: createAdministrator(admin) : String
activate AdminBean
AdminBean->>EntityManager: em.persist(admin) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "createdAdministrator";
deactivate AdminBean
