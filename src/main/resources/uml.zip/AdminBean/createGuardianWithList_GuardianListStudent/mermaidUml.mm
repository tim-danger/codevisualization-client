sequenceDiagram
participant Caller
participant AdminBean
participant Student
participant Guardian
participant EntityManager

Caller->>AdminBean: createGuardianWithList(guardian, students) : String
activate AdminBean
loop for Student s : students
AdminBean->>Student: s.getGuardians().add(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().add(s) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(s) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>EntityManager: em.persist(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "createdGuardian";
deactivate AdminBean
