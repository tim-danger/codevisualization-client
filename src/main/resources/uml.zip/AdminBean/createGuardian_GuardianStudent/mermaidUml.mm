sequenceDiagram
participant Caller
participant AdminBean
participant Logger
participant Student
participant Guardian
participant EntityManager

Caller->>AdminBean: createGuardian(guardian, student) : String
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "Creating guardian {0} for {1}", new Object[] { guardian.getName(), student.getName() }) : void
activate Logger
deactivate Logger
AdminBean->>Student: student.getGuardians().add(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().add(student) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.persist(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "createdGuardian";
deactivate AdminBean
