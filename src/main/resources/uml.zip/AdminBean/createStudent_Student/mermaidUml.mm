sequenceDiagram
participant Caller
participant AdminBean
participant Logger
participant EntityManager

Caller->>AdminBean: createStudent(student) : String
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.createStudent(1 arg): Persisting new student.") : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: em.persist(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "createdStudent";
deactivate AdminBean
