sequenceDiagram
participant Caller
participant AdminBean
participant Logger
participant EntityManager

Caller->>AdminBean: createStudents(students) : void
activate AdminBean
loop for Student s : students
AdminBean->>AdminBean: this.createStudent(s) : void
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.createStudent(1 arg): Persisting new student.") : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: em.persist(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "createdStudent";
deactivate AdminBean
end
deactivate AdminBean
