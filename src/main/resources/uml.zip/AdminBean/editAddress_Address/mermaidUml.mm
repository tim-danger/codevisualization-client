sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: editAddress(address) : String
activate AdminBean
AdminBean->>EntityManager: em.merge(address) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "editedAddress";
deactivate AdminBean
