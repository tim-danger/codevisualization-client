sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: editAddresses(addresses) : String
activate AdminBean
loop for Address a : addresses
AdminBean->>AdminBean: this.editAddress(a) : void
activate AdminBean
AdminBean->>EntityManager: em.merge(address) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "editedAddress";
deactivate AdminBean
end
AdminBean->>Caller: return "editedAddresses";
deactivate AdminBean
