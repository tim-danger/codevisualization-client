sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: editGuardian(guardian) : String
activate AdminBean
AdminBean->>EntityManager: em.merge(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "editedGuardian";
deactivate AdminBean
