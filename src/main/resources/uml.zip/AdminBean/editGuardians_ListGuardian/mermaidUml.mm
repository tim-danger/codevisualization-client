sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: editGuardians(guardians) : String
activate AdminBean
loop for Guardian g : guardians
AdminBean->>AdminBean: this.editGuardian(g) : void
activate AdminBean
AdminBean->>EntityManager: em.merge(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "editedGuardian";
deactivate AdminBean
end
AdminBean->>Caller: return "editedGuardians";
deactivate AdminBean
