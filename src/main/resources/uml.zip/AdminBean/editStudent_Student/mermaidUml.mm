sequenceDiagram
participant Caller
participant AdminBean
participant Logger
participant EntityManager

Caller->>AdminBean: editStudent(student) : String
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.editStudent: Editing student.") : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "editedStudent";
deactivate AdminBean
