sequenceDiagram
participant Caller
participant AdminBean
participant Logger
participant EntityManager

Caller->>AdminBean: editStudents(students) : String
activate AdminBean
loop for Student s : students
AdminBean->>AdminBean: this.editStudent(s) : void
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.editStudent: Editing student.") : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "editedStudent";
deactivate AdminBean
end
AdminBean->>Caller: return "editedStudents";
deactivate AdminBean
