sequenceDiagram
participant Caller
participant AdminBean
participant Logger

Caller->>AdminBean: findGuardianById(id) : Guardian
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "Finding Guardian with ID: {0}", id) : void
activate Logger
deactivate Logger
AdminBean->>Caller: return (Guardian) em.find(Guardian.class, id);
deactivate AdminBean
