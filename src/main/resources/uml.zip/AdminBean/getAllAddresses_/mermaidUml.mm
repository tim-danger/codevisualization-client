sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager
participant CriteriaQuery

Caller->>AdminBean: getAllAddresses() : List<Address>
activate AdminBean
AdminBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Address.class) : CriteriaQuery<Address>
activate EntityManager
EntityManager->>AdminBean: cq
deactivate EntityManager
AdminBean->>CriteriaQuery: address = cq.from(Address.class) : Root<Address>
activate CriteriaQuery
CriteriaQuery->>AdminBean: address
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.select(address) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.where(cb.isTrue(address.get(Address_.active))) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Address>
activate EntityManager
EntityManager->>AdminBean: q
deactivate EntityManager
AdminBean->>Caller: return q.getResultList();
deactivate AdminBean
