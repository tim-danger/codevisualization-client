sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager
participant CriteriaQuery

Caller->>AdminBean: getAllGuardians() : List<Guardian>
activate AdminBean
AdminBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Guardian.class) : CriteriaQuery<Guardian>
activate EntityManager
EntityManager->>AdminBean: cq
deactivate EntityManager
AdminBean->>CriteriaQuery: guardian = cq.from(Guardian.class) : Root<Guardian>
activate CriteriaQuery
CriteriaQuery->>AdminBean: guardian
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.select(guardian) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Guardian>
activate EntityManager
EntityManager->>AdminBean: q
deactivate EntityManager
AdminBean->>Caller: return q.getResultList();
deactivate AdminBean
