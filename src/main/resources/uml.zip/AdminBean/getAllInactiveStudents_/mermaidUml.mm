sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager
participant CriteriaQuery

Caller->>AdminBean: getAllInactiveStudents() : List<Student>
activate AdminBean
AdminBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Student.class) : CriteriaQuery<Student>
activate EntityManager
EntityManager->>AdminBean: cq
deactivate EntityManager
AdminBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>AdminBean: student
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.where(cb.isFalse(student.get(Student_.active))) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>AdminBean: q
deactivate EntityManager
AdminBean->>Caller: return q.getResultList();
deactivate AdminBean
