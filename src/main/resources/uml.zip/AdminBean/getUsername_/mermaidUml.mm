sequenceDiagram
participant Caller
participant AdminBean

Caller->>AdminBean: getUsername() : String
activate AdminBean
AdminBean->>Caller: return FacesContext.getCurrentInstance().getExternalContext().getUserPrincipal().getName();
deactivate AdminBean
