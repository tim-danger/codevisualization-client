sequenceDiagram
participant Caller
participant AdminBean
participant EntityManager

Caller->>AdminBean: init() : void
activate AdminBean
AdminBean->>EntityManager: cb = em.getCriteriaBuilder() : CriteriaBuilder
activate EntityManager
EntityManager->>AdminBean: cb
deactivate EntityManager
deactivate AdminBean
