sequenceDiagram
participant Caller
participant AdminBean

Caller->>AdminBean: isLoggedIn() : boolean
activate AdminBean
AdminBean->>Caller: return FacesContext.getCurrentInstance().getExternalContext().isUserInRole("Administrator");
deactivate AdminBean
