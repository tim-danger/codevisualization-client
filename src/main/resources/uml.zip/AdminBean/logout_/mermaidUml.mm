sequenceDiagram
participant Caller
participant AdminBean
participant FacesContext
participant ExternalContext

Caller->>AdminBean: logout() : String
activate AdminBean
AdminBean->>FacesContext: ec = FacesContext.getCurrentInstance().getExternalContext() : ExternalContext
activate FacesContext
FacesContext->>AdminBean: ec
deactivate FacesContext
AdminBean->>ExternalContext: ec.invalidateSession() : void
activate ExternalContext
deactivate ExternalContext
AdminBean->>Caller: return "../index.xhtml?faces-redirect=true";
deactivate AdminBean
