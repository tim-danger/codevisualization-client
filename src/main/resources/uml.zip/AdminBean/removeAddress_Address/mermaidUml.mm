sequenceDiagram
participant Caller
participant AdminBean
participant Address
participant Person
participant EntityManager

Caller->>AdminBean: removeAddress(address) : String
activate AdminBean
AdminBean->>Address: address.setActive(false) : void
activate Address
Address->>Address: this.active = active
deactivate Address
AdminBean->>Address: person = address.getPerson() : Person
activate Address
Address->>Address: return person;
Address->>AdminBean: person
deactivate Address
AdminBean->>Person: person.getAddresses().remove(address) : void
activate Person
deactivate Person
AdminBean->>EntityManager: em.merge(person) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.merge(address) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "removedAddress";
deactivate AdminBean
