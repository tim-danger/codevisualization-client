sequenceDiagram
participant Caller
participant AdminBean
participant Student
participant Guardian
participant EntityManager

Caller->>AdminBean: removeGuardianFromStudent(guardian, student) : String
activate AdminBean
alt guardian != null && student != null
AdminBean->>Student: student.getGuardians().remove(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().remove(student) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>Caller: return "editedGuardian";
deactivate AdminBean
