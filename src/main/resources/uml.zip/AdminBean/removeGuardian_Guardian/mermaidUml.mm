sequenceDiagram
participant Caller
participant AdminBean
participant Guardian
participant Student
participant EntityManager

Caller->>AdminBean: removeGuardian(guardian) : String
activate AdminBean
AdminBean->>Guardian: guardian.setActive(false) : void
activate Guardian
Guardian->>Guardian: this.active = active
deactivate Guardian
AdminBean->>Guardian: students = guardian.getStudents() : List<Student>
activate Guardian
Guardian->>Guardian: return students;
Guardian->>AdminBean: students
deactivate Guardian
loop for Student s : students
AdminBean->>Student: s.getGuardians().remove(guardian) : void
activate Student
deactivate Student
AdminBean->>EntityManager: em.merge(s) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>EntityManager: em.merge(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>Caller: return "removedGuardian";
deactivate AdminBean
