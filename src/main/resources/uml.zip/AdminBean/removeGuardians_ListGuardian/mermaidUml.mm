sequenceDiagram
participant Caller
participant AdminBean
participant Guardian
participant Student
participant EntityManager

Caller->>AdminBean: removeGuardians(guardians) : String
activate AdminBean
loop for Guardian g : guardians
AdminBean->>AdminBean: this.removeGuardian(g) : void
activate AdminBean
AdminBean->>Guardian: guardian.setActive(false) : void
activate Guardian
Guardian->>Guardian: this.active = active
deactivate Guardian
AdminBean->>Guardian: students = guardian.getStudents() : List<Student>
activate Guardian
Guardian->>Guardian: return students;
Guardian->>AdminBean: students
deactivate Guardian
loop for Student s : students
AdminBean->>Student: s.getGuardians().remove(guardian) : void
activate Student
deactivate Student
AdminBean->>EntityManager: em.merge(s) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>EntityManager: em.merge(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "removedGuardian";
deactivate AdminBean
end
AdminBean->>Caller: return "removedGuardians";
deactivate AdminBean
