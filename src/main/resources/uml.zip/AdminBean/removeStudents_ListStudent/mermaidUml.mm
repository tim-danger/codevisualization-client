sequenceDiagram
participant Caller
participant AdminBean
participant Student
participant EntityManager

Caller->>AdminBean: removeStudents(students) : String
activate AdminBean
loop for Student s : students
AdminBean->>AdminBean: this.removeStudent(s) : void
activate AdminBean
AdminBean->>Student: student.setActive(false) : void
activate Student
Student->>Student: this.active = active
deactivate Student
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "removedStudent";
deactivate AdminBean
end
AdminBean->>Caller: return "removedStudents";
deactivate AdminBean
