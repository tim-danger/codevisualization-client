sequenceDiagram
participant Caller
participant AdminBean

Caller->>AdminBean: setUsername(username) : void
activate AdminBean
AdminBean->>AdminBean: this.username = username
deactivate AdminBean
