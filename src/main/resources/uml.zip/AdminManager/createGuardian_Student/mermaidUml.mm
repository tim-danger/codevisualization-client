sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: createGuardian(student) : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentStudent(student) : void
activate AdminManager
AdminManager->>AdminManager: this.currentStudent = currentStudent
deactivate AdminManager
AdminManager->>AdminManager: this.setCurrentGuardian(null) : void
activate AdminManager
AdminManager->>AdminManager: this.currentGuardian = currentGuardian
deactivate AdminManager
AdminManager->>Caller: return "createGuardian";
deactivate AdminManager
