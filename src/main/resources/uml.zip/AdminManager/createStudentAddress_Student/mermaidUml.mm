sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: createStudentAddress(student) : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentStudent(student) : void
activate AdminManager
AdminManager->>AdminManager: this.currentStudent = currentStudent
deactivate AdminManager
AdminManager->>Caller: return "createAddress";
deactivate AdminManager
