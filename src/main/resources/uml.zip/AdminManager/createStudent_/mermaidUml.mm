sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: createStudent() : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentStudent(null) : void
activate AdminManager
AdminManager->>AdminManager: this.currentStudent = currentStudent
deactivate AdminManager
AdminManager->>Caller: return "createStudent";
deactivate AdminManager
