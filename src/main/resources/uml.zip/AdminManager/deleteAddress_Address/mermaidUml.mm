sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: deleteAddress(address) : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentAddress(address) : void
activate AdminManager
AdminManager->>AdminManager: this.currentAddress = currentAddress
deactivate AdminManager
AdminManager->>Caller: return "deleteAddress";
deactivate AdminManager
