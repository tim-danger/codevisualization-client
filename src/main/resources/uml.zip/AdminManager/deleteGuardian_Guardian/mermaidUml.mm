sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: deleteGuardian(guardian) : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentGuardian(guardian) : void
activate AdminManager
AdminManager->>AdminManager: this.currentGuardian = currentGuardian
deactivate AdminManager
AdminManager->>Caller: return "deleteGuardian";
deactivate AdminManager
