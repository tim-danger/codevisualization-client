sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: editAddress(address) : String
activate AdminManager
AdminManager->>AdminManager: this.setCurrentAddress(address) : void
activate AdminManager
AdminManager->>AdminManager: this.currentAddress = currentAddress
deactivate AdminManager
AdminManager->>Caller: return "editAddress";
deactivate AdminManager
