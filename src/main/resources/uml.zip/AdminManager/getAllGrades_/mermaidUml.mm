sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: getAllGrades() : Map<String,Integer>
activate AdminManager
AdminManager->>Caller: return allGrades;
deactivate AdminManager
