sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: getCurrentAddress() : Address
activate AdminManager
AdminManager->>Caller: return currentAddress;
deactivate AdminManager
