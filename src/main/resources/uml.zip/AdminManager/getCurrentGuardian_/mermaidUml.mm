sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: getCurrentGuardian() : Guardian
activate AdminManager
AdminManager->>Caller: return currentGuardian;
deactivate AdminManager
