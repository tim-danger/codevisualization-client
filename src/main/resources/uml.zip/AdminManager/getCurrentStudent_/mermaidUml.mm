sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: getCurrentStudent() : Student
activate AdminManager
AdminManager->>Caller: return currentStudent;
deactivate AdminManager
