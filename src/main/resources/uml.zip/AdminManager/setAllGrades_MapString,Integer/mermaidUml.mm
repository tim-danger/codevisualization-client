sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: setAllGrades(allGrades) : void
activate AdminManager
AdminManager->>AdminManager: this.allGrades = allGrades
deactivate AdminManager
