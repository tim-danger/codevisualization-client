sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: setCurrentAddress(currentAddress) : void
activate AdminManager
AdminManager->>AdminManager: this.currentAddress = currentAddress
deactivate AdminManager
