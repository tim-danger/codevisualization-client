sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: setCurrentGuardian(currentGuardian) : void
activate AdminManager
AdminManager->>AdminManager: this.currentGuardian = currentGuardian
deactivate AdminManager
