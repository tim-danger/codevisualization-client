sequenceDiagram
participant Caller
participant AdminManager
participant AdminBean
participant Logger
participant EntityManager
participant CriteriaQuery

Caller->>AdminManager: setCurrentStudentById(id) : void
activate AdminManager
AdminManager->>AdminBean: this.currentStudent = adminBean.findStudentById(id)
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "Finding student with ID: {0}", id) : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Student.class) : CriteriaQuery<Student>
activate EntityManager
EntityManager->>AdminBean: cq
deactivate EntityManager
AdminBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>AdminBean: student
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.where(cb.isTrue(student.get(Student_.active))) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.where(cb.equal(student.get(Student_.id), id)) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>AdminBean: q
deactivate EntityManager
AdminBean->>AdminBean: return q.getSingleResult();
AdminBean->>AdminManager: this.currentStudent
deactivate AdminBean
deactivate AdminManager
