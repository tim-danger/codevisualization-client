sequenceDiagram
participant Caller
participant AdminManager

Caller->>AdminManager: setCurrentStudent(currentStudent) : void
activate AdminManager
AdminManager->>AdminManager: this.currentStudent = currentStudent
deactivate AdminManager
