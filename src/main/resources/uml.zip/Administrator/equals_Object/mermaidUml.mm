sequenceDiagram
participant Caller
participant Administrator

Caller->>Administrator: equals(object) : boolean
activate Administrator
alt !(object instanceof Administrator)
Administrator->>Caller: return false;
end
Administrator->>Administrator: Administrator other = (Administrator) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Administrator->>Caller: return false;
end
Administrator->>Caller: return true;
deactivate Administrator
