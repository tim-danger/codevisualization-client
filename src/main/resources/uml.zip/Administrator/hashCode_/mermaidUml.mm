sequenceDiagram
participant Caller
participant Administrator

Caller->>Administrator: hashCode() : int
activate Administrator
Administrator->>Administrator: int hash = 0
Administrator->>Administrator: hash += (id != null ? id.hashCode() : 0)
Administrator->>Caller: return hash;
deactivate Administrator
