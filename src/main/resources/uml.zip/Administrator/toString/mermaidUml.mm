sequenceDiagram
participant Caller
participant Administrator

Caller->>Administrator: toString() : String
activate Administrator
Administrator->>Caller: return "com.forest.entity.Administrator[ id=" + id + " ]";
deactivate Administrator
