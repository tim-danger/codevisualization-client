sequenceDiagram
participant Caller
participant AdministratorBean
participant Administrator
participant Groups
participant EntityManager

Caller->>AdministratorBean: create(admin) : void
activate AdministratorBean
AdministratorBean->>AdministratorBean: Groups adminGroup = (Groups) em.createNamedQuery("Groups.findByName").setParameter("name", "Administrator").getSingleResult()
AdministratorBean->>Administrator: admin.getGroupsList().add(adminGroup) : void
activate Administrator
deactivate Administrator
AdministratorBean->>Groups: adminGroup.getPersonList().add(admin) : void
activate Groups
deactivate Groups
AdministratorBean->>EntityManager: em.persist(admin) : void
activate EntityManager
deactivate EntityManager
AdministratorBean->>EntityManager: em.merge(adminGroup) : void
activate EntityManager
deactivate EntityManager
deactivate AdministratorBean
