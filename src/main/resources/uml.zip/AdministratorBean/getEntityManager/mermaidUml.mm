sequenceDiagram
participant Caller
participant AdministratorBean

Caller->>AdministratorBean: getEntityManager() : EntityManager
activate AdministratorBean
AdministratorBean->>Caller: return em;
deactivate AdministratorBean
