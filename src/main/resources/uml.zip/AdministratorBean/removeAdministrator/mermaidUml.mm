sequenceDiagram
participant Caller
participant AdministratorBean
participant Groups
participant EntityManager

Caller->>AdministratorBean: remove(admin) : void
activate AdministratorBean
AdministratorBean->>AdministratorBean: Groups adminGroup = (Groups) em.createNamedQuery("Groups.findByName").setParameter("name", "Administrator").getSingleResult()
AdministratorBean->>Groups: adminGroup.getPersonList().remove(admin) : void
activate Groups
deactivate Groups
AdministratorBean->>EntityManager: em.remove(em.merge(admin)) : void
activate EntityManager
deactivate EntityManager
AdministratorBean->>EntityManager: em.merge(adminGroup) : void
activate EntityManager
deactivate EntityManager
deactivate AdministratorBean
