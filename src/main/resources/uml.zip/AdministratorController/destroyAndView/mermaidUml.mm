sequenceDiagram
participant Caller
participant AdministratorController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>AdministratorController: destroyAndView() : PageNavigation
activate AdministratorController
AdministratorController->>AdministratorController: performDestroy() : void
activate AdministratorController
opt try
AdministratorController->>AdministratorController: getFacade().remove(current) : void
activate AdministratorController
deactivate AdministratorController
AdministratorController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("AdministratorDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
AdministratorController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate AdministratorController
AdministratorController->>AdministratorController: recreateModel() : void
activate AdministratorController
AdministratorController->>AdministratorController: items = null
deactivate AdministratorController
AdministratorController->>AdministratorController: updateCurrentItem() : void
activate AdministratorController
AdministratorController->>AdministratorController: count = getFacade().count() : int
activate AdministratorController
AdministratorController->>AdministratorController: count
deactivate AdministratorController
alt selectedItemIndex >= count
AdministratorController->>AdministratorController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
AdministratorController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
AdministratorController->>AdministratorController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate AdministratorController
AdministratorController->>AdministratorController: current
deactivate AdministratorController
end
deactivate AdministratorController
alt selectedItemIndex >= 0
AdministratorController->>Caller: return PageNavigation.VIEW;
else
AdministratorController->>AdministratorController: recreateModel() : void
activate AdministratorController
deactivate AdministratorController
AdministratorController->>Caller: return PageNavigation.LIST;
end
deactivate AdministratorController
