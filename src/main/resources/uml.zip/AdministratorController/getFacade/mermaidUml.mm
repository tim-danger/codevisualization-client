sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: getFacade() : AdministratorBean
activate AdministratorController
AdministratorController->>Caller: return ejbFacade;
deactivate AdministratorController
