sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: getItems() : DataModel
activate AdministratorController
alt items == null
AdministratorController->>AdministratorController: items = getPagination().createPageDataModel() : DataModel
activate AdministratorController
AdministratorController->>AdministratorController: items
deactivate AdministratorController
end
AdministratorController->>Caller: return items;
deactivate AdministratorController
