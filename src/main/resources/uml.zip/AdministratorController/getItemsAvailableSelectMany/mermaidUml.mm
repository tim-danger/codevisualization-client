sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: getItemsAvailableSelectMany() : SelectItem[]
activate AdministratorController
AdministratorController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate AdministratorController
