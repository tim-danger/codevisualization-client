sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: getItemsAvailableSelectOne() : SelectItem[]
activate AdministratorController
AdministratorController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate AdministratorController
