sequenceDiagram
participant Caller
participant AdministratorController
participant AbstractPaginationHelper

Caller->>AdministratorController: getPagination() : AbstractPaginationHelper
activate AdministratorController
alt pagination == null
AdministratorController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(10) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>AdministratorController: pagination
deactivate AbstractPaginationHelper
end
AdministratorController->>Caller: return pagination;
deactivate AdministratorController
