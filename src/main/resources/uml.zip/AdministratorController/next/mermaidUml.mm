sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: next() : PageNavigation
activate AdministratorController
AdministratorController->>AdministratorController: getPagination().nextPage() : void
activate AdministratorController
deactivate AdministratorController
AdministratorController->>AdministratorController: recreateModel() : void
activate AdministratorController
AdministratorController->>AdministratorController: items = null
deactivate AdministratorController
AdministratorController->>Caller: return PageNavigation.LIST;
deactivate AdministratorController
