sequenceDiagram
participant Caller
participant AdministratorController
participant Administrator

Caller->>AdministratorController: prepareCreate() : PageNavigation
activate AdministratorController
AdministratorController->>Administrator: current = new Administrator() : Administrator
activate Administrator
Administrator->>AdministratorController: current
deactivate Administrator
AdministratorController->>AdministratorController: selectedItemIndex = -1
AdministratorController->>Caller: return PageNavigation.CREATE;
deactivate AdministratorController
