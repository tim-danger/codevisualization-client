sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: prepareView() : PageNavigation
activate AdministratorController
AdministratorController->>AdministratorController: current = (Administrator) getItems().getRowData()
AdministratorController->>AdministratorController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
AdministratorController->>Caller: return PageNavigation.VIEW;
deactivate AdministratorController
