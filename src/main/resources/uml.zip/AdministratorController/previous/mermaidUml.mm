sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: previous() : PageNavigation
activate AdministratorController
AdministratorController->>AdministratorController: getPagination().previousPage() : void
activate AdministratorController
deactivate AdministratorController
AdministratorController->>AdministratorController: recreateModel() : void
activate AdministratorController
AdministratorController->>AdministratorController: items = null
deactivate AdministratorController
AdministratorController->>Caller: return PageNavigation.LIST;
deactivate AdministratorController
