sequenceDiagram
participant Caller
participant AdministratorController

Caller->>AdministratorController: recreateModel() : void
activate AdministratorController
AdministratorController->>AdministratorController: items = null
deactivate AdministratorController
