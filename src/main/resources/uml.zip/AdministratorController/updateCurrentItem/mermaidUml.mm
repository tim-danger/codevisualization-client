sequenceDiagram
participant Caller
participant AdministratorController
participant AbstractPaginationHelper

Caller->>AdministratorController: updateCurrentItem() : void
activate AdministratorController
AdministratorController->>AdministratorController: count = getFacade().count() : int
activate AdministratorController
AdministratorController->>AdministratorController: count
deactivate AdministratorController
alt selectedItemIndex >= count
AdministratorController->>AdministratorController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
AdministratorController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
AdministratorController->>AdministratorController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate AdministratorController
AdministratorController->>AdministratorController: current
deactivate AdministratorController
end
deactivate AdministratorController
