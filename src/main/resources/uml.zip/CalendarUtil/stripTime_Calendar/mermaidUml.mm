sequenceDiagram
participant Caller
participant CalendarUtil
participant Calendar

Caller->>CalendarUtil: stripTime(cal) : void
activate CalendarUtil
CalendarUtil->>Calendar: cal.clear(Calendar.AM_PM) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR_OF_DAY) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MINUTE) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.SECOND) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MILLISECOND) : void
activate Calendar
deactivate Calendar
deactivate CalendarUtil
