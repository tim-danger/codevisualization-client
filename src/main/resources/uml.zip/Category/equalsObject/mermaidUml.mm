sequenceDiagram
participant Caller
participant Category

Caller->>Category: equals(object) : boolean
activate Category
alt !(object instanceof Category)
Category->>Caller: return false;
end
Category->>Category: Category other = (Category) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Category->>Caller: return false;
end
Category->>Caller: return true;
deactivate Category
