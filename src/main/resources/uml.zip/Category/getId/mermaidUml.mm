sequenceDiagram
participant Caller
participant Category

Caller->>Category: getId() : Integer
activate Category
Category->>Caller: return id;
deactivate Category
