sequenceDiagram
participant Caller
participant Category

Caller->>Category: getName() : String
activate Category
Category->>Caller: return name;
deactivate Category
