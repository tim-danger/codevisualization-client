sequenceDiagram
participant Caller
participant Category

Caller->>Category: getProductList() : List<Product>
activate Category
Category->>Caller: return productList;
deactivate Category
