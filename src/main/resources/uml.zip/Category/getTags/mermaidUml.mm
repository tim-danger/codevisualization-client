sequenceDiagram
participant Caller
participant Category

Caller->>Category: getTags() : String
activate Category
Category->>Caller: return tags;
deactivate Category
