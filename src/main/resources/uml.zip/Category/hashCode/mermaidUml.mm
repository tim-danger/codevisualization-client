sequenceDiagram
participant Caller
participant Category

Caller->>Category: hashCode() : int
activate Category
Category->>Category: int hash = 0
Category->>Category: hash += (id != null ? id.hashCode() : 0)
Category->>Caller: return hash;
deactivate Category
