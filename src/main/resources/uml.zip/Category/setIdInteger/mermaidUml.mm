sequenceDiagram
participant Caller
participant Category

Caller->>Category: setId(id) : void
activate Category
Category->>Category: this.id = id
deactivate Category
