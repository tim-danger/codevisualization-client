sequenceDiagram
participant Caller
participant Category

Caller->>Category: setName(name) : void
activate Category
Category->>Category: this.name = name
deactivate Category
