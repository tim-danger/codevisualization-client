sequenceDiagram
participant Caller
participant Category

Caller->>Category: setProductList(productList) : void
activate Category
Category->>Category: this.productList = productList
deactivate Category
