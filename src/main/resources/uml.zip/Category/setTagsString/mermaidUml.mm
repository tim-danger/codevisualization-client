sequenceDiagram
participant Caller
participant Category

Caller->>Category: setTags(tags) : void
activate Category
Category->>Category: this.tags = tags
deactivate Category
