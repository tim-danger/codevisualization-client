sequenceDiagram
participant Caller
participant Category

Caller->>Category: toString() : String
activate Category
Category->>Caller: return getName() + " [ID: " + id + "]";
deactivate Category
