sequenceDiagram
participant Caller
participant CategoryBean

Caller->>CategoryBean: getEntityManager() : EntityManager
activate CategoryBean
CategoryBean->>Caller: return em;
deactivate CategoryBean
