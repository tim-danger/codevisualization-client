sequenceDiagram
participant Caller
participant CategoryController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>CategoryController: destroyAndView() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: performDestroy() : void
activate CategoryController
opt try
CategoryController->>CategoryController: getFacade().remove(current) : void
activate CategoryController
deactivate CategoryController
CategoryController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("CategoryDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
CategoryController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate CategoryController
CategoryController->>CategoryController: recreateModel() : void
activate CategoryController
CategoryController->>CategoryController: items = null
deactivate CategoryController
CategoryController->>CategoryController: updateCurrentItem() : void
activate CategoryController
CategoryController->>CategoryController: count = getFacade().count() : int
activate CategoryController
CategoryController->>CategoryController: count
deactivate CategoryController
alt selectedItemIndex >= count
CategoryController->>CategoryController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
CategoryController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
CategoryController->>CategoryController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate CategoryController
CategoryController->>CategoryController: current
deactivate CategoryController
end
deactivate CategoryController
alt selectedItemIndex >= 0
CategoryController->>Caller: return PageNavigation.VIEW;
else
CategoryController->>CategoryController: recreateModel() : void
activate CategoryController
deactivate CategoryController
CategoryController->>Caller: return PageNavigation.LIST;
end
deactivate CategoryController
