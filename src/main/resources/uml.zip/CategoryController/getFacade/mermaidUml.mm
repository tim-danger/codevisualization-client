sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: getFacade() : CategoryBean
activate CategoryController
CategoryController->>Caller: return ejbFacade;
deactivate CategoryController
