sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: getItems() : DataModel
activate CategoryController
alt items == null
CategoryController->>CategoryController: items = getPagination().createPageDataModel() : DataModel
activate CategoryController
CategoryController->>CategoryController: items
deactivate CategoryController
end
CategoryController->>Caller: return items;
deactivate CategoryController
