sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: getItemsAvailableSelectMany() : SelectItem[]
activate CategoryController
CategoryController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate CategoryController
