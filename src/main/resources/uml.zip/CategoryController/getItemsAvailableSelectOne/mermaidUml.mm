sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: getItemsAvailableSelectOne() : SelectItem[]
activate CategoryController
CategoryController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate CategoryController
