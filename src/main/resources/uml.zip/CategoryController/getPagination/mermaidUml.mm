sequenceDiagram
participant Caller
participant CategoryController
participant AbstractPaginationHelper

Caller->>CategoryController: getPagination() : AbstractPaginationHelper
activate CategoryController
alt pagination == null
CategoryController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(AbstractPaginationHelper.DEFAULT_SIZE) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>CategoryController: pagination
deactivate AbstractPaginationHelper
end
CategoryController->>Caller: return pagination;
deactivate CategoryController
