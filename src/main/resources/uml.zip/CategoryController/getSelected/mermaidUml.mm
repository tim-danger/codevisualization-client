sequenceDiagram
participant Caller
participant CategoryController
participant Category

Caller->>CategoryController: getSelected() : Category
activate CategoryController
alt current == null
CategoryController->>Category: current = new Category() : Category
activate Category
Category->>CategoryController: current
deactivate Category
CategoryController->>CategoryController: selectedItemIndex = -1
end
CategoryController->>Caller: return current;
deactivate CategoryController
