sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: next() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: getPagination().nextPage() : void
activate CategoryController
deactivate CategoryController
CategoryController->>CategoryController: recreateModel() : void
activate CategoryController
CategoryController->>CategoryController: items = null
deactivate CategoryController
CategoryController->>Caller: return PageNavigation.LIST;
deactivate CategoryController
