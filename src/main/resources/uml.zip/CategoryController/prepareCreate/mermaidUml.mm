sequenceDiagram
participant Caller
participant CategoryController
participant Category

Caller->>CategoryController: prepareCreate() : PageNavigation
activate CategoryController
CategoryController->>Category: current = new Category() : Category
activate Category
Category->>CategoryController: current
deactivate Category
CategoryController->>CategoryController: selectedItemIndex = -1
CategoryController->>Caller: return PageNavigation.CREATE;
deactivate CategoryController
