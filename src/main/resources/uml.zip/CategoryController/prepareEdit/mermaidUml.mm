sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: prepareEdit() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: current = (Category) getItems().getRowData()
CategoryController->>CategoryController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CategoryController->>Caller: return PageNavigation.EDIT;
deactivate CategoryController
