sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: prepareList() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: recreateModel() : void
activate CategoryController
CategoryController->>CategoryController: items = null
deactivate CategoryController
CategoryController->>Caller: return PageNavigation.LIST;
deactivate CategoryController
