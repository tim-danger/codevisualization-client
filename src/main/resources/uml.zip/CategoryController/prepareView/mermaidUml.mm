sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: prepareView() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: current = (Category) getItems().getRowData()
CategoryController->>CategoryController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CategoryController->>Caller: return PageNavigation.VIEW;
deactivate CategoryController
