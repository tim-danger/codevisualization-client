sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: previous() : PageNavigation
activate CategoryController
CategoryController->>CategoryController: getPagination().previousPage() : void
activate CategoryController
deactivate CategoryController
CategoryController->>CategoryController: recreateModel() : void
activate CategoryController
CategoryController->>CategoryController: items = null
deactivate CategoryController
CategoryController->>Caller: return PageNavigation.LIST;
deactivate CategoryController
