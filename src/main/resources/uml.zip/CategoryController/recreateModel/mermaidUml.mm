sequenceDiagram
participant Caller
participant CategoryController

Caller->>CategoryController: recreateModel() : void
activate CategoryController
CategoryController->>CategoryController: items = null
deactivate CategoryController
