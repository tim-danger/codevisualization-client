sequenceDiagram
participant Caller
participant CategoryController
participant AbstractPaginationHelper

Caller->>CategoryController: updateCurrentItem() : void
activate CategoryController
CategoryController->>CategoryController: count = getFacade().count() : int
activate CategoryController
CategoryController->>CategoryController: count
deactivate CategoryController
alt selectedItemIndex >= count
CategoryController->>CategoryController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
CategoryController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
CategoryController->>CategoryController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate CategoryController
CategoryController->>CategoryController: current
deactivate CategoryController
end
deactivate CategoryController
