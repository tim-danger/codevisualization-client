sequenceDiagram
participant Caller
participant ConfigBean
participant Logger
participant RequestBean
participant Calendar
participant CalendarUtil
participant SimpleDateFormat
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager
participant TypedQuery
participant TutoringSession

Caller->>ConfigBean: createTutoringSession() : void
activate ConfigBean
ConfigBean->>Logger: logger.info("Creating today's session in ConfigBean") : void
activate Logger
deactivate Logger
ConfigBean->>RequestBean: requestBean.getTodaysSession() : void
activate RequestBean
RequestBean->>Calendar: today = Calendar.getInstance() : Calendar
activate Calendar
Calendar->>RequestBean: today
deactivate Calendar
RequestBean->>CalendarUtil: CalendarUtil.stripTime(today) : void
activate CalendarUtil
CalendarUtil->>Calendar: cal.clear(Calendar.AM_PM) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR_OF_DAY) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MINUTE) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.SECOND) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MILLISECOND) : void
activate Calendar
deactivate Calendar
deactivate CalendarUtil
RequestBean->>SimpleDateFormat: formatter = new SimpleDateFormat("E, MMM d, yyyy") : SimpleDateFormat
activate SimpleDateFormat
SimpleDateFormat->>RequestBean: formatter
deactivate SimpleDateFormat
RequestBean->>Logger: logger.log(Level.INFO, "Finding tutoring session for {0}", formatter.format(today.getTime())) : void
activate Logger
deactivate Logger
RequestBean->>CriteriaBuilder: cq = cb.createQuery(TutoringSession.class) : CriteriaQuery<TutoringSession>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: tutoringSession = cq.from(TutoringSession.class) : Root<TutoringSession>
activate CriteriaQuery
CriteriaQuery->>RequestBean: tutoringSession
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(tutoringSession) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(tutoringSession.get(TutoringSession_.sessionDate), today)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<TutoringSession>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>RequestBean: TutoringSession session
opt try
RequestBean->>TypedQuery: session = q.getSingleResult() : TutoringSession
activate TypedQuery
TypedQuery->>RequestBean: session
deactivate TypedQuery
RequestBean->>Logger: logger.info("Found session for today.") : void
activate Logger
deactivate Logger
opt catch NoResultException e
RequestBean->>Logger: logger.info("Today's session not found. Creating a new session.") : void
activate Logger
deactivate Logger
RequestBean->>TutoringSession: session = new TutoringSession() : TutoringSession
activate TutoringSession
TutoringSession->>RequestBean: session
deactivate TutoringSession
RequestBean->>EntityManager: em.persist(session) : void
activate EntityManager
deactivate EntityManager
end
end
RequestBean->>RequestBean: return session;
deactivate RequestBean
deactivate ConfigBean
