sequenceDiagram
participant Caller
participant ConfigBean
participant RequestBean
participant Calendar
participant CalendarUtil
participant SimpleDateFormat
participant Logger
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager
participant TypedQuery
participant TutoringSession
participant Student
participant Guardian
participant AdminBean
participant List
participant ArrayList
participant Event
participant StatusEntry
participant Administrator

Caller->>ConfigBean: init() : void
activate ConfigBean
ConfigBean->>RequestBean: requestBean.getTodaysSession() : void
activate RequestBean
RequestBean->>Calendar: today = Calendar.getInstance() : Calendar
activate Calendar
Calendar->>RequestBean: today
deactivate Calendar
RequestBean->>CalendarUtil: CalendarUtil.stripTime(today) : void
activate CalendarUtil
CalendarUtil->>Calendar: cal.clear(Calendar.AM_PM) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR_OF_DAY) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MINUTE) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.SECOND) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MILLISECOND) : void
activate Calendar
deactivate Calendar
deactivate CalendarUtil
RequestBean->>SimpleDateFormat: formatter = new SimpleDateFormat("E, MMM d, yyyy") : SimpleDateFormat
activate SimpleDateFormat
SimpleDateFormat->>RequestBean: formatter
deactivate SimpleDateFormat
RequestBean->>Logger: logger.log(Level.INFO, "Finding tutoring session for {0}", formatter.format(today.getTime())) : void
activate Logger
deactivate Logger
RequestBean->>CriteriaBuilder: cq = cb.createQuery(TutoringSession.class) : CriteriaQuery<TutoringSession>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: tutoringSession = cq.from(TutoringSession.class) : Root<TutoringSession>
activate CriteriaQuery
CriteriaQuery->>RequestBean: tutoringSession
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(tutoringSession) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(tutoringSession.get(TutoringSession_.sessionDate), today)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<TutoringSession>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>RequestBean: TutoringSession session
opt try
RequestBean->>TypedQuery: session = q.getSingleResult() : TutoringSession
activate TypedQuery
TypedQuery->>RequestBean: session
deactivate TypedQuery
RequestBean->>Logger: logger.info("Found session for today.") : void
activate Logger
deactivate Logger
opt catch NoResultException e
RequestBean->>Logger: logger.info("Today's session not found. Creating a new session.") : void
activate Logger
deactivate Logger
RequestBean->>TutoringSession: session = new TutoringSession() : TutoringSession
activate TutoringSession
TutoringSession->>RequestBean: session
deactivate TutoringSession
RequestBean->>EntityManager: em.persist(session) : void
activate EntityManager
deactivate EntityManager
end
end
RequestBean->>RequestBean: return session;
deactivate RequestBean
ConfigBean->>EntityManager: cb = em.getCriteriaBuilder() : CriteriaBuilder
activate EntityManager
EntityManager->>ConfigBean: cb
deactivate EntityManager
ConfigBean->>Logger: logger.info("Creating Maeby entity") : void
activate Logger
deactivate Logger
ConfigBean->>Student: maeby = new Student() : Student
activate Student
Student->>ConfigBean: maeby
deactivate Student
ConfigBean->>Student: maeby.setLastName("Fünke") : void
activate Student
deactivate Student
ConfigBean->>Student: maeby.setFirstName("Maeby") : void
activate Student
deactivate Student
ConfigBean->>Student: maeby.setGrade(10) : void
activate Student
Student->>Student: this.grade = grade
deactivate Student
ConfigBean->>Student: maeby.setSchool("Sunshine Academy") : void
activate Student
Student->>Student: this.school = school
deactivate Student
ConfigBean->>Guardian: tobias = new Guardian() : Guardian
activate Guardian
Guardian->>ConfigBean: tobias
deactivate Guardian
ConfigBean->>Guardian: tobias.setFirstName("Tobias") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: tobias.setLastName("Fünke") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: tobias.setEmail("tobias@example.com") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: tobias.setPassword("javaee") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lindsey = new Guardian() : Guardian
activate Guardian
Guardian->>ConfigBean: lindsey
deactivate Guardian
ConfigBean->>Guardian: lindsey.setFirstName("Lindsey") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lindsey.setLastName("Fünke") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lindsey.setEmail("lindsey@example.com") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lindsey.setPassword("javaee") : void
activate Guardian
deactivate Guardian
ConfigBean->>Logger: logger.info("Creating George Michael entity") : void
activate Logger
deactivate Logger
ConfigBean->>Student: georgeMichael = new Student() : Student
activate Student
Student->>ConfigBean: georgeMichael
deactivate Student
ConfigBean->>Student: georgeMichael.setLastName("Bluth") : void
activate Student
deactivate Student
ConfigBean->>Student: georgeMichael.setFirstName("George") : void
activate Student
deactivate Student
ConfigBean->>Student: georgeMichael.setMiddleName("Michael") : void
activate Student
deactivate Student
ConfigBean->>Student: georgeMichael.setGrade(10) : void
activate Student
deactivate Student
ConfigBean->>Student: georgeMichael.setSchool("Huntington Beach High School") : void
activate Student
deactivate Student
ConfigBean->>Logger: logger.info("Creating Gob entity") : void
activate Logger
deactivate Logger
ConfigBean->>Student: gob = new Student() : Student
activate Student
Student->>ConfigBean: gob
deactivate Student
ConfigBean->>Student: gob.setLastName("Bluth") : void
activate Student
deactivate Student
ConfigBean->>Student: gob.setFirstName("George") : void
activate Student
deactivate Student
ConfigBean->>Student: gob.setMiddleName("Oscar") : void
activate Student
deactivate Student
ConfigBean->>Student: gob.setNickname("Gob") : void
activate Student
deactivate Student
ConfigBean->>Student: gob.setGrade(12) : void
activate Student
deactivate Student
ConfigBean->>Student: gob.setSchool("Magician's Alliance Institute") : void
activate Student
deactivate Student
ConfigBean->>Logger: logger.info("Creating Buster entity") : void
activate Logger
deactivate Logger
ConfigBean->>Student: buster = new Student() : Student
activate Student
Student->>ConfigBean: buster
deactivate Student
ConfigBean->>Student: buster.setFirstName("Byron") : void
activate Student
deactivate Student
ConfigBean->>Student: buster.setLastName("Bluth") : void
activate Student
deactivate Student
ConfigBean->>Student: buster.setNickname("Buster") : void
activate Student
deactivate Student
ConfigBean->>Student: buster.setGrade(11) : void
activate Student
deactivate Student
ConfigBean->>Student: buster.setSchool("Milford Academy") : void
activate Student
deactivate Student
ConfigBean->>Logger: logger.info("Creating Lucille entity") : void
activate Logger
deactivate Logger
ConfigBean->>Guardian: lucille = new Guardian() : Guardian
activate Guardian
Guardian->>ConfigBean: lucille
deactivate Guardian
ConfigBean->>Guardian: lucille.setFirstName("Lucille") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lucille.setLastName("Bluth") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lucille.setEmail("lucille@example.com") : void
activate Guardian
deactivate Guardian
ConfigBean->>Guardian: lucille.setPassword("javaee") : void
activate Guardian
deactivate Guardian
ConfigBean->>Logger: logger.info("Calling createStudent() on Maeby") : void
activate Logger
deactivate Logger
ConfigBean->>AdminBean: result = adminBean.createStudent(maeby) : String
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.createStudent(1 arg): Persisting new student.") : void
activate Logger
deactivate Logger
AdminBean->>EntityManager: em.persist(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "createdStudent";
AdminBean->>ConfigBean: result
deactivate AdminBean
ConfigBean->>Logger: logger.info("Calling createStudent() on George Michael") : void
activate Logger
deactivate Logger
ConfigBean->>AdminBean: result = adminBean.createStudent(georgeMichael) : String
activate AdminBean
AdminBean->>ConfigBean: result
deactivate AdminBean
ConfigBean->>Logger: logger.info("Calling createStudent() on Gob") : void
activate Logger
deactivate Logger
ConfigBean->>AdminBean: result = adminBean.createStudent(gob) : String
activate AdminBean
AdminBean->>ConfigBean: result
deactivate AdminBean
ConfigBean->>Logger: logger.info("Calling createGuardian() for Maeby's parents") : void
activate Logger
deactivate Logger
ConfigBean->>AdminBean: adminBean.createGuardian(tobias, maeby) : void
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "Creating guardian {0} for {1}", new Object[] { guardian.getName(), student.getName() }) : void
activate Logger
deactivate Logger
AdminBean->>Student: student.getGuardians().add(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().add(student) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.persist(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "createdGuardian";
deactivate AdminBean
ConfigBean->>AdminBean: adminBean.createGuardian(lindsey, maeby) : void
activate AdminBean
deactivate AdminBean
ConfigBean->>Logger: logger.info("Calling createGuardian() for Buster and GOB's mom") : void
activate Logger
deactivate Logger
ConfigBean->>List: lucilleKids = new ArrayList<>() : List<Student>
activate List
List->>ConfigBean: lucilleKids
deactivate List
ConfigBean->>List: lucilleKids.add(gob) : void
activate List
deactivate List
ConfigBean->>List: lucilleKids.add(buster) : void
activate List
deactivate List
ConfigBean->>AdminBean: adminBean.createGuardianWithList(lucille, lucilleKids) : void
activate AdminBean
loop for Student s : students
AdminBean->>Student: s.getGuardians().add(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().add(s) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(s) : void
activate EntityManager
deactivate EntityManager
end
AdminBean->>EntityManager: em.persist(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "createdGuardian";
deactivate AdminBean
ConfigBean->>Logger: logger.info("Checking in Maeby and George Michael") : void
activate Logger
deactivate Logger
ConfigBean->>RequestBean: requestBean.checkIn(maeby) : void
activate RequestBean
RequestBean->>RequestBean: String result
alt student == null
RequestBean->>Logger: logger.warning("Student is null!") : void
activate Logger
deactivate Logger
RequestBean->>RequestBean: result = "failedToCheckIn"
else
RequestBean->>RequestBean: tutoringSession = this.getTodaysSession() : TutoringSession
activate RequestBean
RequestBean->>RequestBean: tutoringSession
deactivate RequestBean
RequestBean->>TutoringSession: students = tutoringSession.getStudents() : List<Student>
activate TutoringSession
TutoringSession->>TutoringSession: return students;
TutoringSession->>RequestBean: students
deactivate TutoringSession
alt !students.contains(student)
RequestBean->>Logger: logger.info("Adding student to session.") : void
activate Logger
deactivate Logger
RequestBean->>TutoringSession: tutoringSession.getStudents().add(student) : void
activate TutoringSession
deactivate TutoringSession
RequestBean->>Logger: logger.info("Adding today's tutoring session to student.") : void
activate Logger
deactivate Logger
RequestBean->>Student: sessions = student.getSessions() : List<TutoringSession>
activate Student
Student->>Student: return sessions;
Student->>RequestBean: sessions
deactivate Student
alt sessions.isEmpty()
RequestBean->>Logger: logger.info("Student's sessions list is empty.") : void
activate Logger
deactivate Logger
RequestBean->>ArrayList: sessions = new ArrayList<>() : ArrayList<>
activate ArrayList
ArrayList->>RequestBean: sessions
deactivate ArrayList
end
RequestBean->>List: sessions.add(tutoringSession) : void
activate List
deactivate List
end
RequestBean->>Logger: logger.log(Level.INFO, "Setting {0}''s status to IN", student.getFirstName()) : void
activate Logger
deactivate Logger
RequestBean->>Student: student.setStatus(StatusType.IN) : void
activate Student
Student->>Student: this.status = status
deactivate Student
RequestBean->>Event: statusEvent.fire(new StatusEvent(student)) : void
activate Event
deactivate Event
RequestBean->>Logger: logger.info("Creating a new status entry") : void
activate Logger
deactivate Logger
RequestBean->>StatusEntry: entry = new StatusEntry(StatusType.IN, student, tutoringSession) : StatusEntry
activate StatusEntry
StatusEntry->>RequestBean: entry
deactivate StatusEntry
RequestBean->>Logger: logger.info("Adding status entry to tutoring session") : void
activate Logger
deactivate Logger
RequestBean->>TutoringSession: tutoringSession.getStatusEntries().add(entry) : void
activate TutoringSession
deactivate TutoringSession
RequestBean->>Logger: logger.info("Persisting status entry") : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.persist(entry) : void
activate EntityManager
deactivate EntityManager
RequestBean->>Logger: logger.log(Level.INFO, "Merging status change to {0}", student.getFirstName()) : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
RequestBean->>Logger: logger.info("Merging the status entry to tutoring session") : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.merge(tutoringSession) : void
activate EntityManager
deactivate EntityManager
RequestBean->>RequestBean: result = "checkinSucceeded"
end
RequestBean->>RequestBean: return result;
deactivate RequestBean
ConfigBean->>RequestBean: requestBean.checkIn(georgeMichael) : void
activate RequestBean
deactivate RequestBean
ConfigBean->>Administrator: admin = new Administrator() : Administrator
activate Administrator
Administrator->>ConfigBean: admin
deactivate Administrator
ConfigBean->>Administrator: admin.setFirstName("Admin") : void
activate Administrator
deactivate Administrator
ConfigBean->>Administrator: admin.setLastName("Administrator") : void
activate Administrator
deactivate Administrator
ConfigBean->>Administrator: admin.setEmail("admin@example.com") : void
activate Administrator
deactivate Administrator
ConfigBean->>Administrator: admin.setPassword("javaee") : void
activate Administrator
deactivate Administrator
ConfigBean->>AdminBean: result = adminBean.createAdministrator(admin) : String
activate AdminBean
AdminBean->>EntityManager: em.persist(admin) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return "createdAdministrator";
AdminBean->>ConfigBean: result
deactivate AdminBean
deactivate ConfigBean
