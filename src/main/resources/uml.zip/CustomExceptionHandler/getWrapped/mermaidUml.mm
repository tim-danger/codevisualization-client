sequenceDiagram
participant Caller
participant CustomExceptionHandler

Caller->>CustomExceptionHandler: getWrapped() : ExceptionHandler
activate CustomExceptionHandler
CustomExceptionHandler->>Caller: return wrapped;
deactivate CustomExceptionHandler
