sequenceDiagram
participant Caller
participant CustomExceptionHandler
participant StringWriter
participant PrintWriter
participant Iterator
participant ExceptionQueuedEventContext
participant FacesContext
participant Logger
participant Map
participant Throwable
participant NavigationHandler

Caller->>CustomExceptionHandler: handle() : void
activate CustomExceptionHandler
CustomExceptionHandler->>StringWriter: sw = new StringWriter() : StringWriter
activate StringWriter
StringWriter->>CustomExceptionHandler: sw
deactivate StringWriter
CustomExceptionHandler->>PrintWriter: pw = new PrintWriter(sw) : PrintWriter
activate PrintWriter
PrintWriter->>CustomExceptionHandler: pw
deactivate PrintWriter
CustomExceptionHandler->>CustomExceptionHandler: i = getUnhandledExceptionQueuedEvents().iterator() : Iterator<ExceptionQueuedEvent>
activate CustomExceptionHandler
CustomExceptionHandler->>CustomExceptionHandler: i
deactivate CustomExceptionHandler
loop while i.hasNext()
CustomExceptionHandler->>Iterator: event = i.next() : ExceptionQueuedEvent
activate Iterator
Iterator->>CustomExceptionHandler: event
deactivate Iterator
CustomExceptionHandler->>CustomExceptionHandler: ExceptionQueuedEventContext context = (ExceptionQueuedEventContext) event.getSource()
CustomExceptionHandler->>ExceptionQueuedEventContext: t = context.getException() : Throwable
activate ExceptionQueuedEventContext
ExceptionQueuedEventContext->>CustomExceptionHandler: t
deactivate ExceptionQueuedEventContext
CustomExceptionHandler->>FacesContext: fc = FacesContext.getCurrentInstance() : FacesContext
activate FacesContext
FacesContext->>CustomExceptionHandler: fc
deactivate FacesContext
CustomExceptionHandler->>FacesContext: requestMap = fc.getExternalContext().getRequestMap() : Map<String,Object>
activate FacesContext
FacesContext->>CustomExceptionHandler: requestMap
deactivate FacesContext
CustomExceptionHandler->>FacesContext: nav = fc.getApplication().getNavigationHandler() : NavigationHandler
activate FacesContext
FacesContext->>CustomExceptionHandler: nav
deactivate FacesContext
opt try
CustomExceptionHandler->>Logger: log.log(Level.INFO, "Custom Exception Handler", t) : void
activate Logger
deactivate Logger
CustomExceptionHandler->>Map: requestMap.put("exceptionMessage", t.getMessage()) : void
activate Map
deactivate Map
CustomExceptionHandler->>Throwable: t.printStackTrace(pw) : void
activate Throwable
deactivate Throwable
CustomExceptionHandler->>Map: requestMap.put("exceptionTrace", sw.toString()) : void
activate Map
deactivate Map
CustomExceptionHandler->>NavigationHandler: nav.handleNavigation(fc, null, "/error") : void
activate NavigationHandler
deactivate NavigationHandler
CustomExceptionHandler->>FacesContext: fc.renderResponse() : void
activate FacesContext
deactivate FacesContext
end
end
CustomExceptionHandler->>CustomExceptionHandler: getWrapped().handle() : void
activate CustomExceptionHandler
deactivate CustomExceptionHandler
deactivate CustomExceptionHandler
