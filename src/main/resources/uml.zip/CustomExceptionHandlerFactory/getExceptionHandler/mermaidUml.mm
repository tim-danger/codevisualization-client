sequenceDiagram
participant Caller
participant CustomExceptionHandlerFactory
participant ExceptionHandler

Caller->>CustomExceptionHandlerFactory: getExceptionHandler() : ExceptionHandler
activate CustomExceptionHandlerFactory
CustomExceptionHandlerFactory->>ExceptionHandler: handler = new CustomExceptionHandler(parent.getExceptionHandler()) : ExceptionHandler
activate ExceptionHandler
ExceptionHandler->>CustomExceptionHandlerFactory: handler
deactivate ExceptionHandler
CustomExceptionHandlerFactory->>Caller: return handler;
deactivate CustomExceptionHandlerFactory
