sequenceDiagram
participant Caller
participant Customer

Caller->>Customer: equals(object) : boolean
activate Customer
alt !(object instanceof Customer)
Customer->>Caller: return false;
end
Customer->>Customer: Customer other = (Customer) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Customer->>Caller: return false;
end
Customer->>Caller: return true;
deactivate Customer
