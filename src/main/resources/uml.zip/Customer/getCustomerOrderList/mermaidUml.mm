sequenceDiagram
participant Caller
participant Customer

Caller->>Customer: getCustomerOrderList() : List<CustomerOrder>
activate Customer
Customer->>Caller: return customerOrderList;
deactivate Customer
