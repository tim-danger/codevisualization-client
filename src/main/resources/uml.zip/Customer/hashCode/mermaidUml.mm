sequenceDiagram
participant Caller
participant Customer

Caller->>Customer: hashCode() : int
activate Customer
Customer->>Customer: int hash = 0
Customer->>Customer: hash += (id != null ? id.hashCode() : 0)
Customer->>Caller: return hash;
deactivate Customer
