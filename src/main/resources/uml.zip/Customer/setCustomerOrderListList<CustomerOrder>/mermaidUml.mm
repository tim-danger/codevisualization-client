sequenceDiagram
participant Caller
participant Customer

Caller->>Customer: setCustomerOrderList(customerOrderList) : void
activate Customer
Customer->>Customer: this.customerOrderList = customerOrderList
deactivate Customer
