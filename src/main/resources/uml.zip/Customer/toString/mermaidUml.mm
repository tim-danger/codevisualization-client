sequenceDiagram
participant Caller
participant Customer

Caller->>Customer: toString() : String
activate Customer
Customer->>Caller: return "com.forest.entity.Customer[id=" + id + "]";
deactivate Customer
