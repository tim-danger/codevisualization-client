sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: getAuthenticated() : Person
activate CustomerController
CustomerController->>Caller: return authenticated;
deactivate CustomerController
