sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: getFacade() : UserBean
activate CustomerController
CustomerController->>Caller: return ejbFacade;
deactivate CustomerController
