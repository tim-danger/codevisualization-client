sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: getItems() : DataModel
activate CustomerController
alt items == null
CustomerController->>CustomerController: items = getPagination().createPageDataModel() : DataModel
activate CustomerController
CustomerController->>CustomerController: items
deactivate CustomerController
end
CustomerController->>Caller: return items;
deactivate CustomerController
