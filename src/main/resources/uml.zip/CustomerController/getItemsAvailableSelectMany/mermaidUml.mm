sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: getItemsAvailableSelectMany() : SelectItem[]
activate CustomerController
CustomerController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate CustomerController
