sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: getItemsAvailableSelectOne() : SelectItem[]
activate CustomerController
CustomerController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate CustomerController
