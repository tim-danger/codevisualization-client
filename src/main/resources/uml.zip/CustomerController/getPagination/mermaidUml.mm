sequenceDiagram
participant Caller
participant CustomerController
participant AbstractPaginationHelper

Caller->>CustomerController: getPagination() : AbstractPaginationHelper
activate CustomerController
alt pagination == null
CustomerController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(AbstractPaginationHelper.DEFAULT_SIZE) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));         //return new ListDataModel(getFacade().findAll());     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>CustomerController: pagination
deactivate AbstractPaginationHelper
end
CustomerController->>Caller: return pagination;
deactivate CustomerController
