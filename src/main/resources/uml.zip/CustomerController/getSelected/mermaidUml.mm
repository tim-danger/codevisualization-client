sequenceDiagram
participant Caller
participant CustomerController
participant Customer

Caller->>CustomerController: getSelected() : Customer
activate CustomerController
alt current == null
CustomerController->>Customer: current = new Customer() : Customer
activate Customer
Customer->>CustomerController: current
deactivate Customer
CustomerController->>CustomerController: selectedItemIndex = -1
end
CustomerController->>Caller: return current;
deactivate CustomerController
