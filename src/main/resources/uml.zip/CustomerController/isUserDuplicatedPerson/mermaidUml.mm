sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: isUserDuplicated(p) : boolean
activate CustomerController
CustomerController->>Caller: return (getFacade().getUserByEmail(p.getEmail()) == null) ? false : true;
deactivate CustomerController
