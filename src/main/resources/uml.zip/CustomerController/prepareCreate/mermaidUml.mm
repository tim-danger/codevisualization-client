sequenceDiagram
participant Caller
participant CustomerController
participant Customer

Caller->>CustomerController: prepareCreate() : PageNavigation
activate CustomerController
CustomerController->>Customer: current = new Customer() : Customer
activate Customer
Customer->>CustomerController: current
deactivate Customer
CustomerController->>CustomerController: selectedItemIndex = -1
CustomerController->>Caller: return PageNavigation.CREATE;
deactivate CustomerController
