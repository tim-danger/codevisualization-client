sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: prepareEdit() : PageNavigation
activate CustomerController
CustomerController->>CustomerController: current = (Customer) getItems().getRowData()
CustomerController->>CustomerController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CustomerController->>Caller: return PageNavigation.EDIT;
deactivate CustomerController
