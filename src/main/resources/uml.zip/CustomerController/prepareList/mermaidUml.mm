sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: prepareList() : PageNavigation
activate CustomerController
CustomerController->>CustomerController: recreateModel() : void
activate CustomerController
CustomerController->>CustomerController: items = null
deactivate CustomerController
CustomerController->>Caller: return PageNavigation.LIST;
deactivate CustomerController
