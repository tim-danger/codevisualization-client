sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: recreateModel() : void
activate CustomerController
CustomerController->>CustomerController: items = null
deactivate CustomerController
