sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: setAuthenticated(p) : void
activate CustomerController
CustomerController->>CustomerController: this.authenticated = p
deactivate CustomerController
