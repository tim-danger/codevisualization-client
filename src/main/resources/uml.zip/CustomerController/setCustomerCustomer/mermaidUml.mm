sequenceDiagram
participant Caller
participant CustomerController

Caller->>CustomerController: setCustomer(user) : void
activate CustomerController
CustomerController->>CustomerController: this.authenticated = user
deactivate CustomerController
