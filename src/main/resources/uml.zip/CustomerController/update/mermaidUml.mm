sequenceDiagram
participant Caller
participant CustomerController
participant Logger
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception

Caller->>CustomerController: update() : PageNavigation
activate CustomerController
opt try
CustomerController->>Logger: logger.log(Level.INFO, "Updating customer ID:{0}", current.getId()) : void
activate Logger
deactivate Logger
CustomerController->>CustomerController: getFacade().edit(current) : void
activate CustomerController
deactivate CustomerController
CustomerController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("CustomerUpdated")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
CustomerController->>CustomerController: return PageNavigation.VIEW;
opt catch Exception e
CustomerController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
CustomerController->>CustomerController: return null;
end
end
deactivate CustomerController
