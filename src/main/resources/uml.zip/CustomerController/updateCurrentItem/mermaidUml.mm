sequenceDiagram
participant Caller
participant CustomerController
participant AbstractPaginationHelper

Caller->>CustomerController: updateCurrentItem() : void
activate CustomerController
CustomerController->>CustomerController: count = getFacade().count() : int
activate CustomerController
CustomerController->>CustomerController: count
deactivate CustomerController
alt selectedItemIndex >= count
CustomerController->>CustomerController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
CustomerController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
CustomerController->>CustomerController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate CustomerController
CustomerController->>CustomerController: current
deactivate CustomerController
end
deactivate CustomerController
