sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: equals(object) : boolean
activate CustomerOrder
alt !(object instanceof CustomerOrder)
CustomerOrder->>Caller: return false;
end
CustomerOrder->>CustomerOrder: CustomerOrder other = (CustomerOrder) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
CustomerOrder->>Caller: return false;
end
CustomerOrder->>Caller: return true;
deactivate CustomerOrder
