sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getAmount() : double
activate CustomerOrder
CustomerOrder->>Caller: return amount;
deactivate CustomerOrder
