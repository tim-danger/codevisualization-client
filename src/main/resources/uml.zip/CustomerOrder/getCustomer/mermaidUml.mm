sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getCustomer() : Customer
activate CustomerOrder
CustomerOrder->>Caller: return customer;
deactivate CustomerOrder
