sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getDateCreated() : Date
activate CustomerOrder
CustomerOrder->>Caller: return dateCreated;
deactivate CustomerOrder
