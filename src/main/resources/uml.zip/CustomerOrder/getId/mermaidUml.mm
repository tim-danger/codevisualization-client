sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getId() : Integer
activate CustomerOrder
CustomerOrder->>Caller: return id;
deactivate CustomerOrder
