sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getOrderDetailList() : List<OrderDetail>
activate CustomerOrder
CustomerOrder->>Caller: return orderDetailList;
deactivate CustomerOrder
