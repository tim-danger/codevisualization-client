sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: getOrderStatus() : OrderStatus
activate CustomerOrder
CustomerOrder->>Caller: return orderStatus;
deactivate CustomerOrder
