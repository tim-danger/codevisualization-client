sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: hashCode() : int
activate CustomerOrder
CustomerOrder->>CustomerOrder: int hash = 0
CustomerOrder->>CustomerOrder: hash += (id != null ? id.hashCode() : 0)
CustomerOrder->>Caller: return hash;
deactivate CustomerOrder
