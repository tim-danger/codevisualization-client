sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setAmount(amount) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.amount = amount
deactivate CustomerOrder
