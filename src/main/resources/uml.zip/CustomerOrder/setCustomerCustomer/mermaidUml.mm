sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setCustomer(customer) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.customer = customer
deactivate CustomerOrder
