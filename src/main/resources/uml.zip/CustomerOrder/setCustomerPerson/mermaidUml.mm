sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setCustomer(person) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.customer = (Customer) person
deactivate CustomerOrder
