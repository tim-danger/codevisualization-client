sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setDateCreated(dateCreated) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.dateCreated = dateCreated
deactivate CustomerOrder
