sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setId(id) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.id = id
deactivate CustomerOrder
