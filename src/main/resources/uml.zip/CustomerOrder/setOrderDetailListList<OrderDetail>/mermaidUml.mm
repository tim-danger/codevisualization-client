sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setOrderDetailList(orderDetailList) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderDetailList = orderDetailList
deactivate CustomerOrder
