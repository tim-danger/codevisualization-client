sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: setOrderStatus(orderStatus) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderStatus = orderStatus
deactivate CustomerOrder
