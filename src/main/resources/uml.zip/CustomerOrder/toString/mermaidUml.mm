sequenceDiagram
participant Caller
participant CustomerOrder

Caller->>CustomerOrder: toString() : String
activate CustomerOrder
CustomerOrder->>Caller: return "com.forest.entity.CustomerOrder[id=" + id + "]";
deactivate CustomerOrder
