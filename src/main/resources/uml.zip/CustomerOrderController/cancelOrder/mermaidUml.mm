sequenceDiagram
participant Caller
participant CustomerOrderController
participant OrderJMSManager
participant JMSContext
participant JMSConsumer
participant Logger
participant com.forest.ejb.AdministratorBean
participant ex

Caller->>CustomerOrderController: cancelOrder() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current = (CustomerOrder) getItems().getRowData()
CustomerOrderController->>CustomerOrderController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
opt try
CustomerOrderController->>OrderJMSManager: orderJMSManager.deleteMessage(current.getId()) : void
activate OrderJMSManager
OrderJMSManager->>JMSContext: consumer = context.createConsumer(queue, "OrderID='" + orderID + "'") : JMSConsumer
activate JMSContext
JMSContext->>OrderJMSManager: consumer
deactivate JMSContext
OrderJMSManager->>JMSConsumer: order = consumer.receiveBody(CustomerOrder.class, 1) : CustomerOrder
activate JMSConsumer
JMSConsumer->>OrderJMSManager: order
deactivate JMSConsumer
alt order != null
OrderJMSManager->>Logger: logger.log(Level.INFO, "Order {0} removed from queue.", order.getId()) : void
activate Logger
deactivate Logger
else
OrderJMSManager->>Logger: logger.log(Level.SEVERE, "Order {0} was not removed from queue!", orderID) : void
activate Logger
deactivate Logger
OrderJMSManager->>Caller: throw new Exception("Order not removed from queue")
end
deactivate OrderJMSManager
CustomerOrderController->>com.forest.ejb.AdministratorBean: ejbFacade.setOrderStatus(current.getId(), String.valueOf(OrderBean.Status.CANCELLED_MANUAL.getStatus())) : void
activate com.forest.ejb.AdministratorBean
deactivate com.forest.ejb.AdministratorBean
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: return PageNavigation.LIST;
opt catch Exception ex
CustomerOrderController->>ex: ex.printStackTrace() : void
activate ex
deactivate ex
end
end
CustomerOrderController->>Caller: return PageNavigation.INDEX;
deactivate CustomerOrderController
