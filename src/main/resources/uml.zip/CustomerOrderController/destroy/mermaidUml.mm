sequenceDiagram
participant Caller
participant CustomerOrderController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception

Caller->>CustomerOrderController: destroy() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current = (CustomerOrder) getItems().getRowData()
CustomerOrderController->>CustomerOrderController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CustomerOrderController->>CustomerOrderController: performDestroy() : void
activate CustomerOrderController
opt try
CustomerOrderController->>CustomerOrderController: getFacade().remove(current) : void
activate CustomerOrderController
deactivate CustomerOrderController
CustomerOrderController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("CustomerOrderDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
CustomerOrderController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>Caller: return PageNavigation.LIST;
deactivate CustomerOrderController
