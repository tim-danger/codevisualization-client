sequenceDiagram
participant Caller
participant CustomerOrderController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>CustomerOrderController: destroyAndView() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: performDestroy() : void
activate CustomerOrderController
opt try
CustomerOrderController->>CustomerOrderController: getFacade().remove(current) : void
activate CustomerOrderController
deactivate CustomerOrderController
CustomerOrderController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("CustomerOrderDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
CustomerOrderController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: updateCurrentItem() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: count = getFacade().count() : int
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: count
deactivate CustomerOrderController
alt selectedItemIndex >= count
CustomerOrderController->>CustomerOrderController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
CustomerOrderController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
CustomerOrderController->>CustomerOrderController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current
deactivate CustomerOrderController
end
deactivate CustomerOrderController
alt selectedItemIndex >= 0
CustomerOrderController->>Caller: return PageNavigation.VIEW;
else
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
deactivate CustomerOrderController
CustomerOrderController->>Caller: return PageNavigation.LIST;
end
deactivate CustomerOrderController
