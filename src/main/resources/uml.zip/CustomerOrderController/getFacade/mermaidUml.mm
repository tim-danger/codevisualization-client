sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: getFacade() : OrderBean
activate CustomerOrderController
CustomerOrderController->>Caller: return ejbFacade;
deactivate CustomerOrderController
