sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: getItems() : DataModel
activate CustomerOrderController
alt items == null
CustomerOrderController->>CustomerOrderController: items = getPagination().createPageDataModel() : DataModel
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items
deactivate CustomerOrderController
end
CustomerOrderController->>Caller: return items;
deactivate CustomerOrderController
