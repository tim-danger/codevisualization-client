sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: getItemsAvailableSelectMany() : SelectItem[]
activate CustomerOrderController
CustomerOrderController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate CustomerOrderController
