sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: getItemsAvailableSelectOne() : SelectItem[]
activate CustomerOrderController
CustomerOrderController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate CustomerOrderController
