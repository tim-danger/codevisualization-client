sequenceDiagram
participant Caller
participant CustomerOrderController
participant Logger
participant JsfUtil
participant FacesMessage
participant FacesContext

Caller->>CustomerOrderController: getMyOrders() : List<CustomerOrder>
activate CustomerOrderController
alt user != null
CustomerOrderController->>CustomerOrderController: myOrders = getFacade().getOrderByCustomerId(user.getId()) : List<CustomerOrder>
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: myOrders
deactivate CustomerOrderController
alt myOrders.isEmpty()
CustomerOrderController->>Logger: logger.log(Level.FINEST, "Customer {0} has no orders to display.", user.getEmail()) : void
activate Logger
deactivate Logger
CustomerOrderController->>Caller: return null;
else
CustomerOrderController->>Logger: logger.log(Level.FINEST, "Order amount:{0}", myOrders.get(0).getAmount()) : void
activate Logger
deactivate Logger
CustomerOrderController->>Caller: return myOrders;
end
else
CustomerOrderController->>JsfUtil: JsfUtil.addErrorMessage("Current user is not authenticated. Please do login before accessing your orders.") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
CustomerOrderController->>Caller: return null;
end
deactivate CustomerOrderController
