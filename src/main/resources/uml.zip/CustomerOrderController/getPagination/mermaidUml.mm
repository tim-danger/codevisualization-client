sequenceDiagram
participant Caller
participant CustomerOrderController
participant AbstractPaginationHelper

Caller->>CustomerOrderController: getPagination() : AbstractPaginationHelper
activate CustomerOrderController
alt pagination == null
CustomerOrderController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(10) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>CustomerOrderController: pagination
deactivate AbstractPaginationHelper
end
CustomerOrderController->>Caller: return pagination;
deactivate CustomerOrderController
