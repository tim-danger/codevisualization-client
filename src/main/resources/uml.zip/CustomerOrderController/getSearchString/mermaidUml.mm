sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: getSearchString() : String
activate CustomerOrderController
CustomerOrderController->>Caller: return searchString;
deactivate CustomerOrderController
