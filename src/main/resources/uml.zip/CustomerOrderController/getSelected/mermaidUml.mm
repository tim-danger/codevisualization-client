sequenceDiagram
participant Caller
participant CustomerOrderController
participant CustomerOrder

Caller->>CustomerOrderController: getSelected() : CustomerOrder
activate CustomerOrderController
alt current == null
CustomerOrderController->>CustomerOrder: current = new CustomerOrder() : CustomerOrder
activate CustomerOrder
CustomerOrder->>CustomerOrderController: current
deactivate CustomerOrder
CustomerOrderController->>CustomerOrderController: selectedItemIndex = -1
end
CustomerOrderController->>Caller: return current;
deactivate CustomerOrderController
