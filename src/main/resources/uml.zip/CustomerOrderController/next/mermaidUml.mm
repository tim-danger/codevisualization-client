sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: next() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: getPagination().nextPage() : void
activate CustomerOrderController
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>Caller: return PageNavigation.LIST;
deactivate CustomerOrderController
