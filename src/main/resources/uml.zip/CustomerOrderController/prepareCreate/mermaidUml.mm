sequenceDiagram
participant Caller
participant CustomerOrderController
participant CustomerOrder

Caller->>CustomerOrderController: prepareCreate() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrder: current = new CustomerOrder() : CustomerOrder
activate CustomerOrder
CustomerOrder->>CustomerOrderController: current
deactivate CustomerOrder
CustomerOrderController->>CustomerOrderController: selectedItemIndex = -1
CustomerOrderController->>Caller: return PageNavigation.CREATE;
deactivate CustomerOrderController
