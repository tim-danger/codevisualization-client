sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: prepareEdit() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current = (CustomerOrder) getItems().getRowData()
CustomerOrderController->>CustomerOrderController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CustomerOrderController->>Caller: return PageNavigation.EDIT;
deactivate CustomerOrderController
