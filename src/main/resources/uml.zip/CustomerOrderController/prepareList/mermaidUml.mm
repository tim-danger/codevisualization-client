sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: prepareList() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>Caller: return PageNavigation.LIST;
deactivate CustomerOrderController
