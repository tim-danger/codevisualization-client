sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: prepareView() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current = (CustomerOrder) getItems().getRowData()
CustomerOrderController->>CustomerOrderController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
CustomerOrderController->>Caller: return PageNavigation.VIEW;
deactivate CustomerOrderController
