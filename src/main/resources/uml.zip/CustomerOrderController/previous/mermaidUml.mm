sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: previous() : PageNavigation
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: getPagination().previousPage() : void
activate CustomerOrderController
deactivate CustomerOrderController
CustomerOrderController->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
CustomerOrderController->>Caller: return PageNavigation.LIST;
deactivate CustomerOrderController
