sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: recreateModel() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: items = null
deactivate CustomerOrderController
