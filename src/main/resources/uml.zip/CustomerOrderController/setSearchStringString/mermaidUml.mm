sequenceDiagram
participant Caller
participant CustomerOrderController

Caller->>CustomerOrderController: setSearchString(searchString) : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: this.searchString = searchString
deactivate CustomerOrderController
