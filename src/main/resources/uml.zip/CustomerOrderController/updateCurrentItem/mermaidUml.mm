sequenceDiagram
participant Caller
participant CustomerOrderController
participant AbstractPaginationHelper

Caller->>CustomerOrderController: updateCurrentItem() : void
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: count = getFacade().count() : int
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: count
deactivate CustomerOrderController
alt selectedItemIndex >= count
CustomerOrderController->>CustomerOrderController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
CustomerOrderController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
CustomerOrderController->>CustomerOrderController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate CustomerOrderController
CustomerOrderController->>CustomerOrderController: current
deactivate CustomerOrderController
end
deactivate CustomerOrderController
