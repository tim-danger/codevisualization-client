sequenceDiagram
participant Caller
participant DeliveryHandler
participant Logger
participant OrderBean
participant OrderStatusBean
participant CustomerOrder
participant EntityManager
participant Query
participant OrderJMSManager
participant JMSContext
participant ObjectMessage

Caller->>DeliveryHandler: onNewOrder(event) : void
activate DeliveryHandler
DeliveryHandler->>Logger: logger.log(Level.FINEST, "{0} Event being processed by DeliveryHandler", Thread.currentThread().getName()) : void
activate Logger
deactivate Logger
opt try
DeliveryHandler->>Logger: logger.log(Level.INFO, "Order #{0} has been paid in the amount of {1}. Order is now ready for delivery!", new Object[] { event.getOrderID(), event.getAmount() }) : void
activate Logger
deactivate Logger
DeliveryHandler->>OrderBean: orderBean.setOrderStatus(event.getOrderID(), String.valueOf(OrderBean.Status.READY_TO_SHIP.getStatus())) : void
activate OrderBean
OrderBean->>Logger: logger.log(Level.INFO, "Order id:{0} - Status:{1}", new Object[] { orderId, newStatus }) : void
activate Logger
deactivate Logger
opt try
OrderBean->>OrderBean: order = this.find(orderId) : CustomerOrder
activate OrderBean
OrderBean->>OrderBean: order
deactivate OrderBean
alt order != null
OrderBean->>Logger: logger.log(Level.FINEST, "Updating order {0} status to {1}", new Object[] { order.getId(), newStatus }) : void
activate Logger
deactivate Logger
OrderBean->>OrderStatusBean: oStatus = statusBean.find(new Integer(newStatus)) : OrderStatus
activate OrderStatusBean
OrderStatusBean->>OrderBean: oStatus
deactivate OrderStatusBean
OrderBean->>CustomerOrder: order.setOrderStatus(oStatus) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderStatus = orderStatus
deactivate CustomerOrder
OrderBean->>EntityManager: em.merge(order) : void
activate EntityManager
deactivate EntityManager
OrderBean->>Logger: logger.info("Order Updated!") : void
activate Logger
deactivate Logger
end
opt catch Exception ex
OrderBean->>Logger: logger.log(Level.SEVERE, ex.getMessage()) : void
activate Logger
deactivate Logger
end
end
deactivate OrderBean
DeliveryHandler->>OrderBean: order = orderBean.getOrderById(event.getOrderID()) : CustomerOrder
activate OrderBean
OrderBean->>OrderBean: createNamedQuery = getEntityManager().createNamedQuery("CustomerOrder.findById") : Query
activate OrderBean
OrderBean->>OrderBean: createNamedQuery
deactivate OrderBean
OrderBean->>Query: createNamedQuery.setParameter("id", id) : void
activate Query
deactivate Query
OrderBean->>OrderBean: return (CustomerOrder) createNamedQuery.getSingleResult();
OrderBean->>DeliveryHandler: order
deactivate OrderBean
alt order != null
DeliveryHandler->>OrderJMSManager: orderPublisher.sendMessage(order) : void
activate OrderJMSManager
OrderJMSManager->>JMSContext: msgObj = context.createObjectMessage() : ObjectMessage
activate JMSContext
JMSContext->>OrderJMSManager: msgObj
deactivate JMSContext
opt try
OrderJMSManager->>ObjectMessage: msgObj.setObject(customerOrder) : void
activate ObjectMessage
deactivate ObjectMessage
OrderJMSManager->>ObjectMessage: msgObj.setStringProperty("OrderID", String.valueOf(customerOrder.getId())) : void
activate ObjectMessage
deactivate ObjectMessage
OrderJMSManager->>JMSContext: context.createProducer().send(queue, msgObj) : void
activate JMSContext
deactivate JMSContext
opt catch JMSException ex
OrderJMSManager->>Logger: logger.log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
end
end
deactivate OrderJMSManager
else
DeliveryHandler->>Caller: throw new Exception("The order does not exist")
end
opt catch Exception jex
DeliveryHandler->>Logger: logger.log(Level.SEVERE, null, jex) : void
activate Logger
deactivate Logger
end
end
deactivate DeliveryHandler
