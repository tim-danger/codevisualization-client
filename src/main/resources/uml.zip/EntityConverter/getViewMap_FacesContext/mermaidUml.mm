sequenceDiagram
participant Caller
participant EntityConverter
participant FacesContext
participant HashMap
participant Map

Caller->>EntityConverter: getViewMap(context) : Map<String,Object>
activate EntityConverter
EntityConverter->>FacesContext: viewMap = context.getViewRoot().getViewMap() : Map<String,Object>
activate FacesContext
FacesContext->>EntityConverter: viewMap
deactivate FacesContext
EntityConverter->>EntityConverter: Map<String,Object> idMap = (Map) viewMap.get(key)
alt idMap == null
EntityConverter->>HashMap: idMap = new HashMap<>() : HashMap<>
activate HashMap
HashMap->>EntityConverter: idMap
deactivate HashMap
EntityConverter->>Map: viewMap.put(key, idMap) : void
activate Map
deactivate Map
end
EntityConverter->>Caller: return idMap;
deactivate EntityConverter
