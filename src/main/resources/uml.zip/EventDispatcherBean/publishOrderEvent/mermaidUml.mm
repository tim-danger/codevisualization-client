sequenceDiagram
participant Caller
participant EventDispatcherBean
participant Logger
participant Event

Caller->>EventDispatcherBean: publish(event) : void
activate EventDispatcherBean
EventDispatcherBean->>Logger: logger.log(Level.FINEST, "{0} Sending event from EJB", Thread.currentThread().getName()) : void
activate Logger
deactivate Logger
EventDispatcherBean->>Event: eventManager.fire(event) : void
activate Event
deactivate Event
deactivate EventDispatcherBean
