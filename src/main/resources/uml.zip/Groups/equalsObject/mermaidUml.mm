sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: equals(object) : boolean
activate Groups
alt !(object instanceof Groups)
Groups->>Caller: return false;
end
Groups->>Groups: Groups other = (Groups) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Groups->>Caller: return false;
end
Groups->>Caller: return true;
deactivate Groups
