sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: getDescription() : String
activate Groups
Groups->>Caller: return description;
deactivate Groups
