sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: getId() : Integer
activate Groups
Groups->>Caller: return id;
deactivate Groups
