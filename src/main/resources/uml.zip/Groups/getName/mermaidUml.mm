sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: getName() : String
activate Groups
Groups->>Caller: return name;
deactivate Groups
