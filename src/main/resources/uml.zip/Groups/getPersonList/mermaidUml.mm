sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: getPersonList() : List<Person>
activate Groups
Groups->>Caller: return personList;
deactivate Groups
