sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: hashCode() : int
activate Groups
Groups->>Groups: int hash = 0
Groups->>Groups: hash += (id != null ? id.hashCode() : 0)
Groups->>Caller: return hash;
deactivate Groups
