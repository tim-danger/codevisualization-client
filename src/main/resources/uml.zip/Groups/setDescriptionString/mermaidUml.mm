sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: setDescription(description) : void
activate Groups
Groups->>Groups: this.description = description
deactivate Groups
