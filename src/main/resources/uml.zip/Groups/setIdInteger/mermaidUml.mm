sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: setId(id) : void
activate Groups
Groups->>Groups: this.id = id
deactivate Groups
