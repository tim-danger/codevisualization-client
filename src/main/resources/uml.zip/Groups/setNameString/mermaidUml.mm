sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: setName(name) : void
activate Groups
Groups->>Groups: this.name = name
deactivate Groups
