sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: setPersonList(personList) : void
activate Groups
Groups->>Groups: this.personList = personList
deactivate Groups
