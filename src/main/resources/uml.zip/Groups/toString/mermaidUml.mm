sequenceDiagram
participant Caller
participant Groups

Caller->>Groups: toString() : String
activate Groups
Groups->>Caller: return "com.forest.entity.Groups[ id=" + id + " ]";
deactivate Groups
