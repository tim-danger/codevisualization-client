sequenceDiagram
participant Caller
participant GroupsBean

Caller->>GroupsBean: getEntityManager() : EntityManager
activate GroupsBean
GroupsBean->>Caller: return em;
deactivate GroupsBean
