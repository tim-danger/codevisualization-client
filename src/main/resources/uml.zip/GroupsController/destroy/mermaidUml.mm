sequenceDiagram
participant Caller
participant GroupsController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception

Caller->>GroupsController: destroy() : PageNavigation
activate GroupsController
GroupsController->>GroupsController: current = (Groups) getItems().getRowData()
GroupsController->>GroupsController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
GroupsController->>GroupsController: performDestroy() : void
activate GroupsController
opt try
GroupsController->>GroupsController: getFacade().remove(current) : void
activate GroupsController
deactivate GroupsController
GroupsController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("GroupsDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
GroupsController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate GroupsController
GroupsController->>GroupsController: recreateModel() : void
activate GroupsController
GroupsController->>GroupsController: items = null
deactivate GroupsController
GroupsController->>Caller: return PageNavigation.LIST;
deactivate GroupsController
