sequenceDiagram
participant Caller
participant GroupsController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>GroupsController: destroyAndView() : PageNavigation
activate GroupsController
GroupsController->>GroupsController: performDestroy() : void
activate GroupsController
opt try
GroupsController->>GroupsController: getFacade().remove(current) : void
activate GroupsController
deactivate GroupsController
GroupsController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("GroupsDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
GroupsController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate GroupsController
GroupsController->>GroupsController: recreateModel() : void
activate GroupsController
GroupsController->>GroupsController: items = null
deactivate GroupsController
GroupsController->>GroupsController: updateCurrentItem() : void
activate GroupsController
GroupsController->>GroupsController: count = getFacade().count() : int
activate GroupsController
GroupsController->>GroupsController: count
deactivate GroupsController
alt selectedItemIndex >= count
GroupsController->>GroupsController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
GroupsController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
GroupsController->>GroupsController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate GroupsController
GroupsController->>GroupsController: current
deactivate GroupsController
end
deactivate GroupsController
alt selectedItemIndex >= 0
GroupsController->>Caller: return PageNavigation.VIEW;
else
GroupsController->>GroupsController: recreateModel() : void
activate GroupsController
deactivate GroupsController
GroupsController->>Caller: return PageNavigation.LIST;
end
deactivate GroupsController
