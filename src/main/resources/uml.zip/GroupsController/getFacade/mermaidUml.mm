sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: getFacade() : GroupsBean
activate GroupsController
GroupsController->>Caller: return ejbFacade;
deactivate GroupsController
