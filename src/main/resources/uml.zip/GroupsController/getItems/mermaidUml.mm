sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: getItems() : DataModel
activate GroupsController
alt items == null
GroupsController->>GroupsController: items = getPagination().createPageDataModel() : DataModel
activate GroupsController
GroupsController->>GroupsController: items
deactivate GroupsController
end
GroupsController->>Caller: return items;
deactivate GroupsController
