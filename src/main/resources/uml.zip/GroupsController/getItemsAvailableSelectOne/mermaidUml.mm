sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: getItemsAvailableSelectOne() : SelectItem[]
activate GroupsController
GroupsController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate GroupsController
