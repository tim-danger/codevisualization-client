sequenceDiagram
participant Caller
participant GroupsController
participant AbstractPaginationHelper

Caller->>GroupsController: getPagination() : AbstractPaginationHelper
activate GroupsController
alt pagination == null
GroupsController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(10) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>GroupsController: pagination
deactivate AbstractPaginationHelper
end
GroupsController->>Caller: return pagination;
deactivate GroupsController
