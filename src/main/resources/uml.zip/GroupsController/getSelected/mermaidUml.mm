sequenceDiagram
participant Caller
participant GroupsController
participant Groups

Caller->>GroupsController: getSelected() : Groups
activate GroupsController
alt current == null
GroupsController->>Groups: current = new Groups() : Groups
activate Groups
Groups->>GroupsController: current
deactivate Groups
GroupsController->>GroupsController: selectedItemIndex = -1
end
GroupsController->>Caller: return current;
deactivate GroupsController
