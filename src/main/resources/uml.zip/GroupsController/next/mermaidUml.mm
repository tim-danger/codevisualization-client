sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: next() : PageNavigation
activate GroupsController
GroupsController->>GroupsController: getPagination().nextPage() : void
activate GroupsController
deactivate GroupsController
GroupsController->>GroupsController: recreateModel() : void
activate GroupsController
GroupsController->>GroupsController: items = null
deactivate GroupsController
GroupsController->>Caller: return PageNavigation.LIST;
deactivate GroupsController
