sequenceDiagram
participant Caller
participant GroupsController
participant Groups

Caller->>GroupsController: prepareCreate() : PageNavigation
activate GroupsController
GroupsController->>Groups: current = new Groups() : Groups
activate Groups
Groups->>GroupsController: current
deactivate Groups
GroupsController->>GroupsController: selectedItemIndex = -1
GroupsController->>Caller: return PageNavigation.CREATE;
deactivate GroupsController
