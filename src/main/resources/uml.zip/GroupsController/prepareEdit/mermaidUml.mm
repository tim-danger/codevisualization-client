sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: prepareEdit() : PageNavigation
activate GroupsController
GroupsController->>GroupsController: current = (Groups) getItems().getRowData()
GroupsController->>GroupsController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
GroupsController->>Caller: return PageNavigation.EDIT;
deactivate GroupsController
