sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: prepareList() : PageNavigation
activate GroupsController
GroupsController->>GroupsController: recreateModel() : void
activate GroupsController
GroupsController->>GroupsController: items = null
deactivate GroupsController
GroupsController->>Caller: return PageNavigation.LIST;
deactivate GroupsController
