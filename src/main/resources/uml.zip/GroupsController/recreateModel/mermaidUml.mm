sequenceDiagram
participant Caller
participant GroupsController

Caller->>GroupsController: recreateModel() : void
activate GroupsController
GroupsController->>GroupsController: items = null
deactivate GroupsController
