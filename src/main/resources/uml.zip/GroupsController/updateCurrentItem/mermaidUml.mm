sequenceDiagram
participant Caller
participant GroupsController
participant AbstractPaginationHelper

Caller->>GroupsController: updateCurrentItem() : void
activate GroupsController
GroupsController->>GroupsController: count = getFacade().count() : int
activate GroupsController
GroupsController->>GroupsController: count
deactivate GroupsController
alt selectedItemIndex >= count
GroupsController->>GroupsController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
GroupsController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
GroupsController->>GroupsController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate GroupsController
GroupsController->>GroupsController: current
deactivate GroupsController
end
deactivate GroupsController
