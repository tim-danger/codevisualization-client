sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: equals(object) : boolean
activate Guardian
alt !(object instanceof Guardian)
Guardian->>Caller: return false;
end
Guardian->>Guardian: Guardian other = (Guardian) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Guardian->>Caller: return false;
end
Guardian->>Caller: return true;
deactivate Guardian
