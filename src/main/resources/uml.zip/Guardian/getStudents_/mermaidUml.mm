sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: getStudents() : List<Student>
activate Guardian
Guardian->>Caller: return students;
deactivate Guardian
