sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: hashCode() : int
activate Guardian
Guardian->>Guardian: int hash = 0
Guardian->>Guardian: hash += (id != null ? id.hashCode() : 0)
Guardian->>Caller: return hash;
deactivate Guardian
