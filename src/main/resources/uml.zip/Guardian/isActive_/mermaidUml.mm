sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: isActive() : boolean
activate Guardian
Guardian->>Caller: return active;
deactivate Guardian
