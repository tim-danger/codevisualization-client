sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: setActive(active) : void
activate Guardian
Guardian->>Guardian: this.active = active
deactivate Guardian
