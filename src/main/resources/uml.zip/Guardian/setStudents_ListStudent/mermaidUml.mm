sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: setStudents(students) : void
activate Guardian
Guardian->>Guardian: this.students = students
deactivate Guardian
