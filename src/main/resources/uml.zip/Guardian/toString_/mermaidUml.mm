sequenceDiagram
participant Caller
participant Guardian

Caller->>Guardian: toString() : String
activate Guardian
Guardian->>Caller: return "dukestutoring.entity.Guardian[id=" + id + "]";
deactivate Guardian
