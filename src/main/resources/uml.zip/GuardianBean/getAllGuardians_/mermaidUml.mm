sequenceDiagram
participant Caller
participant GuardianBean
participant AdminBean
participant EntityManager
participant CriteriaQuery
participant Logger

Caller->>GuardianBean: getAllGuardians() : List<Guardian>
activate GuardianBean
alt allGuardians == null
opt try
GuardianBean->>AdminBean: this.allGuardians = adminBean.getAllGuardians()
activate AdminBean
AdminBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Guardian.class) : CriteriaQuery<Guardian>
activate EntityManager
EntityManager->>AdminBean: cq
deactivate EntityManager
AdminBean->>CriteriaQuery: guardian = cq.from(Guardian.class) : Root<Guardian>
activate CriteriaQuery
CriteriaQuery->>AdminBean: guardian
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.select(guardian) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
AdminBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Guardian>
activate EntityManager
EntityManager->>AdminBean: q
deactivate EntityManager
AdminBean->>AdminBean: return q.getResultList();
AdminBean->>GuardianBean: this.allGuardians
deactivate AdminBean
opt catch Exception ex
GuardianBean->>Logger: logger.log(Level.SEVERE, "adminBean.getAllGuardians returned an error{0}", ex.getMessage()) : void
activate Logger
deactivate Logger
end
end
end
GuardianBean->>Caller: return this.allGuardians;
deactivate GuardianBean
