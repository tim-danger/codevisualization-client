sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getEmail() : String
activate GuardianBean
GuardianBean->>Caller: return email;
deactivate GuardianBean
