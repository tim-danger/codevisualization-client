sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getFirstName() : String
activate GuardianBean
GuardianBean->>Caller: return firstName;
deactivate GuardianBean
