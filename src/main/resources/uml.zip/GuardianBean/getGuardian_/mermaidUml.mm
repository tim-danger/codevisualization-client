sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getGuardian() : Guardian
activate GuardianBean
GuardianBean->>Caller: return guardian;
deactivate GuardianBean
