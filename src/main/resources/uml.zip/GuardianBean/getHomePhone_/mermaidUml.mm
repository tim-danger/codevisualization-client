sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getHomePhone() : String
activate GuardianBean
GuardianBean->>Caller: return homePhone;
deactivate GuardianBean
