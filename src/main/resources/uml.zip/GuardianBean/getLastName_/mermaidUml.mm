sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getLastName() : String
activate GuardianBean
GuardianBean->>Caller: return lastName;
deactivate GuardianBean
