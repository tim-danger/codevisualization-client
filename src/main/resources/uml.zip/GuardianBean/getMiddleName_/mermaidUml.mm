sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getMiddleName() : String
activate GuardianBean
GuardianBean->>Caller: return middleName;
deactivate GuardianBean
