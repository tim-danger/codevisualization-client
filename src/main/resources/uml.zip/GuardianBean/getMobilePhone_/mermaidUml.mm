sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getMobilePhone() : String
activate GuardianBean
GuardianBean->>Caller: return mobilePhone;
deactivate GuardianBean
