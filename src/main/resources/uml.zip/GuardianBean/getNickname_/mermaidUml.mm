sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getNickname() : String
activate GuardianBean
GuardianBean->>Caller: return nickname;
deactivate GuardianBean
