sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getSelectedGuardian() : Guardian
activate GuardianBean
GuardianBean->>Caller: return selectedGuardian;
deactivate GuardianBean
