sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getSelectedGuardians() : List<Guardian>
activate GuardianBean
GuardianBean->>Caller: return selectedGuardians;
deactivate GuardianBean
