sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: getSuffix() : String
activate GuardianBean
GuardianBean->>Caller: return suffix;
deactivate GuardianBean
