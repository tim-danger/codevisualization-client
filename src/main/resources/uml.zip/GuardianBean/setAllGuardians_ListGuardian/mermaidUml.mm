sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setAllGuardians(allGuardians) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.allGuardians = allGuardians
deactivate GuardianBean
