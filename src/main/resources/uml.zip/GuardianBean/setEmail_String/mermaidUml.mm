sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setEmail(email) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.email = email
deactivate GuardianBean
