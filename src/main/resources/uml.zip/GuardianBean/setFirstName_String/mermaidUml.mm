sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setFirstName(firstName) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.firstName = firstName
deactivate GuardianBean
