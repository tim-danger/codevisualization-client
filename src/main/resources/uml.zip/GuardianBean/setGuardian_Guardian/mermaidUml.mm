sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setGuardian(guardian) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.guardian = guardian
deactivate GuardianBean
