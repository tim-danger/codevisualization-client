sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setHomePhone(homePhone) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.homePhone = homePhone
deactivate GuardianBean
