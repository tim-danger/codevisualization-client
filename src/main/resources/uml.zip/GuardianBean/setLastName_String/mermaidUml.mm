sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setLastName(lastName) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.lastName = lastName
deactivate GuardianBean
