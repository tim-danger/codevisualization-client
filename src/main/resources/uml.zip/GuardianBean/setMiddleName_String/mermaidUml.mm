sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setMiddleName(middleName) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.middleName = middleName
deactivate GuardianBean
