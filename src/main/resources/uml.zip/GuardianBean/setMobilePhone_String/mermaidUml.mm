sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setMobilePhone(mobilePhone) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.mobilePhone = mobilePhone
deactivate GuardianBean
