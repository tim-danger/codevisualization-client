sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setNickname(nickname) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.nickname = nickname
deactivate GuardianBean
