sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setSelectedGuardian(selectedGuardian) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.selectedGuardian = selectedGuardian
deactivate GuardianBean
