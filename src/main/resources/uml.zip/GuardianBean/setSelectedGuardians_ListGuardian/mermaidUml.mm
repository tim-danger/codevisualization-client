sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setSelectedGuardians(selectedGuardians) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.selectedGuardians = selectedGuardians
deactivate GuardianBean
