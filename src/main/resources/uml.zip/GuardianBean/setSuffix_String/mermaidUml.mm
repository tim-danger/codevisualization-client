sequenceDiagram
participant Caller
participant GuardianBean

Caller->>GuardianBean: setSuffix(suffix) : void
activate GuardianBean
GuardianBean->>GuardianBean: this.suffix = suffix
deactivate GuardianBean
