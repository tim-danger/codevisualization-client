sequenceDiagram
participant Caller
participant GuardianBean
participant AdminBean
participant Logger
participant Guardian
participant Student
participant EntityManager

Caller->>GuardianBean: submit(student) : String
activate GuardianBean
GuardianBean->>AdminBean: this.guardian = adminBean.createGuardian(firstName, middleName, lastName, nickname, suffix, email, homePhone, mobilePhone, student)
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.createGuardian(9 args): Persisting new guardian.") : void
activate Logger
deactivate Logger
AdminBean->>Guardian: guardian = new Guardian() : Guardian
activate Guardian
Guardian->>AdminBean: guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setFirstName(firstName) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setMiddleName(middleName) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setLastName(lastName) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setNickname(nickname) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setSuffix(suffix) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setEmail(email) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setHomePhone(homePhone) : void
activate Guardian
deactivate Guardian
AdminBean->>Guardian: guardian.setMobilePhone(mobilePhone) : void
activate Guardian
deactivate Guardian
AdminBean->>Student: student.getGuardians().add(guardian) : void
activate Student
deactivate Student
AdminBean->>Guardian: guardian.getStudents().add(student) : void
activate Guardian
deactivate Guardian
AdminBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>EntityManager: em.persist(guardian) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return guardian;
AdminBean->>GuardianBean: this.guardian
deactivate AdminBean
GuardianBean->>Caller: return "createdGuardian";
deactivate GuardianBean
