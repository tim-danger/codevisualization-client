sequenceDiagram
participant Caller
participant GuardianConverter

Caller->>GuardianConverter: getAsObject(context, component, value) : Object
activate GuardianConverter
alt value.isEmpty()
GuardianConverter->>Caller: return null;
end
GuardianConverter->>Caller: return this.getViewMap(context).get(value);
deactivate GuardianConverter
