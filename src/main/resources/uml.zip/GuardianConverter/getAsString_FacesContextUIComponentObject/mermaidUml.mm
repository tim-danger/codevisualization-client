sequenceDiagram
participant Caller
participant GuardianConverter
participant Guardian
participant String

Caller->>GuardianConverter: getAsString(context, component, object) : String
activate GuardianConverter
alt object == null
GuardianConverter->>Caller: return "";
end
GuardianConverter->>GuardianConverter: Guardian guardian = (Guardian) object
GuardianConverter->>Guardian: id = guardian.getId() : Long
activate Guardian
Guardian->>GuardianConverter: id
deactivate Guardian
alt id != null
GuardianConverter->>String: stringId = String.valueOf(id.longValue()) : String
activate String
String->>GuardianConverter: stringId
deactivate String
GuardianConverter->>GuardianConverter: this.getViewMap(context).put(stringId, object) : void
activate GuardianConverter
deactivate GuardianConverter
GuardianConverter->>Caller: return stringId;
else
GuardianConverter->>Caller: return "0";
end
deactivate GuardianConverter
