sequenceDiagram
participant Caller
participant IOrderHandler

Caller->>IOrderHandler: onNewOrder(event) : void
activate IOrderHandler
deactivate IOrderHandler
