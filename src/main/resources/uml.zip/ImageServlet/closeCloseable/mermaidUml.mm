sequenceDiagram
participant Caller
participant ImageServlet
participant Closeable
participant Logger

Caller->>ImageServlet: close(resource) : void
activate ImageServlet
alt resource != null
opt try
ImageServlet->>Closeable: resource.close() : void
activate Closeable
deactivate Closeable
opt catch IOException e
ImageServlet->>Logger: logger.log(Level.SEVERE, "Problems during image resource manipulation. {0}", e.getMessage()) : void
activate Logger
deactivate Logger
end
end
end
deactivate ImageServlet
