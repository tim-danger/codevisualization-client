sequenceDiagram
participant Caller
participant ImageServlet
participant HttpServletRequest
participant HttpServletResponse
participant ProductBean
participant ByteArrayInputStream
participant BufferedOutputStream

Caller->>ImageServlet: doGet(request, response) : void
activate ImageServlet
ImageServlet->>HttpServletRequest: requestedImage = request.getParameter("id") : String
activate HttpServletRequest
HttpServletRequest->>ImageServlet: requestedImage
deactivate HttpServletRequest
alt requestedImage == null
ImageServlet->>HttpServletResponse: response.sendError(HttpServletResponse.SC_NOT_FOUND) : void
activate HttpServletResponse
deactivate HttpServletResponse
ImageServlet->>Caller: return;
end
ImageServlet->>ProductBean: p = productBean.find(Integer.parseInt(requestedImage)) : Product
activate ProductBean
ProductBean->>ImageServlet: p
deactivate ProductBean
alt (p == null) || (p.getImgSrc() == null)
ImageServlet->>HttpServletResponse: response.sendError(HttpServletResponse.SC_NOT_FOUND) : void
activate HttpServletResponse
deactivate HttpServletResponse
else
ImageServlet->>HttpServletResponse: response.reset() : void
activate HttpServletResponse
deactivate HttpServletResponse
ImageServlet->>HttpServletResponse: response.setBufferSize(DEFAULT_BUFFER_SIZE) : void
activate HttpServletResponse
deactivate HttpServletResponse
ImageServlet->>HttpServletResponse: response.setHeader("Content-Length", String.valueOf(p.getImgSrc().length)) : void
activate HttpServletResponse
deactivate HttpServletResponse
ImageServlet->>HttpServletResponse: response.setHeader("Content-Disposition", "inline; filename=\"" + p.getName() + "\"") : void
activate HttpServletResponse
deactivate HttpServletResponse
ImageServlet->>ImageServlet: ByteArrayInputStream byteInputStream = null
ImageServlet->>ImageServlet: BufferedOutputStream output = null
opt try
ImageServlet->>ByteArrayInputStream: byteInputStream = new ByteArrayInputStream(p.getImgSrc()) : ByteArrayInputStream
activate ByteArrayInputStream
ByteArrayInputStream->>ImageServlet: byteInputStream
deactivate ByteArrayInputStream
ImageServlet->>BufferedOutputStream: output = new BufferedOutputStream(response.getOutputStream(), DEFAULT_BUFFER_SIZE) : BufferedOutputStream
activate BufferedOutputStream
BufferedOutputStream->>ImageServlet: output
deactivate BufferedOutputStream
ImageServlet->>ImageServlet: byte[] buffer = new byte[DEFAULT_BUFFER_SIZE]
ImageServlet->>ImageServlet: int length
loop while (length = byteInputStream.read(buffer)) > 0
ImageServlet->>BufferedOutputStream: output.write(buffer, 0, length) : void
activate BufferedOutputStream
deactivate BufferedOutputStream
end
end
end
deactivate ImageServlet
