sequenceDiagram
participant Caller
participant ImageServlet

Caller->>ImageServlet: init() : void
activate ImageServlet
deactivate ImageServlet
