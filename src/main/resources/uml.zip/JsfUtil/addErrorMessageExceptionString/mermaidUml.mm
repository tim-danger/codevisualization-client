sequenceDiagram
participant Caller
participant JsfUtil
participant Exception
participant FacesMessage
participant FacesContext

Caller->>JsfUtil: addErrorMessage(ex, defaultMsg) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
