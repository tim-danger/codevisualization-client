sequenceDiagram
participant Caller
participant JsfUtil
participant FacesMessage
participant FacesContext

Caller->>JsfUtil: addErrorMessages(messages) : void
activate JsfUtil
loop for String message : messages
JsfUtil->>JsfUtil: addErrorMessage(message) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
end
deactivate JsfUtil
