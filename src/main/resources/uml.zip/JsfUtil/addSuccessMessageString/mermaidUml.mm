sequenceDiagram
participant Caller
participant JsfUtil
participant FacesMessage
participant FacesContext

Caller->>JsfUtil: addSuccessMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
