sequenceDiagram
participant Caller
participant JsfUtil

Caller->>JsfUtil: getObjectFromRequestParameter(reqParamName, converter, component) : Object
activate JsfUtil
JsfUtil->>JsfUtil: theId = JsfUtil.getRequestParameter(reqParamName) : String
activate JsfUtil
JsfUtil->>JsfUtil: return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(key);
JsfUtil->>JsfUtil: theId
deactivate JsfUtil
JsfUtil->>Caller: return converter.getAsObject(FacesContext.getCurrentInstance(), component, theId);
deactivate JsfUtil
