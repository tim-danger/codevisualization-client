sequenceDiagram
participant Caller
participant JsfUtil

Caller->>JsfUtil: getRequestParameter(key) : String
activate JsfUtil
JsfUtil->>Caller: return FacesContext.getCurrentInstance().getExternalContext().getRequestParameterMap().get(key);
deactivate JsfUtil
