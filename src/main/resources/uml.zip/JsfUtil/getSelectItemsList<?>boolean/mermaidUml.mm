sequenceDiagram
participant Caller
participant JsfUtil
participant int
participant List
participant SelectItem

Caller->>JsfUtil: getSelectItems(entities, selectOne) : SelectItem[]
activate JsfUtil
alt selectOne
JsfUtil->>int: size = entities.size() + 1 : int
activate int
int->>JsfUtil: size
deactivate int
else
JsfUtil->>List: size = entities.size() : int
activate List
List->>JsfUtil: size
deactivate List
end
JsfUtil->>JsfUtil: SelectItem[] items = new SelectItem[size]
JsfUtil->>JsfUtil: int i = 0
alt selectOne
JsfUtil->>SelectItem: items[0] = new SelectItem("", "---") : SelectItem
activate SelectItem
SelectItem->>JsfUtil: items[0]
deactivate SelectItem
JsfUtil->>JsfUtil: i++
end
loop for Object x : entities
JsfUtil->>SelectItem: items[i++] = new SelectItem(x, x.toString()) : SelectItem
activate SelectItem
SelectItem->>JsfUtil: items[i++]
deactivate SelectItem
end
JsfUtil->>Caller: return items;
deactivate JsfUtil
