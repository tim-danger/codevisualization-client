sequenceDiagram
participant Caller
participant LocaleBean

Caller->>LocaleBean: getLanguage() : String
activate LocaleBean
LocaleBean->>Caller: return locale.getLanguage();
deactivate LocaleBean
