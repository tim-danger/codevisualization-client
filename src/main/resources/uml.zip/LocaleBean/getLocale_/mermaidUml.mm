sequenceDiagram
participant Caller
participant LocaleBean

Caller->>LocaleBean: getLocale() : Locale
activate LocaleBean
LocaleBean->>Caller: return locale;
deactivate LocaleBean
