sequenceDiagram
participant Caller
participant LocaleBean
participant Locale
participant FacesContext

Caller->>LocaleBean: setLanguage(language) : void
activate LocaleBean
LocaleBean->>Locale: locale = new Locale(language) : Locale
activate Locale
Locale->>LocaleBean: locale
deactivate Locale
LocaleBean->>FacesContext: FacesContext.getCurrentInstance().getViewRoot().setLocale(locale) : void
activate FacesContext
deactivate FacesContext
deactivate LocaleBean
