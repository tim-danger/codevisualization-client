sequenceDiagram
participant Caller
participant MD5Util
participant MessageDigest
participant BigInteger

Caller->>MD5Util: generateMD5(value) : String
activate MD5Util
opt try
MD5Util->>MessageDigest: md = MessageDigest.getInstance("MD5") : MessageDigest
activate MessageDigest
MessageDigest->>MD5Util: md
deactivate MessageDigest
MD5Util->>MessageDigest: messageDigest = md.digest(value.getBytes()) : byte[]
activate MessageDigest
MessageDigest->>MD5Util: messageDigest
deactivate MessageDigest
MD5Util->>BigInteger: number = new BigInteger(1, messageDigest) : BigInteger
activate BigInteger
BigInteger->>MD5Util: number
deactivate BigInteger
MD5Util->>MD5Util: return number.toString(16);
opt catch NoSuchAlgorithmException nsae
MD5Util->>MD5Util: return null;
end
end
deactivate MD5Util
