sequenceDiagram
participant Caller
participant OrderBean

Caller->>OrderBean: getEntityManager() : EntityManager
activate OrderBean
OrderBean->>Caller: return em;
deactivate OrderBean
