sequenceDiagram
participant Caller
participant OrderBean
participant Query

Caller->>OrderBean: getOrderByCustomerId(id) : List<CustomerOrder>
activate OrderBean
OrderBean->>OrderBean: createNamedQuery = getEntityManager().createNamedQuery("CustomerOrder.findByCustomerId") : Query
activate OrderBean
OrderBean->>OrderBean: createNamedQuery
deactivate OrderBean
OrderBean->>Query: createNamedQuery.setParameter("id", id) : void
activate Query
deactivate Query
OrderBean->>Caller: return createNamedQuery.getResultList();
deactivate OrderBean
