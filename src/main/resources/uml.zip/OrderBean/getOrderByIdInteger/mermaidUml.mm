sequenceDiagram
participant Caller
participant OrderBean
participant Query

Caller->>OrderBean: getOrderById(id) : CustomerOrder
activate OrderBean
OrderBean->>OrderBean: createNamedQuery = getEntityManager().createNamedQuery("CustomerOrder.findById") : Query
activate OrderBean
OrderBean->>OrderBean: createNamedQuery
deactivate OrderBean
OrderBean->>Query: createNamedQuery.setParameter("id", id) : void
activate Query
deactivate Query
OrderBean->>Caller: return (CustomerOrder) createNamedQuery.getSingleResult();
deactivate OrderBean
