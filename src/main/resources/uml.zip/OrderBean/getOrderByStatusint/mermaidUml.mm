sequenceDiagram
participant Caller
participant OrderBean
participant OrderStatusBean
participant Query

Caller->>OrderBean: getOrderByStatus(status) : List<CustomerOrder>
activate OrderBean
OrderBean->>OrderBean: createNamedQuery = getEntityManager().createNamedQuery("CustomerOrder.findByStatus") : Query
activate OrderBean
OrderBean->>OrderBean: createNamedQuery
deactivate OrderBean
OrderBean->>OrderStatusBean: result = statusBean.find(status) : OrderStatus
activate OrderStatusBean
OrderStatusBean->>OrderBean: result
deactivate OrderStatusBean
OrderBean->>Query: createNamedQuery.setParameter("status", result.getStatus()) : void
activate Query
deactivate Query
OrderBean->>Query: orders = createNamedQuery.getResultList() : List<CustomerOrder>
activate Query
Query->>OrderBean: orders
deactivate Query
OrderBean->>Caller: return orders;
deactivate OrderBean
