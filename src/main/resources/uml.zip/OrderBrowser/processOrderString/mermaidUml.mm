sequenceDiagram
participant Caller
participant OrderBrowser
participant Logger
participant JMSContext
participant JMSConsumer

Caller->>OrderBrowser: processOrder(OrderMessageID) : CustomerOrder
activate OrderBrowser
OrderBrowser->>Logger: logger.log(Level.INFO, "Processing Order {0}", OrderMessageID) : void
activate Logger
deactivate Logger
OrderBrowser->>JMSContext: consumer = context.createConsumer(queue, "JMSMessageID='" + OrderMessageID + "'") : JMSConsumer
activate JMSContext
JMSContext->>OrderBrowser: consumer
deactivate JMSContext
OrderBrowser->>JMSConsumer: order = consumer.receiveBody(CustomerOrder.class, 1) : CustomerOrder
activate JMSConsumer
JMSConsumer->>OrderBrowser: order
deactivate JMSConsumer
OrderBrowser->>Caller: return order;
deactivate OrderBrowser
