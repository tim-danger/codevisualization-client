sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: equals(object) : boolean
activate OrderDetail
alt !(object instanceof OrderDetail)
OrderDetail->>Caller: return false;
end
OrderDetail->>OrderDetail: OrderDetail other = (OrderDetail) object
alt (this.orderDetailPK == null && other.orderDetailPK != null) || (this.orderDetailPK != null && !this.orderDetailPK.equals(other.orderDetailPK))
OrderDetail->>Caller: return false;
end
OrderDetail->>Caller: return true;
deactivate OrderDetail
