sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: getCustomerOrder() : CustomerOrder
activate OrderDetail
OrderDetail->>Caller: return customerOrder;
deactivate OrderDetail
