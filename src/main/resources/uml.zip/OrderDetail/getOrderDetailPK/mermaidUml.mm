sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: getOrderDetailPK() : OrderDetailPK
activate OrderDetail
OrderDetail->>Caller: return orderDetailPK;
deactivate OrderDetail
