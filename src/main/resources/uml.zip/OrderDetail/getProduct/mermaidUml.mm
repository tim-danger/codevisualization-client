sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: getProduct() : Product
activate OrderDetail
OrderDetail->>Caller: return product;
deactivate OrderDetail
