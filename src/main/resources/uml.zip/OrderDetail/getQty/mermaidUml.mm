sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: getQty() : int
activate OrderDetail
OrderDetail->>Caller: return qty;
deactivate OrderDetail
