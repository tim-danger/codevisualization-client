sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: hashCode() : int
activate OrderDetail
OrderDetail->>OrderDetail: int hash = 0
OrderDetail->>OrderDetail: hash += (orderDetailPK != null ? orderDetailPK.hashCode() : 0)
OrderDetail->>Caller: return hash;
deactivate OrderDetail
