sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: setCustomerOrder(customerOrder) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.customerOrder = customerOrder
deactivate OrderDetail
