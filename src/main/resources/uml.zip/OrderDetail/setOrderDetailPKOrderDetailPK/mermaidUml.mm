sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: setOrderDetailPK(orderDetailPK) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.orderDetailPK = orderDetailPK
deactivate OrderDetail
