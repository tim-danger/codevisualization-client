sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: setProduct(product) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.product = product
deactivate OrderDetail
