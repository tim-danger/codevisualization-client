sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: setQty(qty) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.qty = qty
deactivate OrderDetail
