sequenceDiagram
participant Caller
participant OrderDetail

Caller->>OrderDetail: toString() : String
activate OrderDetail
OrderDetail->>Caller: return "com.forest.entity.OrderDetail[orderDetailPK=" + orderDetailPK + "]";
deactivate OrderDetail
