sequenceDiagram
participant Caller
participant OrderDetailBean

Caller->>OrderDetailBean: findOrderDetailByOrder(orderId) : List<OrderDetail>
activate OrderDetailBean
OrderDetailBean->>OrderDetailBean: details = getEntityManager().createNamedQuery("OrderDetail.findByOrderId").setParameter("orderId", orderId).getResultList() : List<OrderDetail>
activate OrderDetailBean
OrderDetailBean->>OrderDetailBean: details
deactivate OrderDetailBean
OrderDetailBean->>Caller: return details;
deactivate OrderDetailBean
