sequenceDiagram
participant Caller
participant OrderDetailBean

Caller->>OrderDetailBean: getEntityManager() : EntityManager
activate OrderDetailBean
OrderDetailBean->>Caller: return em;
deactivate OrderDetailBean
