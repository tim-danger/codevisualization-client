sequenceDiagram
participant Caller
participant OrderDetailController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>OrderDetailController: destroyAndView() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: performDestroy() : void
activate OrderDetailController
opt try
OrderDetailController->>OrderDetailController: getFacade().remove(current) : void
activate OrderDetailController
deactivate OrderDetailController
OrderDetailController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("OrderDetailDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
OrderDetailController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate OrderDetailController
OrderDetailController->>OrderDetailController: recreateModel() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: items = null
deactivate OrderDetailController
OrderDetailController->>OrderDetailController: updateCurrentItem() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: count = getFacade().count() : int
activate OrderDetailController
OrderDetailController->>OrderDetailController: count
deactivate OrderDetailController
alt selectedItemIndex >= count
OrderDetailController->>OrderDetailController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
OrderDetailController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
OrderDetailController->>OrderDetailController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate OrderDetailController
OrderDetailController->>OrderDetailController: current
deactivate OrderDetailController
end
deactivate OrderDetailController
alt selectedItemIndex >= 0
OrderDetailController->>Caller: return PageNavigation.VIEW;
else
OrderDetailController->>OrderDetailController: recreateModel() : void
activate OrderDetailController
deactivate OrderDetailController
OrderDetailController->>Caller: return PageNavigation.LIST;
end
deactivate OrderDetailController
