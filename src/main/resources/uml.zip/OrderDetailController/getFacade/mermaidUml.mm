sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: getFacade() : OrderDetailBean
activate OrderDetailController
OrderDetailController->>Caller: return ejbFacade;
deactivate OrderDetailController
