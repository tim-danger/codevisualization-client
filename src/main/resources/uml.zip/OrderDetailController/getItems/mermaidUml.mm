sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: getItems() : DataModel
activate OrderDetailController
alt items == null
OrderDetailController->>OrderDetailController: items = getPagination().createPageDataModel() : DataModel
activate OrderDetailController
OrderDetailController->>OrderDetailController: items
deactivate OrderDetailController
end
OrderDetailController->>Caller: return items;
deactivate OrderDetailController
