sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: getItemsAvailableSelectMany() : SelectItem[]
activate OrderDetailController
OrderDetailController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate OrderDetailController
