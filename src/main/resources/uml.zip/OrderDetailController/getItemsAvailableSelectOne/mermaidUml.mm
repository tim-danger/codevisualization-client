sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: getItemsAvailableSelectOne() : SelectItem[]
activate OrderDetailController
OrderDetailController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate OrderDetailController
