sequenceDiagram
participant Caller
participant OrderDetailController
participant AbstractPaginationHelper

Caller->>OrderDetailController: getPagination() : AbstractPaginationHelper
activate OrderDetailController
alt pagination == null
OrderDetailController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(10) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         int orderId = Integer.valueOf(JsfUtil.getRequestParameter("orderId"));         //ListDataModel(getFacade().findRange(new int[]{getPageFirstItem(), getPageFirstItem()+getPageSize()}));         return new ListDataModel(getFacade().findOrderDetailByOrder(orderId));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>OrderDetailController: pagination
deactivate AbstractPaginationHelper
end
OrderDetailController->>Caller: return pagination;
deactivate OrderDetailController
