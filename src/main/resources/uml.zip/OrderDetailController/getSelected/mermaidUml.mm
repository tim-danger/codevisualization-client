sequenceDiagram
participant Caller
participant OrderDetailController
participant OrderDetail

Caller->>OrderDetailController: getSelected() : OrderDetail
activate OrderDetailController
alt current == null
OrderDetailController->>OrderDetail: current = new OrderDetail() : OrderDetail
activate OrderDetail
OrderDetail->>OrderDetailController: current
deactivate OrderDetail
OrderDetailController->>OrderDetailController: selectedItemIndex = -1
end
OrderDetailController->>Caller: return current;
deactivate OrderDetailController
