sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: next() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: getPagination().nextPage() : void
activate OrderDetailController
deactivate OrderDetailController
OrderDetailController->>OrderDetailController: recreateModel() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: items = null
deactivate OrderDetailController
OrderDetailController->>Caller: return PageNavigation.LIST;
deactivate OrderDetailController
