sequenceDiagram
participant Caller
participant OrderDetailController
participant OrderDetail

Caller->>OrderDetailController: prepareCreate() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetail: current = new OrderDetail() : OrderDetail
activate OrderDetail
OrderDetail->>OrderDetailController: current
deactivate OrderDetail
OrderDetailController->>OrderDetailController: selectedItemIndex = -1
OrderDetailController->>Caller: return PageNavigation.CREATE;
deactivate OrderDetailController
