sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: prepareEdit() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: current = (OrderDetail) getItems().getRowData()
OrderDetailController->>OrderDetailController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
OrderDetailController->>Caller: return PageNavigation.EDIT;
deactivate OrderDetailController
