sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: prepareList() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: recreateModel() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: items = null
deactivate OrderDetailController
OrderDetailController->>Caller: return PageNavigation.LIST;
deactivate OrderDetailController
