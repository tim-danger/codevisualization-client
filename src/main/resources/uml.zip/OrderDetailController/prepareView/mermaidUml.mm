sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: prepareView() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: current = (OrderDetail) getItems().getRowData()
OrderDetailController->>OrderDetailController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
OrderDetailController->>Caller: return PageNavigation.VIEW;
deactivate OrderDetailController
