sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: previous() : PageNavigation
activate OrderDetailController
OrderDetailController->>OrderDetailController: getPagination().previousPage() : void
activate OrderDetailController
deactivate OrderDetailController
OrderDetailController->>OrderDetailController: recreateModel() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: items = null
deactivate OrderDetailController
OrderDetailController->>Caller: return PageNavigation.LIST;
deactivate OrderDetailController
