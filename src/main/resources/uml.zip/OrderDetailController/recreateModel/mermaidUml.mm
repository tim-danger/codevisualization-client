sequenceDiagram
participant Caller
participant OrderDetailController

Caller->>OrderDetailController: recreateModel() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: items = null
deactivate OrderDetailController
