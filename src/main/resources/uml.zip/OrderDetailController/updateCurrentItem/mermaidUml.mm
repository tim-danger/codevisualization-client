sequenceDiagram
participant Caller
participant OrderDetailController
participant AbstractPaginationHelper

Caller->>OrderDetailController: updateCurrentItem() : void
activate OrderDetailController
OrderDetailController->>OrderDetailController: count = getFacade().count() : int
activate OrderDetailController
OrderDetailController->>OrderDetailController: count
deactivate OrderDetailController
alt selectedItemIndex >= count
OrderDetailController->>OrderDetailController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
OrderDetailController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
OrderDetailController->>OrderDetailController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate OrderDetailController
OrderDetailController->>OrderDetailController: current
deactivate OrderDetailController
end
deactivate OrderDetailController
