sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: equals(object) : boolean
activate OrderDetailPK
alt !(object instanceof OrderDetailPK)
OrderDetailPK->>Caller: return false;
end
OrderDetailPK->>OrderDetailPK: OrderDetailPK other = (OrderDetailPK) object
alt this.orderId != other.orderId
OrderDetailPK->>Caller: return false;
end
alt this.productId != other.productId
OrderDetailPK->>Caller: return false;
end
OrderDetailPK->>Caller: return true;
deactivate OrderDetailPK
