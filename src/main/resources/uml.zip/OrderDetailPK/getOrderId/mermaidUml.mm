sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: getOrderId() : int
activate OrderDetailPK
OrderDetailPK->>Caller: return orderId;
deactivate OrderDetailPK
