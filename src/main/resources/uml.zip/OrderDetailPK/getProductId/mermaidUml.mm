sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: getProductId() : int
activate OrderDetailPK
OrderDetailPK->>Caller: return productId;
deactivate OrderDetailPK
