sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: hashCode() : int
activate OrderDetailPK
OrderDetailPK->>OrderDetailPK: int hash = 0
OrderDetailPK->>OrderDetailPK: hash += (int) orderId
OrderDetailPK->>OrderDetailPK: hash += (int) productId
OrderDetailPK->>Caller: return hash;
deactivate OrderDetailPK
