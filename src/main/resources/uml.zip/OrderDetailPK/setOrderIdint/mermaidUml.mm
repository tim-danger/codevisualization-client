sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: setOrderId(orderId) : void
activate OrderDetailPK
OrderDetailPK->>OrderDetailPK: this.orderId = orderId
deactivate OrderDetailPK
