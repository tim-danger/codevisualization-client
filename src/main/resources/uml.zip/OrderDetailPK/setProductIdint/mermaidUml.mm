sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: setProductId(productId) : void
activate OrderDetailPK
OrderDetailPK->>OrderDetailPK: this.productId = productId
deactivate OrderDetailPK
