sequenceDiagram
participant Caller
participant OrderDetailPK

Caller->>OrderDetailPK: toString() : String
activate OrderDetailPK
OrderDetailPK->>Caller: return "com.forest.entity.OrderDetailPK[orderId=" + orderId + ", productId=" + productId + "]";
deactivate OrderDetailPK
