sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: getAmount() : double
activate OrderEvent
OrderEvent->>Caller: return amount;
deactivate OrderEvent
