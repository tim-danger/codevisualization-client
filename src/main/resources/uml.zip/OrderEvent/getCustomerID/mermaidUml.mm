sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: getCustomerID() : int
activate OrderEvent
OrderEvent->>Caller: return customerID;
deactivate OrderEvent
