sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: getDateCreated() : Date
activate OrderEvent
OrderEvent->>Caller: return dateCreated;
deactivate OrderEvent
