sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: getOrderID() : int
activate OrderEvent
OrderEvent->>Caller: return orderID;
deactivate OrderEvent
