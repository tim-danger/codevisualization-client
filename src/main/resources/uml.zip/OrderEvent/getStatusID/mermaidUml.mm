sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: getStatusID() : int
activate OrderEvent
OrderEvent->>Caller: return statusID;
deactivate OrderEvent
