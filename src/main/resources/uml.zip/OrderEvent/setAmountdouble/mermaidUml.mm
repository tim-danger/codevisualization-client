sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: setAmount(amount) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.amount = amount
deactivate OrderEvent
