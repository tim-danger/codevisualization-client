sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: setCustomerID(customerID) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.customerID = customerID
deactivate OrderEvent
