sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: setDateCreated(dateCreated) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.dateCreated = dateCreated
deactivate OrderEvent
