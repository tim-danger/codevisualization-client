sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: setOrderID(orderID) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.orderID = orderID
deactivate OrderEvent
