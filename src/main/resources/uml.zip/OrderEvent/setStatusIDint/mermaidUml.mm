sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: setStatusID(statusID) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.statusID = statusID
deactivate OrderEvent
