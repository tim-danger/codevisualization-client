sequenceDiagram
participant Caller
participant OrderEvent

Caller->>OrderEvent: toString() : String
activate OrderEvent
OrderEvent->>Caller: return "[OrderEvent] " + getCustomerID();
deactivate OrderEvent
