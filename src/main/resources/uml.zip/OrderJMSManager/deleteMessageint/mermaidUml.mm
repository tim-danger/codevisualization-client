sequenceDiagram
participant Caller
participant OrderJMSManager
participant JMSContext
participant JMSConsumer
participant Logger

Caller->>OrderJMSManager: deleteMessage(orderID) : void
activate OrderJMSManager
OrderJMSManager->>JMSContext: consumer = context.createConsumer(queue, "OrderID='" + orderID + "'") : JMSConsumer
activate JMSContext
JMSContext->>OrderJMSManager: consumer
deactivate JMSContext
OrderJMSManager->>JMSConsumer: order = consumer.receiveBody(CustomerOrder.class, 1) : CustomerOrder
activate JMSConsumer
JMSConsumer->>OrderJMSManager: order
deactivate JMSConsumer
alt order != null
OrderJMSManager->>Logger: logger.log(Level.INFO, "Order {0} removed from queue.", order.getId()) : void
activate Logger
deactivate Logger
else
OrderJMSManager->>Logger: logger.log(Level.SEVERE, "Order {0} was not removed from queue!", orderID) : void
activate Logger
deactivate Logger
OrderJMSManager->>Caller: throw new Exception("Order not removed from queue")
end
deactivate OrderJMSManager
