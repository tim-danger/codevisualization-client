sequenceDiagram
participant Caller
participant OrderJMSManager
participant JMSContext
participant ObjectMessage
participant Logger

Caller->>OrderJMSManager: sendMessage(customerOrder) : void
activate OrderJMSManager
OrderJMSManager->>JMSContext: msgObj = context.createObjectMessage() : ObjectMessage
activate JMSContext
JMSContext->>OrderJMSManager: msgObj
deactivate JMSContext
opt try
OrderJMSManager->>ObjectMessage: msgObj.setObject(customerOrder) : void
activate ObjectMessage
deactivate ObjectMessage
OrderJMSManager->>ObjectMessage: msgObj.setStringProperty("OrderID", String.valueOf(customerOrder.getId())) : void
activate ObjectMessage
deactivate ObjectMessage
OrderJMSManager->>JMSContext: context.createProducer().send(queue, msgObj) : void
activate JMSContext
deactivate JMSContext
opt catch JMSException ex
OrderJMSManager->>Logger: logger.log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
end
end
deactivate OrderJMSManager
