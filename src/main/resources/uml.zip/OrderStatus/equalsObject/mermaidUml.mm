sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: equals(object) : boolean
activate OrderStatus
alt !(object instanceof OrderStatus)
OrderStatus->>Caller: return false;
end
OrderStatus->>OrderStatus: OrderStatus other = (OrderStatus) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
OrderStatus->>Caller: return false;
end
OrderStatus->>Caller: return true;
deactivate OrderStatus
