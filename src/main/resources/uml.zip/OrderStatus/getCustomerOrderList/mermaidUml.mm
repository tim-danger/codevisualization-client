sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: getCustomerOrderList() : List<CustomerOrder>
activate OrderStatus
OrderStatus->>Caller: return customerOrderList;
deactivate OrderStatus
