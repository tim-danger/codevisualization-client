sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: getDescription() : String
activate OrderStatus
OrderStatus->>Caller: return description;
deactivate OrderStatus
