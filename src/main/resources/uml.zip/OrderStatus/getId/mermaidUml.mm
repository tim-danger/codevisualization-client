sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: getId() : Integer
activate OrderStatus
OrderStatus->>Caller: return id;
deactivate OrderStatus
