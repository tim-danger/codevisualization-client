sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: getStatus() : String
activate OrderStatus
OrderStatus->>Caller: return status;
deactivate OrderStatus
