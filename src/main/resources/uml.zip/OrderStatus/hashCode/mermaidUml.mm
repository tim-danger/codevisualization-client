sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: hashCode() : int
activate OrderStatus
OrderStatus->>OrderStatus: int hash = 0
OrderStatus->>OrderStatus: hash += (id != null ? id.hashCode() : 0)
OrderStatus->>Caller: return hash;
deactivate OrderStatus
