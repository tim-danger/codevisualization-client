sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: setCustomerOrderList(customerOrderList) : void
activate OrderStatus
OrderStatus->>OrderStatus: this.customerOrderList = customerOrderList
deactivate OrderStatus
