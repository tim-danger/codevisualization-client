sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: setDescription(description) : void
activate OrderStatus
OrderStatus->>OrderStatus: this.description = description
deactivate OrderStatus
