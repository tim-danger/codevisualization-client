sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: setId(id) : void
activate OrderStatus
OrderStatus->>OrderStatus: this.id = id
deactivate OrderStatus
