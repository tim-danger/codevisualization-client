sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: setStatus(status) : void
activate OrderStatus
OrderStatus->>OrderStatus: this.status = status
deactivate OrderStatus
