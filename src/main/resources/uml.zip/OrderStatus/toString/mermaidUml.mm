sequenceDiagram
participant Caller
participant OrderStatus

Caller->>OrderStatus: toString() : String
activate OrderStatus
OrderStatus->>Caller: return "com.forest.entity.OrderStatus[id=" + id + "]";
deactivate OrderStatus
