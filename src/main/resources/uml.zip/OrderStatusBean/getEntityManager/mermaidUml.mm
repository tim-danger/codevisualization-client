sequenceDiagram
participant Caller
participant OrderStatusBean

Caller->>OrderStatusBean: getEntityManager() : EntityManager
activate OrderStatusBean
OrderStatusBean->>Caller: return em;
deactivate OrderStatusBean
