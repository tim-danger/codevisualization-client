sequenceDiagram
participant Caller
participant OrderStatusBean
participant Query

Caller->>OrderStatusBean: getStatusByName(status) : OrderStatus
activate OrderStatusBean
OrderStatusBean->>OrderStatusBean: createNamedQuery = getEntityManager().createNamedQuery("OrderStatus.findByStatus") : Query
activate OrderStatusBean
OrderStatusBean->>OrderStatusBean: createNamedQuery
deactivate OrderStatusBean
OrderStatusBean->>Query: createNamedQuery.setParameter("status", status) : void
activate Query
deactivate Query
OrderStatusBean->>Caller: return (OrderStatus) createNamedQuery.getSingleResult();
deactivate OrderStatusBean
