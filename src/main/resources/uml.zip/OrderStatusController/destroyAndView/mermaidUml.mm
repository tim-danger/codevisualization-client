sequenceDiagram
participant Caller
participant OrderStatusController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>OrderStatusController: destroyAndView() : PageNavigation
activate OrderStatusController
OrderStatusController->>OrderStatusController: performDestroy() : void
activate OrderStatusController
opt try
OrderStatusController->>OrderStatusController: getFacade().remove(current) : void
activate OrderStatusController
deactivate OrderStatusController
OrderStatusController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("OrderStatusDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
OrderStatusController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate OrderStatusController
OrderStatusController->>OrderStatusController: recreateModel() : void
activate OrderStatusController
OrderStatusController->>OrderStatusController: items = null
deactivate OrderStatusController
OrderStatusController->>OrderStatusController: updateCurrentItem() : void
activate OrderStatusController
OrderStatusController->>OrderStatusController: count = getFacade().count() : int
activate OrderStatusController
OrderStatusController->>OrderStatusController: count
deactivate OrderStatusController
alt selectedItemIndex >= count
OrderStatusController->>OrderStatusController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
OrderStatusController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
OrderStatusController->>OrderStatusController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate OrderStatusController
OrderStatusController->>OrderStatusController: current
deactivate OrderStatusController
end
deactivate OrderStatusController
alt selectedItemIndex >= 0
OrderStatusController->>Caller: return PageNavigation.VIEW;
else
OrderStatusController->>OrderStatusController: recreateModel() : void
activate OrderStatusController
deactivate OrderStatusController
OrderStatusController->>Caller: return PageNavigation.LIST;
end
deactivate OrderStatusController
