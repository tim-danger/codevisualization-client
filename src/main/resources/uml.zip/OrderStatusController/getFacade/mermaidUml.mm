sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: getFacade() : OrderStatusBean
activate OrderStatusController
OrderStatusController->>Caller: return ejbFacade;
deactivate OrderStatusController
