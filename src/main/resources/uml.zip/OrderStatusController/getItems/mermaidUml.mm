sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: getItems() : DataModel
activate OrderStatusController
alt items == null
OrderStatusController->>OrderStatusController: items = getPagination().createPageDataModel() : DataModel
activate OrderStatusController
OrderStatusController->>OrderStatusController: items
deactivate OrderStatusController
end
OrderStatusController->>Caller: return items;
deactivate OrderStatusController
