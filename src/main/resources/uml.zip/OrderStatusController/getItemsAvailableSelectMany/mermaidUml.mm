sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: getItemsAvailableSelectMany() : SelectItem[]
activate OrderStatusController
OrderStatusController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate OrderStatusController
