sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: getItemsAvailableSelectOne() : SelectItem[]
activate OrderStatusController
OrderStatusController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate OrderStatusController
