sequenceDiagram
participant Caller
participant OrderStatusController
participant AbstractPaginationHelper

Caller->>OrderStatusController: getPagination() : AbstractPaginationHelper
activate OrderStatusController
alt pagination == null
OrderStatusController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(10) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>OrderStatusController: pagination
deactivate AbstractPaginationHelper
end
OrderStatusController->>Caller: return pagination;
deactivate OrderStatusController
