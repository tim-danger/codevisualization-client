sequenceDiagram
participant Caller
participant OrderStatusController
participant OrderStatus

Caller->>OrderStatusController: getSelected() : OrderStatus
activate OrderStatusController
alt current == null
OrderStatusController->>OrderStatus: current = new OrderStatus() : OrderStatus
activate OrderStatus
OrderStatus->>OrderStatusController: current
deactivate OrderStatus
OrderStatusController->>OrderStatusController: selectedItemIndex = -1
end
OrderStatusController->>Caller: return current;
deactivate OrderStatusController
