sequenceDiagram
participant Caller
participant OrderStatusController
participant OrderStatus

Caller->>OrderStatusController: prepareCreate() : PageNavigation
activate OrderStatusController
OrderStatusController->>OrderStatus: current = new OrderStatus() : OrderStatus
activate OrderStatus
OrderStatus->>OrderStatusController: current
deactivate OrderStatus
OrderStatusController->>OrderStatusController: selectedItemIndex = -1
OrderStatusController->>Caller: return PageNavigation.CREATE;
deactivate OrderStatusController
