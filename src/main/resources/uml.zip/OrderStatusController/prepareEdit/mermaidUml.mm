sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: prepareEdit() : PageNavigation
activate OrderStatusController
OrderStatusController->>OrderStatusController: current = (OrderStatus) getItems().getRowData()
OrderStatusController->>OrderStatusController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
OrderStatusController->>Caller: return PageNavigation.EDIT;
deactivate OrderStatusController
