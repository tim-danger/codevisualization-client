sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: previous() : PageNavigation
activate OrderStatusController
OrderStatusController->>OrderStatusController: getPagination().previousPage() : void
activate OrderStatusController
deactivate OrderStatusController
OrderStatusController->>OrderStatusController: recreateModel() : void
activate OrderStatusController
OrderStatusController->>OrderStatusController: items = null
deactivate OrderStatusController
OrderStatusController->>Caller: return PageNavigation.LIST;
deactivate OrderStatusController
