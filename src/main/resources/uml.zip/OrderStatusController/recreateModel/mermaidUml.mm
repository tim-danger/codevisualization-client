sequenceDiagram
participant Caller
participant OrderStatusController

Caller->>OrderStatusController: recreateModel() : void
activate OrderStatusController
OrderStatusController->>OrderStatusController: items = null
deactivate OrderStatusController
