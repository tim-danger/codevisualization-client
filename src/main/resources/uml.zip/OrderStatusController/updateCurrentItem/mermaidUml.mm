sequenceDiagram
participant Caller
participant OrderStatusController
participant AbstractPaginationHelper

Caller->>OrderStatusController: updateCurrentItem() : void
activate OrderStatusController
OrderStatusController->>OrderStatusController: count = getFacade().count() : int
activate OrderStatusController
OrderStatusController->>OrderStatusController: count
deactivate OrderStatusController
alt selectedItemIndex >= count
OrderStatusController->>OrderStatusController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
OrderStatusController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
OrderStatusController->>OrderStatusController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate OrderStatusController
OrderStatusController->>OrderStatusController: current
deactivate OrderStatusController
end
deactivate OrderStatusController
