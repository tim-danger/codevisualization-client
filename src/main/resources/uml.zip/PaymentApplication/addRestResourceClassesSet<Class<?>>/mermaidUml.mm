sequenceDiagram
participant Caller
participant PaymentApplication
participant Set

Caller->>PaymentApplication: addRestResourceClasses(resources) : void
activate PaymentApplication
PaymentApplication->>Set: resources.add(com.forest.payment.services.PaymentService.class) : void
activate Set
deactivate Set
deactivate PaymentApplication
