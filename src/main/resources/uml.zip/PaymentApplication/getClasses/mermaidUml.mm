sequenceDiagram
participant Caller
participant PaymentApplication
participant Set

Caller->>PaymentApplication: getClasses() : Set<Class<?>>
activate PaymentApplication
PaymentApplication->>Set: resources = new java.util.HashSet<>() : Set<Class<?>>
activate Set
Set->>PaymentApplication: resources
deactivate Set
PaymentApplication->>PaymentApplication: addRestResourceClasses(resources) : void
activate PaymentApplication
PaymentApplication->>Set: resources.add(com.forest.payment.services.PaymentService.class) : void
activate Set
deactivate Set
deactivate PaymentApplication
PaymentApplication->>Caller: return resources;
deactivate PaymentApplication
