sequenceDiagram
participant Caller
participant PaymentHandler
participant Logger
participant OrderBean
participant OrderStatusBean
participant CustomerOrder
participant EntityManager
participant Event

Caller->>PaymentHandler: onNewOrder(event) : void
activate PaymentHandler
PaymentHandler->>Logger: logger.log(Level.FINEST, "{0} Event being processed by PaymentHandler", Thread.currentThread().getName()) : void
activate Logger
deactivate Logger
alt processPayment(event)
PaymentHandler->>OrderBean: orderBean.setOrderStatus(event.getOrderID(), String.valueOf(OrderBean.Status.PENDING_PAYMENT.getStatus())) : void
activate OrderBean
OrderBean->>Logger: logger.log(Level.INFO, "Order id:{0} - Status:{1}", new Object[] { orderId, newStatus }) : void
activate Logger
deactivate Logger
opt try
OrderBean->>OrderBean: order = this.find(orderId) : CustomerOrder
activate OrderBean
OrderBean->>OrderBean: order
deactivate OrderBean
alt order != null
OrderBean->>Logger: logger.log(Level.FINEST, "Updating order {0} status to {1}", new Object[] { order.getId(), newStatus }) : void
activate Logger
deactivate Logger
OrderBean->>OrderStatusBean: oStatus = statusBean.find(new Integer(newStatus)) : OrderStatus
activate OrderStatusBean
OrderStatusBean->>OrderBean: oStatus
deactivate OrderStatusBean
OrderBean->>CustomerOrder: order.setOrderStatus(oStatus) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderStatus = orderStatus
deactivate CustomerOrder
OrderBean->>EntityManager: em.merge(order) : void
activate EntityManager
deactivate EntityManager
OrderBean->>Logger: logger.info("Order Updated!") : void
activate Logger
deactivate Logger
end
opt catch Exception ex
OrderBean->>Logger: logger.log(Level.SEVERE, ex.getMessage()) : void
activate Logger
deactivate Logger
end
end
deactivate OrderBean
PaymentHandler->>Logger: logger.info("Payment Approved") : void
activate Logger
deactivate Logger
PaymentHandler->>Event: eventManager.fire(event) : void
activate Event
deactivate Event
else
PaymentHandler->>OrderBean: orderBean.setOrderStatus(event.getOrderID(), String.valueOf(OrderBean.Status.CANCELLED_PAYMENT.getStatus())) : void
activate OrderBean
deactivate OrderBean
PaymentHandler->>Logger: logger.info("Payment Denied") : void
activate Logger
deactivate Logger
end
deactivate PaymentHandler
