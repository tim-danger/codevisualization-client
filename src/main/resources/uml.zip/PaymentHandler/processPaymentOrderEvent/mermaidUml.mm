sequenceDiagram
participant Caller
participant PaymentHandler
participant ClientBuilder
participant Client
participant Response
participant Logger

Caller->>PaymentHandler: processPayment(order) : boolean
activate PaymentHandler
PaymentHandler->>PaymentHandler: boolean success = false
PaymentHandler->>ClientBuilder: client = ClientBuilder.newClient() : Client
activate ClientBuilder
ClientBuilder->>PaymentHandler: client
deactivate ClientBuilder
PaymentHandler->>Client: client.register(new AuthClientRequestFilter("jack@example.com", "1234")) : void
activate Client
deactivate Client
PaymentHandler->>Client: resp = client.target(ENDPOINT).request(MediaType.APPLICATION_XML).post(Entity.entity(order, MediaType.APPLICATION_XML), Response.class) : Response
activate Client
Client->>PaymentHandler: resp
deactivate Client
PaymentHandler->>Response: status = resp.getStatus() : int
activate Response
Response->>PaymentHandler: status
deactivate Response
alt status == 200
PaymentHandler->>PaymentHandler: success = true
end
PaymentHandler->>Logger: logger.log(Level.INFO, "[PaymentHandler] Response status {0}", status) : void
activate Logger
deactivate Logger
PaymentHandler->>Client: client.close() : void
activate Client
deactivate Client
PaymentHandler->>Caller: return success;
deactivate PaymentHandler
