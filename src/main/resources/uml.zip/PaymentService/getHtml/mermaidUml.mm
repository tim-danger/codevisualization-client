sequenceDiagram
participant Caller
participant PaymentService

Caller->>PaymentService: getHtml() : String
activate PaymentService
PaymentService->>Caller: return "PaymentService";
deactivate PaymentService
