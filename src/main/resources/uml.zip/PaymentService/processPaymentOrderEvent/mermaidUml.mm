sequenceDiagram
participant Caller
participant PaymentService
participant Logger

Caller->>PaymentService: processPayment(order) : Response
activate PaymentService
PaymentService->>Logger: logger.info("Amount: " + order.getAmount()) : void
activate Logger
deactivate Logger
alt order.getAmount() < 1000
PaymentService->>Caller: return Response.ok().build();
else
PaymentService->>Caller: return Response.status(401).build();
end
deactivate PaymentService
