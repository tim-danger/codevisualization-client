sequenceDiagram
participant Caller
participant Person

Caller->>Person: equals(object) : boolean
activate Person
alt !(object instanceof Person)
Person->>Caller: return false;
end
Person->>Person: Person other = (Person) object
Person->>Caller: return (this.id != null || other.id == null) && (this.id == null || this.id.equals(other.id));
deactivate Person
