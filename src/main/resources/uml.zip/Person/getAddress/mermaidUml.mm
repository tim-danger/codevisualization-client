sequenceDiagram
participant Caller
participant Person

Caller->>Person: getAddress() : String
activate Person
Person->>Caller: return address;
deactivate Person
