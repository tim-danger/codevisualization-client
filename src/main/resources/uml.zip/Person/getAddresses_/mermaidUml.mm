sequenceDiagram
participant Caller
participant Person

Caller->>Person: getAddresses() : List<Address>
activate Person
Person->>Caller: return addresses;
deactivate Person
