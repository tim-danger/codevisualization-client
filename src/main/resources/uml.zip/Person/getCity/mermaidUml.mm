sequenceDiagram
participant Caller
participant Person

Caller->>Person: getCity() : String
activate Person
Person->>Caller: return city;
deactivate Person
