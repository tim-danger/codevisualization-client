sequenceDiagram
participant Caller
participant Person

Caller->>Person: getDetails() : PersonDetails
activate Person
Person->>Caller: return details;
deactivate Person
