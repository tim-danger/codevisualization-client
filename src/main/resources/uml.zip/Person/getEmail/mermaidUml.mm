sequenceDiagram
participant Caller
participant Person

Caller->>Person: getEmail() : String
activate Person
Person->>Caller: return email;
deactivate Person
