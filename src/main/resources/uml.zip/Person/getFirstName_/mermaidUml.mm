sequenceDiagram
participant Caller
participant Person

Caller->>Person: getFirstName() : String
activate Person
Person->>Caller: return firstName;
deactivate Person
