sequenceDiagram
participant Caller
participant Person

Caller->>Person: getFirstname() : String
activate Person
Person->>Caller: return firstname;
deactivate Person
