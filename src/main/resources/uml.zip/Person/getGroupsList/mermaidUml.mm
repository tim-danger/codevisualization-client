sequenceDiagram
participant Caller
participant Person

Caller->>Person: getGroupsList() : List<Groups>
activate Person
Person->>Caller: return groupsList;
deactivate Person
