sequenceDiagram
participant Caller
participant Person

Caller->>Person: getHomePhone() : String
activate Person
Person->>Caller: return homePhone;
deactivate Person
