sequenceDiagram
participant Caller
participant Person

Caller->>Person: getId() : Integer
activate Person
Person->>Caller: return id;
deactivate Person
