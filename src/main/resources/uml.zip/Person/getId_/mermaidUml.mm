sequenceDiagram
participant Caller
participant Person

Caller->>Person: getId() : Long
activate Person
Person->>Caller: return id;
deactivate Person
