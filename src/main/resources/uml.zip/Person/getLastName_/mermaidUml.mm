sequenceDiagram
participant Caller
participant Person

Caller->>Person: getLastName() : String
activate Person
Person->>Caller: return lastName;
deactivate Person
