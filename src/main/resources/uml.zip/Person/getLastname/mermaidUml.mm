sequenceDiagram
participant Caller
participant Person

Caller->>Person: getLastname() : String
activate Person
Person->>Caller: return lastname;
deactivate Person
