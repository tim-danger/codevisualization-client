sequenceDiagram
participant Caller
participant Person

Caller->>Person: getMiddleName() : String
activate Person
Person->>Caller: return middleName;
deactivate Person
