sequenceDiagram
participant Caller
participant Person

Caller->>Person: getMobilePhone() : String
activate Person
Person->>Caller: return mobilePhone;
deactivate Person
