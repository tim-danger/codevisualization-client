sequenceDiagram
participant Caller
participant Person

Caller->>Person: getName() : String
activate Person
alt null == this.nickname || nickname.length() < 1
Person->>Caller: return this.getFirstName() + " " + this.getLastName();
else
Person->>Caller: return this.getNickname() + " " + this.getLastName();
end
deactivate Person
