sequenceDiagram
participant Caller
participant Person

Caller->>Person: getNickname() : String
activate Person
Person->>Caller: return nickname;
deactivate Person
