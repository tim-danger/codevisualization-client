sequenceDiagram
participant Caller
participant Person

Caller->>Person: getPassword() : String
activate Person
Person->>Caller: return password;
deactivate Person
