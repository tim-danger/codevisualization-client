sequenceDiagram
participant Caller
participant Person

Caller->>Person: getSuffix() : String
activate Person
Person->>Caller: return suffix;
deactivate Person
