sequenceDiagram
participant Caller
participant Person

Caller->>Person: hashCode() : int
activate Person
Person->>Person: int hash = 0
Person->>Person: hash += (id != null ? id.hashCode() : 0)
Person->>Caller: return hash;
deactivate Person
