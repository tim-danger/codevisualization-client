sequenceDiagram
participant Caller
participant Person

Caller->>Person: setAddress(address) : void
activate Person
Person->>Person: this.address = address
deactivate Person
