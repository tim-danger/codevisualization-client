sequenceDiagram
participant Caller
participant Person

Caller->>Person: setAddresses(addresses) : void
activate Person
Person->>Person: this.addresses = addresses
deactivate Person
