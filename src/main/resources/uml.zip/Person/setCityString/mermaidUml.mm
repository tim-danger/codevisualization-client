sequenceDiagram
participant Caller
participant Person

Caller->>Person: setCity(city) : void
activate Person
Person->>Person: this.city = city
deactivate Person
