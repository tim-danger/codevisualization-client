sequenceDiagram
participant Caller
participant Person

Caller->>Person: setDetails(details) : void
activate Person
Person->>Person: this.details = details
deactivate Person
