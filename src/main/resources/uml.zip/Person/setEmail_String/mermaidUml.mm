sequenceDiagram
participant Caller
participant Person

Caller->>Person: setEmail(email) : void
activate Person
Person->>Person: this.email = email
deactivate Person
