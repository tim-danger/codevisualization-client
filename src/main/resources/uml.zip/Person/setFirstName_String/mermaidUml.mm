sequenceDiagram
participant Caller
participant Person

Caller->>Person: setFirstName(firstName) : void
activate Person
Person->>Person: this.firstName = firstName
deactivate Person
