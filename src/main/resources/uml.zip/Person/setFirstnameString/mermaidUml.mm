sequenceDiagram
participant Caller
participant Person

Caller->>Person: setFirstname(firstname) : void
activate Person
Person->>Person: this.firstname = firstname
deactivate Person
