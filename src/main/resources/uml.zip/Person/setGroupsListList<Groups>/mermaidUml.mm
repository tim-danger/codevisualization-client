sequenceDiagram
participant Caller
participant Person

Caller->>Person: setGroupsList(groupsList) : void
activate Person
Person->>Person: this.groupsList = groupsList
deactivate Person
