sequenceDiagram
participant Caller
participant Person

Caller->>Person: setHomePhone(homePhone) : void
activate Person
Person->>Person: this.homePhone = homePhone
deactivate Person
