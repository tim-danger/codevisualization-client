sequenceDiagram
participant Caller
participant Person

Caller->>Person: setId(id) : void
activate Person
Person->>Person: this.id = id
deactivate Person
