sequenceDiagram
participant Caller
participant Person

Caller->>Person: setLastName(lastName) : void
activate Person
Person->>Person: this.lastName = lastName
deactivate Person
