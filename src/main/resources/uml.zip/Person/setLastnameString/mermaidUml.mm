sequenceDiagram
participant Caller
participant Person

Caller->>Person: setLastname(lastname) : void
activate Person
Person->>Person: this.lastname = lastname
deactivate Person
