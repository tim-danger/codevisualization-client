sequenceDiagram
participant Caller
participant Person

Caller->>Person: setMiddleName(middleName) : void
activate Person
Person->>Person: this.middleName = middleName
deactivate Person
