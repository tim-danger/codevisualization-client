sequenceDiagram
participant Caller
participant Person

Caller->>Person: setMobilePhone(mobilePhone) : void
activate Person
Person->>Person: this.mobilePhone = mobilePhone
deactivate Person
