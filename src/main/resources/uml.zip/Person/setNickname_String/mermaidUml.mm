sequenceDiagram
participant Caller
participant Person

Caller->>Person: setNickname(nickname) : void
activate Person
Person->>Person: this.nickname = nickname
deactivate Person
