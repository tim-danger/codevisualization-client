sequenceDiagram
participant Caller
participant Person

Caller->>Person: setPassword(password) : void
activate Person
Person->>Person: this.password = password
deactivate Person
