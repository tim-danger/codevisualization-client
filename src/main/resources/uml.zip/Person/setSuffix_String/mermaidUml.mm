sequenceDiagram
participant Caller
participant Person

Caller->>Person: setSuffix(suffix) : void
activate Person
Person->>Person: this.suffix = suffix
deactivate Person
