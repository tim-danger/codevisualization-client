sequenceDiagram
participant Caller
participant Person

Caller->>Person: toString() : String
activate Person
Person->>Caller: return "com.forest.entity.Person[ id=" + id + " ]";
deactivate Person
