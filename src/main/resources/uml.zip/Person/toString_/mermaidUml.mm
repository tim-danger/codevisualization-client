sequenceDiagram
participant Caller
participant Person

Caller->>Person: toString() : String
activate Person
Person->>Caller: return "dukestutoring.entity.Person[id=" + id + "]";
deactivate Person
