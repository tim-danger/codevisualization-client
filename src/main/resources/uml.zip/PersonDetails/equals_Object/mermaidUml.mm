sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: equals(object) : boolean
activate PersonDetails
alt !(object instanceof PersonDetails)
PersonDetails->>Caller: return false;
end
PersonDetails->>PersonDetails: PersonDetails other = (PersonDetails) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
PersonDetails->>Caller: return false;
end
PersonDetails->>Caller: return true;
deactivate PersonDetails
