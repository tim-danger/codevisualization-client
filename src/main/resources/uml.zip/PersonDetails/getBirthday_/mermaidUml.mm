sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: getBirthday() : Date
activate PersonDetails
PersonDetails->>Caller: return birthday;
deactivate PersonDetails
