sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: getId() : Long
activate PersonDetails
PersonDetails->>Caller: return id;
deactivate PersonDetails
