sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: getPerson() : Person
activate PersonDetails
PersonDetails->>Caller: return person;
deactivate PersonDetails
