sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: getPhoto() : byte[]
activate PersonDetails
PersonDetails->>Caller: return photo;
deactivate PersonDetails
