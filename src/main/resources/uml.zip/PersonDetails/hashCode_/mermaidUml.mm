sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: hashCode() : int
activate PersonDetails
PersonDetails->>PersonDetails: int hash = 0
PersonDetails->>PersonDetails: hash += (id != null ? id.hashCode() : 0)
PersonDetails->>Caller: return hash;
deactivate PersonDetails
