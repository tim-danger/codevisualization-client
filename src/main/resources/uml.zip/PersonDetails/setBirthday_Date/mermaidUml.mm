sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: setBirthday(birthday) : void
activate PersonDetails
PersonDetails->>PersonDetails: this.birthday = birthday
deactivate PersonDetails
