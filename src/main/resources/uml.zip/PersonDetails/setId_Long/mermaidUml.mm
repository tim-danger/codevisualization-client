sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: setId(id) : void
activate PersonDetails
PersonDetails->>PersonDetails: this.id = id
deactivate PersonDetails
