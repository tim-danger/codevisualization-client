sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: setPerson(person) : void
activate PersonDetails
PersonDetails->>PersonDetails: this.person = person
deactivate PersonDetails
