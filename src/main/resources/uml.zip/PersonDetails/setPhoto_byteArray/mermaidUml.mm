sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: setPhoto(photo) : void
activate PersonDetails
PersonDetails->>PersonDetails: this.photo = photo
deactivate PersonDetails
