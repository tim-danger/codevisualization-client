sequenceDiagram
participant Caller
participant PersonDetails

Caller->>PersonDetails: toString() : String
activate PersonDetails
PersonDetails->>Caller: return "dukestutoring.entity.PersonDetails[id=" + id + "]";
deactivate PersonDetails
