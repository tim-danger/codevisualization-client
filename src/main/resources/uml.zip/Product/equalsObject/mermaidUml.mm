sequenceDiagram
participant Caller
participant Product

Caller->>Product: equals(object) : boolean
activate Product
alt !(object instanceof Product)
Product->>Caller: return false;
end
Product->>Product: Product other = (Product) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Product->>Caller: return false;
end
Product->>Caller: return true;
deactivate Product
