sequenceDiagram
participant Caller
participant Product

Caller->>Product: getCategory() : Category
activate Product
Product->>Caller: return category;
deactivate Product
