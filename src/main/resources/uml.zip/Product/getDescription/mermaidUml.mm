sequenceDiagram
participant Caller
participant Product

Caller->>Product: getDescription() : String
activate Product
Product->>Caller: return description;
deactivate Product
