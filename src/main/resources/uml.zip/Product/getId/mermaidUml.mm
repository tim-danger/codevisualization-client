sequenceDiagram
participant Caller
participant Product

Caller->>Product: getId() : Integer
activate Product
Product->>Caller: return id;
deactivate Product
