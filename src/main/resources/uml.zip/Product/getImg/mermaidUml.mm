sequenceDiagram
participant Caller
participant Product

Caller->>Product: getImg() : String
activate Product
Product->>Caller: return img;
deactivate Product
