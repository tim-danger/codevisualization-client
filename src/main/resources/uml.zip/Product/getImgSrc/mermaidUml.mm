sequenceDiagram
participant Caller
participant Product

Caller->>Product: getImgSrc() : byte[]
activate Product
Product->>Caller: return imgSrc;
deactivate Product
