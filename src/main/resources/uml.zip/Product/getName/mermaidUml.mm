sequenceDiagram
participant Caller
participant Product

Caller->>Product: getName() : String
activate Product
Product->>Caller: return name;
deactivate Product
