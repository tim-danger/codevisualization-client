sequenceDiagram
participant Caller
participant Product

Caller->>Product: getPrice() : double
activate Product
Product->>Caller: return price;
deactivate Product
