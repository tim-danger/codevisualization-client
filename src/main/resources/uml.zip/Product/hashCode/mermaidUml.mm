sequenceDiagram
participant Caller
participant Product

Caller->>Product: hashCode() : int
activate Product
Product->>Product: int hash = 0
Product->>Product: hash += (id != null ? id.hashCode() : 0)
Product->>Caller: return hash;
deactivate Product
