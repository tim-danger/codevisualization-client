sequenceDiagram
participant Caller
participant Product

Caller->>Product: setCategory(category) : void
activate Product
Product->>Product: this.category = category
deactivate Product
