sequenceDiagram
participant Caller
participant Product

Caller->>Product: setId(id) : void
activate Product
Product->>Product: this.id = id
deactivate Product
