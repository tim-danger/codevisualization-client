sequenceDiagram
participant Caller
participant Product

Caller->>Product: setImgSrc(imgSrc) : void
activate Product
Product->>Product: this.imgSrc = imgSrc
deactivate Product
