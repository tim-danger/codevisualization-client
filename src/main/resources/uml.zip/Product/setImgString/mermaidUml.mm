sequenceDiagram
participant Caller
participant Product

Caller->>Product: setImg(simg) : void
activate Product
Product->>Product: this.img = simg
deactivate Product
