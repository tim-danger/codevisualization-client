sequenceDiagram
participant Caller
participant Product

Caller->>Product: setName(name) : void
activate Product
Product->>Product: this.name = name
deactivate Product
