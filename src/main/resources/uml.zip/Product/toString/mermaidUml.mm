sequenceDiagram
participant Caller
participant Product

Caller->>Product: toString() : String
activate Product
Product->>Caller: return "com.forest.entity.Product[id=" + id + "]";
deactivate Product
