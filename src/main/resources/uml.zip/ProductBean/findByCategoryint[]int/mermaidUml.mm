sequenceDiagram
participant Caller
participant ProductBean
participant Category
participant EntityManager
participant CriteriaBuilder
participant CriteriaQuery
participant Logger

Caller->>ProductBean: findByCategory(range, categoryId) : List<Product>
activate ProductBean
ProductBean->>Category: cat = new Category() : Category
activate Category
Category->>ProductBean: cat
deactivate Category
ProductBean->>Category: cat.setId(categoryId) : void
activate Category
Category->>Category: this.id = id
deactivate Category
ProductBean->>EntityManager: qb = em.getCriteriaBuilder() : CriteriaBuilder
activate EntityManager
EntityManager->>ProductBean: qb
deactivate EntityManager
ProductBean->>CriteriaBuilder: query = qb.createQuery(Product.class) : CriteriaQuery<Product>
activate CriteriaBuilder
CriteriaBuilder->>ProductBean: query
deactivate CriteriaBuilder
ProductBean->>CriteriaQuery: product = query.from(Product.class) : Root<Product>
activate CriteriaQuery
CriteriaQuery->>ProductBean: product
deactivate CriteriaQuery
ProductBean->>CriteriaQuery: query.where(qb.equal(product.get("category"), cat)) : void
activate CriteriaQuery
deactivate CriteriaQuery
ProductBean->>ProductBean: result = this.findRange(range, query) : List<Product>
activate ProductBean
ProductBean->>ProductBean: result
deactivate ProductBean
ProductBean->>Logger: logger.log(Level.FINEST, "Product List size: {0}", result.size()) : void
activate Logger
deactivate Logger
ProductBean->>Caller: return result;
deactivate ProductBean
