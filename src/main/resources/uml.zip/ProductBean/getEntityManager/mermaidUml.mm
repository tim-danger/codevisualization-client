sequenceDiagram
participant Caller
participant ProductBean

Caller->>ProductBean: getEntityManager() : EntityManager
activate ProductBean
ProductBean->>Caller: return em;
deactivate ProductBean
