sequenceDiagram
participant Caller
participant ProductController
participant JsfUtil
participant FacesMessage
participant FacesContext
participant Exception
participant AbstractPaginationHelper

Caller->>ProductController: destroyAndView() : PageNavigation
activate ProductController
ProductController->>ProductController: performDestroy() : void
activate ProductController
opt try
ProductController->>ProductController: getFacade().remove(current) : void
activate ProductController
deactivate ProductController
ProductController->>JsfUtil: JsfUtil.addSuccessMessage(ResourceBundle.getBundle(BUNDLE).getString("ProductDeleted")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception e
ProductController->>JsfUtil: JsfUtil.addErrorMessage(e, ResourceBundle.getBundle(BUNDLE).getString("PersistenceErrorOccured")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
end
end
deactivate ProductController
ProductController->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
ProductController->>ProductController: updateCurrentItem() : void
activate ProductController
ProductController->>ProductController: count = getFacade().count() : int
activate ProductController
ProductController->>ProductController: count
deactivate ProductController
alt selectedItemIndex >= count
ProductController->>ProductController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
ProductController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
ProductController->>ProductController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate ProductController
ProductController->>ProductController: current
deactivate ProductController
end
deactivate ProductController
alt selectedItemIndex >= 0
ProductController->>Caller: return PageNavigation.VIEW;
else
ProductController->>ProductController: recreateModel() : void
activate ProductController
deactivate ProductController
ProductController->>Caller: return PageNavigation.LIST;
end
deactivate ProductController
