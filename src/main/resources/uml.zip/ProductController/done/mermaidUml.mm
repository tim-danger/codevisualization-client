sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: done() : PageNavigation
activate ProductController
ProductController->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
ProductController->>ProductController: setStep(1) : void
activate ProductController
ProductController->>ProductController: this.step = step
deactivate ProductController
ProductController->>ProductController: current = null
ProductController->>Caller: return PageNavigation.INDEX;
deactivate ProductController
