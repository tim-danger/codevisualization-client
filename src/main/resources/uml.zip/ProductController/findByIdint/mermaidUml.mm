sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: findById(id) : Product
activate ProductController
ProductController->>Caller: return ejbFacade.find(id);
deactivate ProductController
