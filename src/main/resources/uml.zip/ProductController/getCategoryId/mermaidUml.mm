sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getCategoryId() : int
activate ProductController
ProductController->>Caller: return categoryId;
deactivate ProductController
