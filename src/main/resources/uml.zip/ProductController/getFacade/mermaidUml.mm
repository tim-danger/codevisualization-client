sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getFacade() : ProductBean
activate ProductController
ProductController->>Caller: return ejbFacade;
deactivate ProductController
