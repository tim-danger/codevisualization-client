sequenceDiagram
participant Caller
participant ProductController
participant Part
participant Logger

Caller->>ProductController: getFileName(part) : String
activate ProductController
ProductController->>Part: partHeader = part.getHeader("content-disposition") : String
activate Part
Part->>ProductController: partHeader
deactivate Part
ProductController->>Logger: logger.log(Level.INFO, "Part Header = {0}", partHeader) : void
activate Logger
deactivate Logger
loop for String cd : part.getHeader("content-disposition").split(",")
alt cd.trim().startsWith("filename")
ProductController->>ProductController: return cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
end
end
ProductController->>Caller: return null;
deactivate ProductController
