sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getFilePart() : Part
activate ProductController
ProductController->>Caller: return filePart;
deactivate ProductController
