sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getItems() : DataModel
activate ProductController
alt items == null
ProductController->>ProductController: items = getPagination().createPageDataModel() : DataModel
activate ProductController
ProductController->>ProductController: items
deactivate ProductController
end
ProductController->>Caller: return items;
deactivate ProductController
