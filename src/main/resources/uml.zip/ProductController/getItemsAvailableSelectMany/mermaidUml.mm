sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getItemsAvailableSelectMany() : SelectItem[]
activate ProductController
ProductController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), false);
deactivate ProductController
