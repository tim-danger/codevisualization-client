sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getItemsAvailableSelectOne() : SelectItem[]
activate ProductController
ProductController->>Caller: return JsfUtil.getSelectItems(ejbFacade.findAll(), true);
deactivate ProductController
