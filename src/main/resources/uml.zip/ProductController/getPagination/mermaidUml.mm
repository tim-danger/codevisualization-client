sequenceDiagram
participant Caller
participant ProductController
participant AbstractPaginationHelper

Caller->>ProductController: getPagination() : AbstractPaginationHelper
activate ProductController
alt pagination == null
ProductController->>AbstractPaginationHelper: pagination = new AbstractPaginationHelper(AbstractPaginationHelper.DEFAULT_SIZE) {      @Override     public int getItemsCount() {         return getFacade().count();     }      @Override     public DataModel createPageDataModel() {         if (categoryId != 0) {             return new ListDataModel(getFacade().findByCategory(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }, categoryId));         }         return new ListDataModel(getFacade().findRange(new int[] { getPageFirstItem(), getPageFirstItem() + getPageSize() }));     } } : AbstractPaginationHelper
activate AbstractPaginationHelper
AbstractPaginationHelper->>ProductController: pagination
deactivate AbstractPaginationHelper
end
ProductController->>Caller: return pagination;
deactivate ProductController
