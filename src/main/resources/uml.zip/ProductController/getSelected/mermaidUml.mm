sequenceDiagram
participant Caller
participant ProductController
participant Product

Caller->>ProductController: getSelected() : Product
activate ProductController
alt current == null
ProductController->>Product: current = new Product() : Product
activate Product
Product->>ProductController: current
deactivate Product
ProductController->>ProductController: selectedItemIndex = -1
end
ProductController->>Caller: return current;
deactivate ProductController
