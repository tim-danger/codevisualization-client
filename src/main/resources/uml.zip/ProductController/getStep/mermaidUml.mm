sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: getStep() : int
activate ProductController
ProductController->>Caller: return step;
deactivate ProductController
