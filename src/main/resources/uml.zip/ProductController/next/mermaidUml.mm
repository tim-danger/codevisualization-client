sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: next() : PageNavigation
activate ProductController
ProductController->>ProductController: getPagination().nextPage() : void
activate ProductController
deactivate ProductController
ProductController->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
ProductController->>Caller: return PageNavigation.LIST;
deactivate ProductController
