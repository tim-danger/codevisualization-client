sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: nextStep() : PageNavigation
activate ProductController
ProductController->>ProductController: setStep(getStep() + 1) : void
activate ProductController
ProductController->>ProductController: this.step = step
deactivate ProductController
ProductController->>Caller: return PageNavigation.CREATE;
deactivate ProductController
