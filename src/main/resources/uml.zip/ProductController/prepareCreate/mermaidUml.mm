sequenceDiagram
participant Caller
participant ProductController
participant Product

Caller->>ProductController: prepareCreate() : PageNavigation
activate ProductController
ProductController->>Product: current = new Product() : Product
activate Product
Product->>ProductController: current
deactivate Product
ProductController->>ProductController: selectedItemIndex = -1
ProductController->>ProductController: setStep(1) : void
activate ProductController
ProductController->>ProductController: this.step = step
deactivate ProductController
ProductController->>Caller: return PageNavigation.CREATE;
deactivate ProductController
