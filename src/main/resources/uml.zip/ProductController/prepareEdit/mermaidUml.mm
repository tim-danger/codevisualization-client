sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: prepareEdit() : PageNavigation
activate ProductController
ProductController->>ProductController: current = (Product) getItems().getRowData()
ProductController->>ProductController: selectedItemIndex = pagination.getPageFirstItem() + getItems().getRowIndex()
ProductController->>Caller: return PageNavigation.EDIT;
deactivate ProductController
