sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: prepareList() : PageNavigation
activate ProductController
ProductController->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
ProductController->>Caller: return PageNavigation.LIST;
deactivate ProductController
