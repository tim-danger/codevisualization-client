sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
