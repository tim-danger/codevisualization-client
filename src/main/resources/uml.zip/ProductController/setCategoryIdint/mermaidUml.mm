sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: setCategoryId(categoryId) : void
activate ProductController
ProductController->>ProductController: this.categoryId = categoryId
deactivate ProductController
