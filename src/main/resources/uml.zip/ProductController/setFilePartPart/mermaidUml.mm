sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: setFilePart(filePart) : void
activate ProductController
ProductController->>ProductController: this.filePart = filePart
deactivate ProductController
