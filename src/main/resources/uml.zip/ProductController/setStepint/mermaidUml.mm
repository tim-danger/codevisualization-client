sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: setStep(step) : void
activate ProductController
ProductController->>ProductController: this.step = step
deactivate ProductController
