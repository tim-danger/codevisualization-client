sequenceDiagram
participant Caller
participant ProductController

Caller->>ProductController: showAll() : String
activate ProductController
ProductController->>ProductController: recreateModel() : void
activate ProductController
ProductController->>ProductController: items = null
deactivate ProductController
ProductController->>ProductController: categoryId = 0
ProductController->>Caller: return "product/List";
deactivate ProductController
