sequenceDiagram
participant Caller
participant ProductController
participant AbstractPaginationHelper

Caller->>ProductController: updateCurrentItem() : void
activate ProductController
ProductController->>ProductController: count = getFacade().count() : int
activate ProductController
ProductController->>ProductController: count
deactivate ProductController
alt selectedItemIndex >= count
ProductController->>ProductController: selectedItemIndex = count - 1
alt pagination.getPageFirstItem() >= count
ProductController->>AbstractPaginationHelper: pagination.previousPage() : void
activate AbstractPaginationHelper
alt isHasPreviousPage()
AbstractPaginationHelper->>AbstractPaginationHelper: page--
end
deactivate AbstractPaginationHelper
end
end
alt selectedItemIndex >= 0
ProductController->>ProductController: current = getFacade().findRange(new int[] { selectedItemIndex, selectedItemIndex + 1 }).get(0) : Administrator
activate ProductController
ProductController->>ProductController: current
deactivate ProductController
end
deactivate ProductController
