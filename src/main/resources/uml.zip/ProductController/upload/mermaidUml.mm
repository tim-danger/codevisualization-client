sequenceDiagram
participant Caller
participant ProductController
participant Logger
participant InputStream
participant Part
participant String
participant JsfUtil
participant Exception
participant FacesMessage
participant FacesContext
participant Administrator
participant com.forest.ejb.AdministratorBean

Caller->>ProductController: upload() : void
activate ProductController
ProductController->>Logger: logger.info(getFilePart().getName()) : void
activate Logger
deactivate Logger
opt try
ProductController->>ProductController: is = getFilePart().getInputStream() : InputStream
activate ProductController
ProductController->>ProductController: is
deactivate ProductController
ProductController->>InputStream: i = is.available() : int
activate InputStream
InputStream->>ProductController: i
deactivate InputStream
ProductController->>ProductController: byte[] b = new byte[i]
ProductController->>InputStream: is.read(b) : void
activate InputStream
deactivate InputStream
ProductController->>Logger: logger.log(Level.INFO, "Length : {0}", b.length) : void
activate Logger
deactivate Logger
ProductController->>ProductController: fileName = getFileName(getFilePart()) : String
activate ProductController
ProductController->>Part: partHeader = part.getHeader("content-disposition") : String
activate Part
Part->>ProductController: partHeader
deactivate Part
ProductController->>Logger: logger.log(Level.INFO, "Part Header = {0}", partHeader) : void
activate Logger
deactivate Logger
loop for String cd : part.getHeader("content-disposition").split(",")
alt cd.trim().startsWith("filename")
ProductController->>ProductController: return cd.substring(cd.indexOf('=') + 1).trim().replace("\"", "");
end
end
ProductController->>ProductController: return null;
ProductController->>ProductController: fileName
deactivate ProductController
ProductController->>Logger: logger.log(Level.INFO, "File name : {0}", fileName) : void
activate Logger
deactivate Logger
ProductController->>String: extension = fileName.substring(fileName.length() - 4) : String
activate String
String->>ProductController: extension
deactivate String
alt !EXTENSIONS_ALLOWED.contains(extension)
ProductController->>Logger: logger.severe("User tried to upload file that's not an image. Upload canceled.") : void
activate Logger
deactivate Logger
ProductController->>JsfUtil: JsfUtil.addErrorMessage(new Exception("Error trying to upload file"), ResourceBundle.getBundle(BUNDLE).getString("Error trying to upload file")) : void
activate JsfUtil
JsfUtil->>Exception: msg = ex.getLocalizedMessage() : String
activate Exception
Exception->>JsfUtil: msg
deactivate Exception
alt msg != null && msg.length() > 0
JsfUtil->>JsfUtil: addErrorMessage(msg) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
JsfUtil->>JsfUtil: addErrorMessage(defaultMsg) : void
activate JsfUtil
deactivate JsfUtil
end
deactivate JsfUtil
ProductController->>ProductController: return;
end
ProductController->>Administrator: current.setImgSrc(b) : void
activate Administrator
deactivate Administrator
ProductController->>Administrator: current.setImg(fileName) : void
activate Administrator
deactivate Administrator
ProductController->>com.forest.ejb.AdministratorBean: ejbFacade.edit(current) : void
activate com.forest.ejb.AdministratorBean
deactivate com.forest.ejb.AdministratorBean
ProductController->>ProductController: setStep(3) : void
activate ProductController
ProductController->>ProductController: this.step = step
deactivate ProductController
ProductController->>JsfUtil: JsfUtil.addSuccessMessage("Product image successfuly uploaded!") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch Exception ex
end
end
deactivate ProductController
