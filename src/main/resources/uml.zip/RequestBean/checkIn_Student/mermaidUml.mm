sequenceDiagram
participant Caller
participant RequestBean
participant Logger
participant Calendar
participant CalendarUtil
participant SimpleDateFormat
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager
participant TypedQuery
participant TutoringSession
participant Root
participant Student
participant ArrayList
participant List
participant Event
participant StatusEntry

Caller->>RequestBean: checkIn(student) : String
activate RequestBean
RequestBean->>RequestBean: String result
alt student == null
RequestBean->>Logger: logger.warning("Student is null!") : void
activate Logger
deactivate Logger
RequestBean->>RequestBean: result = "failedToCheckIn"
else
RequestBean->>RequestBean: tutoringSession = this.getTodaysSession() : TutoringSession
activate RequestBean
RequestBean->>Calendar: today = Calendar.getInstance() : Calendar
activate Calendar
Calendar->>RequestBean: today
deactivate Calendar
RequestBean->>CalendarUtil: CalendarUtil.stripTime(today) : void
activate CalendarUtil
CalendarUtil->>Calendar: cal.clear(Calendar.AM_PM) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR_OF_DAY) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.HOUR) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MINUTE) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.SECOND) : void
activate Calendar
deactivate Calendar
CalendarUtil->>Calendar: cal.clear(Calendar.MILLISECOND) : void
activate Calendar
deactivate Calendar
deactivate CalendarUtil
RequestBean->>SimpleDateFormat: formatter = new SimpleDateFormat("E, MMM d, yyyy") : SimpleDateFormat
activate SimpleDateFormat
SimpleDateFormat->>RequestBean: formatter
deactivate SimpleDateFormat
RequestBean->>Logger: logger.log(Level.INFO, "Finding tutoring session for {0}", formatter.format(today.getTime())) : void
activate Logger
deactivate Logger
RequestBean->>CriteriaBuilder: cq = cb.createQuery(TutoringSession.class) : CriteriaQuery<TutoringSession>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: tutoringSession = cq.from(TutoringSession.class) : Root<TutoringSession>
activate CriteriaQuery
CriteriaQuery->>RequestBean: tutoringSession
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(tutoringSession) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(tutoringSession.get(TutoringSession_.sessionDate), today)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<TutoringSession>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>RequestBean: TutoringSession session
opt try
RequestBean->>TypedQuery: session = q.getSingleResult() : TutoringSession
activate TypedQuery
TypedQuery->>RequestBean: session
deactivate TypedQuery
RequestBean->>Logger: logger.info("Found session for today.") : void
activate Logger
deactivate Logger
opt catch NoResultException e
RequestBean->>Logger: logger.info("Today's session not found. Creating a new session.") : void
activate Logger
deactivate Logger
RequestBean->>TutoringSession: session = new TutoringSession() : TutoringSession
activate TutoringSession
TutoringSession->>RequestBean: session
deactivate TutoringSession
RequestBean->>EntityManager: em.persist(session) : void
activate EntityManager
deactivate EntityManager
end
end
RequestBean->>RequestBean: return session;
RequestBean->>RequestBean: tutoringSession
deactivate RequestBean
RequestBean->>Root: students = tutoringSession.getStudents() : List<Student>
activate Root
Root->>RequestBean: students
deactivate Root
alt !students.contains(student)
RequestBean->>Logger: logger.info("Adding student to session.") : void
activate Logger
deactivate Logger
RequestBean->>Root: tutoringSession.getStudents().add(student) : void
activate Root
deactivate Root
RequestBean->>Logger: logger.info("Adding today's tutoring session to student.") : void
activate Logger
deactivate Logger
RequestBean->>Student: sessions = student.getSessions() : List<TutoringSession>
activate Student
Student->>Student: return sessions;
Student->>RequestBean: sessions
deactivate Student
alt sessions.isEmpty()
RequestBean->>Logger: logger.info("Student's sessions list is empty.") : void
activate Logger
deactivate Logger
RequestBean->>ArrayList: sessions = new ArrayList<>() : ArrayList<>
activate ArrayList
ArrayList->>RequestBean: sessions
deactivate ArrayList
end
RequestBean->>List: sessions.add(tutoringSession) : void
activate List
deactivate List
end
RequestBean->>Logger: logger.log(Level.INFO, "Setting {0}''s status to IN", student.getFirstName()) : void
activate Logger
deactivate Logger
RequestBean->>Student: student.setStatus(StatusType.IN) : void
activate Student
Student->>Student: this.status = status
deactivate Student
RequestBean->>Event: statusEvent.fire(new StatusEvent(student)) : void
activate Event
deactivate Event
RequestBean->>Logger: logger.info("Creating a new status entry") : void
activate Logger
deactivate Logger
RequestBean->>StatusEntry: entry = new StatusEntry(StatusType.IN, student, tutoringSession) : StatusEntry
activate StatusEntry
StatusEntry->>RequestBean: entry
deactivate StatusEntry
RequestBean->>Logger: logger.info("Adding status entry to tutoring session") : void
activate Logger
deactivate Logger
RequestBean->>Root: tutoringSession.getStatusEntries().add(entry) : void
activate Root
deactivate Root
RequestBean->>Logger: logger.info("Persisting status entry") : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.persist(entry) : void
activate EntityManager
deactivate EntityManager
RequestBean->>Logger: logger.log(Level.INFO, "Merging status change to {0}", student.getFirstName()) : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.merge(student) : void
activate EntityManager
deactivate EntityManager
RequestBean->>Logger: logger.info("Merging the status entry to tutoring session") : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.merge(tutoringSession) : void
activate EntityManager
deactivate EntityManager
RequestBean->>RequestBean: result = "checkinSucceeded"
end
RequestBean->>Caller: return result;
deactivate RequestBean
