sequenceDiagram
participant Caller
participant RequestBean
participant TutoringSession
participant SimpleDateFormat
participant Logger
participant EntityManager

Caller->>RequestBean: createTutoringSession() : void
activate RequestBean
opt try
RequestBean->>TutoringSession: todaysSession = new TutoringSession() : TutoringSession
activate TutoringSession
TutoringSession->>RequestBean: todaysSession
deactivate TutoringSession
RequestBean->>SimpleDateFormat: formatter = new SimpleDateFormat("E, MMM d, yyyy") : SimpleDateFormat
activate SimpleDateFormat
SimpleDateFormat->>RequestBean: formatter
deactivate SimpleDateFormat
RequestBean->>Logger: logger.log(Level.INFO, "Creating new tutoring session for {0}.", formatter.format(todaysSession.getSessionDate().getTime())) : void
activate Logger
deactivate Logger
RequestBean->>EntityManager: em.persist(todaysSession) : void
activate EntityManager
deactivate EntityManager
opt catch Exception e
RequestBean->>Logger: logger.warning("Couldn't create a new session!") : void
activate Logger
deactivate Logger
end
end
deactivate RequestBean
