sequenceDiagram
participant Caller
participant RequestBean
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager
participant TypedQuery
participant Logger

Caller->>RequestBean: getAllTutoringSessions() : List<TutoringSession>
activate RequestBean
RequestBean->>CriteriaBuilder: cq = cb.createQuery(TutoringSession.class) : CriteriaQuery<TutoringSession>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: session = cq.from(TutoringSession.class) : Root<TutoringSession>
activate CriteriaQuery
CriteriaQuery->>RequestBean: session
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(session) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<TutoringSession>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>TypedQuery: sessions = q.getResultList() : List<TutoringSession>
activate TypedQuery
TypedQuery->>RequestBean: sessions
deactivate TypedQuery
RequestBean->>Logger: logger.log(Level.INFO, "Total number of sessions: {0}", sessions.size()) : void
activate Logger
deactivate Logger
RequestBean->>Caller: return sessions;
deactivate RequestBean
