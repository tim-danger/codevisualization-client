sequenceDiagram
participant Caller
participant RequestBean

Caller->>RequestBean: getCheckedInStudents() : List<Student>
activate RequestBean
RequestBean->>Caller: return this.getStudentsByStatus(StatusType.IN);
deactivate RequestBean
