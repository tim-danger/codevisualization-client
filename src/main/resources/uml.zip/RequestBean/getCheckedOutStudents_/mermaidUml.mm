sequenceDiagram
participant Caller
participant RequestBean

Caller->>RequestBean: getCheckedOutStudents() : List<Student>
activate RequestBean
RequestBean->>Caller: return this.getStudentsByStatus(StatusType.OUT);
deactivate RequestBean
