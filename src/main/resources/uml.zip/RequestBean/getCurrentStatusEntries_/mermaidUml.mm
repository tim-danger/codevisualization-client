sequenceDiagram
participant Caller
participant RequestBean
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager

Caller->>RequestBean: getCurrentStatusEntries() : List<StatusEntry>
activate RequestBean
RequestBean->>CriteriaBuilder: cq = cb.createQuery(StatusEntry.class) : CriteriaQuery<StatusEntry>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: statusEntry = cq.from(StatusEntry.class) : Root<StatusEntry>
activate CriteriaQuery
CriteriaQuery->>RequestBean: statusEntry
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(statusEntry) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(statusEntry.get(StatusEntry_.tutoringSession), this.getTodaysSession())) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<StatusEntry>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>Caller: return q.getResultList();
deactivate RequestBean
