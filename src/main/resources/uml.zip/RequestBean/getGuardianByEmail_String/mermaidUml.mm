sequenceDiagram
participant Caller
participant RequestBean
participant Logger
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager

Caller->>RequestBean: getGuardianByEmail(email) : Guardian
activate RequestBean
RequestBean->>Logger: logger.log(Level.INFO, "Principal is: {0}", ctx.getCallerPrincipal().getName()) : void
activate Logger
deactivate Logger
RequestBean->>CriteriaBuilder: cq = cb.createQuery(Guardian.class) : CriteriaQuery<Guardian>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: guardian = cq.from(Guardian.class) : Root<Guardian>
activate CriteriaQuery
CriteriaQuery->>RequestBean: guardian
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(guardian) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(guardian.get(Guardian_.email), email)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Guardian>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>Caller: return q.getSingleResult();
deactivate RequestBean
