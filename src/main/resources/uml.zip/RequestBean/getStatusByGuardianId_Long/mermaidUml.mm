sequenceDiagram
participant Caller
participant RequestBean
participant Logger
participant CriteriaBuilder
participant CriteriaQuery
participant Root
participant EntityManager

Caller->>RequestBean: getStatusByGuardianId(id) : List<Student>
activate RequestBean
RequestBean->>Logger: logger.log(Level.INFO, "Principal is: {0}", ctx.getCallerPrincipal().getName()) : void
activate Logger
deactivate Logger
RequestBean->>CriteriaBuilder: cq = cb.createQuery(Student.class) : CriteriaQuery<Student>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>RequestBean: student
deactivate CriteriaQuery
RequestBean->>Root: guardian = student.join(Student_.guardians) : Join<Student,Guardian>
activate Root
Root->>RequestBean: guardian
deactivate Root
RequestBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(guardian.get(Guardian_.id), id)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>Caller: return q.getResultList();
deactivate RequestBean
