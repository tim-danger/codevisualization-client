sequenceDiagram
participant Caller
participant RequestBean
participant EntityManager
participant CriteriaQuery

Caller->>RequestBean: getStudentByName(lastName, firstName) : Student
activate RequestBean
RequestBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Student.class) : CriteriaQuery<Student>
activate EntityManager
EntityManager->>RequestBean: cq
deactivate EntityManager
RequestBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>RequestBean: student
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(student.get(Student_.lastName), lastName)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(student.get(Student_.firstName), firstName)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>Caller: return q.getSingleResult();
deactivate RequestBean
