sequenceDiagram
participant Caller
participant RequestBean

Caller->>RequestBean: getStudentsAtPark() : List<Student>
activate RequestBean
RequestBean->>Caller: return this.getStudentsByStatus(StatusType.PARK);
deactivate RequestBean
