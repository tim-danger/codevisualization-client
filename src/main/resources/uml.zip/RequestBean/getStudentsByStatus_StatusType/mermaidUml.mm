sequenceDiagram
participant Caller
participant RequestBean
participant CriteriaBuilder
participant CriteriaQuery
participant EntityManager

Caller->>RequestBean: getStudentsByStatus(statusType) : List<Student>
activate RequestBean
RequestBean->>CriteriaBuilder: cq = cb.createQuery(Student.class) : CriteriaQuery<Student>
activate CriteriaBuilder
CriteriaBuilder->>RequestBean: cq
deactivate CriteriaBuilder
RequestBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>RequestBean: student
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.equal(student.get(Student_.status), statusType)) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>Caller: return q.getResultList();
deactivate RequestBean
