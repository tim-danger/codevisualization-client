sequenceDiagram
participant Caller
participant RequestBean
participant EntityManager

Caller->>RequestBean: init() : void
activate RequestBean
RequestBean->>EntityManager: cb = em.getCriteriaBuilder() : CriteriaBuilder
activate EntityManager
EntityManager->>RequestBean: cb
deactivate EntityManager
deactivate RequestBean
