sequenceDiagram
participant Caller
participant ShippingBean
participant Client

Caller->>ShippingBean: clean() : void
activate ShippingBean
ShippingBean->>Client: client.close() : void
activate Client
deactivate Client
deactivate ShippingBean
