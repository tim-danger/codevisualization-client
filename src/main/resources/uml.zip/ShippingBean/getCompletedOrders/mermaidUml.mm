sequenceDiagram
participant Caller
participant ShippingBean

Caller->>ShippingBean: getCompletedOrders() : List<CustomerOrder>
activate ShippingBean
ShippingBean->>Caller: return listByStatus(Status.SHIPPED);
deactivate ShippingBean
