sequenceDiagram
participant Caller
participant ShippingBean

Caller->>ShippingBean: getEndpoint() : String
activate ShippingBean
ShippingBean->>Caller: return SERVICE_ENDPOINT;
deactivate ShippingBean
