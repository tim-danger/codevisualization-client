sequenceDiagram
participant Caller
participant ShippingBean

Caller->>ShippingBean: getOrders() : Map<String,CustomerOrder>
activate ShippingBean
ShippingBean->>Caller: return orders;
deactivate ShippingBean
