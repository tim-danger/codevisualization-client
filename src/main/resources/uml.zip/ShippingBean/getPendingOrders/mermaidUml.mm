sequenceDiagram
participant Caller
participant ShippingBean
participant OrderBrowser
participant JMSContext
participant QueueBrowser
participant Logger
participant Map
participant Message

Caller->>ShippingBean: getPendingOrders() : List<String>
activate ShippingBean
ShippingBean->>OrderBrowser: pendingOrders = orderBrowser.getOrders() : Map<String,CustomerOrder>
activate OrderBrowser
OrderBrowser->>JMSContext: browser = context.createBrowser(queue) : QueueBrowser
activate JMSContext
JMSContext->>OrderBrowser: browser
deactivate JMSContext
OrderBrowser->>OrderBrowser: Enumeration msgs
opt try
OrderBrowser->>QueueBrowser: msgs = browser.getEnumeration() : Enumeration
activate QueueBrowser
QueueBrowser->>OrderBrowser: msgs
deactivate QueueBrowser
alt !msgs.hasMoreElements()
OrderBrowser->>Logger: logger.log(Level.INFO, "No messages on the queue!") : void
activate Logger
deactivate Logger
else
OrderBrowser->>Map: result = new LinkedHashMap<>() : Map<String,CustomerOrder>
activate Map
Map->>OrderBrowser: result
deactivate Map
loop while msgs.hasMoreElements()
OrderBrowser->>OrderBrowser: Message msg = (Message) msgs.nextElement()
OrderBrowser->>Logger: logger.log(Level.INFO, "Message ID: {0}", msg.getJMSMessageID()) : void
activate Logger
deactivate Logger
OrderBrowser->>Message: order = msg.getBody(CustomerOrder.class) : CustomerOrder
activate Message
Message->>OrderBrowser: order
deactivate Message
OrderBrowser->>Map: result.put(msg.getJMSMessageID(), order) : void
activate Map
deactivate Map
end
OrderBrowser->>OrderBrowser: return result;
end
opt catch JMSException ex
OrderBrowser->>Logger: Logger.getLogger(OrderBrowser.class.getName()).log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
end
end
OrderBrowser->>OrderBrowser: return null;
OrderBrowser->>ShippingBean: pendingOrders
deactivate OrderBrowser
alt pendingOrders == null
ShippingBean->>Caller: return null;
else
ShippingBean->>ShippingBean: setOrders(pendingOrders) : void
activate ShippingBean
ShippingBean->>ShippingBean: this.orders = orders
deactivate ShippingBean
ShippingBean->>Caller: return new ArrayList<>(getOrders().keySet());
end
deactivate ShippingBean
