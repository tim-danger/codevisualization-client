sequenceDiagram
participant Caller
participant ShippingBean
participant ClientBuilder

Caller->>ShippingBean: init() : void
activate ShippingBean
ShippingBean->>ClientBuilder: client = ClientBuilder.newClient() : Client
activate ClientBuilder
ClientBuilder->>ShippingBean: client
deactivate ClientBuilder
deactivate ShippingBean
