sequenceDiagram
participant Caller
participant ShippingBean

Caller->>ShippingBean: listByStatus(status) : List<CustomerOrder>
activate ShippingBean
ShippingBean->>ShippingBean: List<CustomerOrder> entity = (List<CustomerOrder>) client.target(SERVICE_ENDPOINT).queryParam("status", String.valueOf(status.getStatus())).request(MEDIA_TYPE).get(new GenericType<List<CustomerOrder>>() {
})
ShippingBean->>Caller: return entity;
deactivate ShippingBean
