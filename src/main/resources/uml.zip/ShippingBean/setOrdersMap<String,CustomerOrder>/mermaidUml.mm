sequenceDiagram
participant Caller
participant ShippingBean

Caller->>ShippingBean: setOrders(orders) : void
activate ShippingBean
ShippingBean->>ShippingBean: this.orders = orders
deactivate ShippingBean
