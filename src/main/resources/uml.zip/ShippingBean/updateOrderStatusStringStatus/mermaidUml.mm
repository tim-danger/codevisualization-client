sequenceDiagram
participant Caller
participant ShippingBean
participant OrderBrowser
participant Logger
participant JMSContext
participant JMSConsumer
participant Client

Caller->>ShippingBean: updateOrderStatus(messageID, status) : void
activate ShippingBean
ShippingBean->>OrderBrowser: order = orderBrowser.processOrder(messageID) : CustomerOrder
activate OrderBrowser
OrderBrowser->>Logger: logger.log(Level.INFO, "Processing Order {0}", OrderMessageID) : void
activate Logger
deactivate Logger
OrderBrowser->>JMSContext: consumer = context.createConsumer(queue, "JMSMessageID='" + OrderMessageID + "'") : JMSConsumer
activate JMSContext
JMSContext->>OrderBrowser: consumer
deactivate JMSContext
OrderBrowser->>JMSConsumer: order = consumer.receiveBody(CustomerOrder.class, 1) : CustomerOrder
activate JMSConsumer
JMSConsumer->>OrderBrowser: order
deactivate JMSConsumer
OrderBrowser->>OrderBrowser: return order;
OrderBrowser->>ShippingBean: order
deactivate OrderBrowser
ShippingBean->>Client: response = client.target(SERVICE_ENDPOINT).path("/" + order.getId()).request(MEDIA_TYPE).put(Entity.text(String.valueOf(status.getStatus()))) : Response
activate Client
Client->>ShippingBean: response
deactivate Client
ShippingBean->>Logger: logger.log(Level.FINEST, "PUT Status response: {0}", response.getStatus()) : void
activate Logger
deactivate Logger
deactivate ShippingBean
