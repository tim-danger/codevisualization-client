sequenceDiagram
participant Caller
participant ShoppingCart
participant ArrayList
participant Conversation
participant Logger
participant List

Caller->>ShoppingCart: addItem(p) : String
activate ShoppingCart
alt cartItems == null
ShoppingCart->>ArrayList: cartItems = new ArrayList<>() : ArrayList<>
activate ArrayList
ArrayList->>ShoppingCart: cartItems
deactivate ArrayList
alt conversation.isTransient()
ShoppingCart->>Conversation: conversation.begin() : void
activate Conversation
deactivate Conversation
end
end
ShoppingCart->>Logger: LOGGER.log(Level.FINEST, "Adding product {0}", p.getName()) : void
activate Logger
deactivate Logger
ShoppingCart->>Logger: LOGGER.log(Level.FINEST, "Cart Size: {0}", cartItems.size()) : void
activate Logger
deactivate Logger
alt !cartItems.contains(p)
ShoppingCart->>List: cartItems.add(p) : void
activate List
deactivate List
end
ShoppingCart->>Caller: return "";
deactivate ShoppingCart
