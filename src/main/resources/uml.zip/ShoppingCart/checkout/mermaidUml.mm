sequenceDiagram
participant Caller
participant ShoppingCart
participant JsfUtil
participant FacesMessage
participant FacesContext
participant CustomerOrder
participant List
participant OrderStatus
participant OrderBean
participant OrderDetail
participant OrderDetailPK
participant OrderEvent
participant Logger
participant EventDispatcherBean
participant Event

Caller->>ShoppingCart: checkout() : PageNavigation
activate ShoppingCart
alt user == null
ShoppingCart->>JsfUtil: JsfUtil.addErrorMessage(JsfUtil.getStringFromBundle("bundles.Bundle", "LoginBeforeCheckout")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
loop for Groups g : user.getGroupsList()
alt g.getName().equals("ADMINS")
ShoppingCart->>JsfUtil: JsfUtil.addErrorMessage(JsfUtil.getStringFromBundle("bundles.Bundle", "AdministratorNotAllowed")) : void
activate JsfUtil
deactivate JsfUtil
ShoppingCart->>ShoppingCart: return PageNavigation.INDEX;
end
end
ShoppingCart->>CustomerOrder: order = new CustomerOrder() : CustomerOrder
activate CustomerOrder
CustomerOrder->>ShoppingCart: order
deactivate CustomerOrder
ShoppingCart->>List: details = new ArrayList<>() : List<OrderDetail>
activate List
List->>ShoppingCart: details
deactivate List
ShoppingCart->>OrderStatus: orderStatus = new OrderStatus() : OrderStatus
activate OrderStatus
OrderStatus->>ShoppingCart: orderStatus
deactivate OrderStatus
ShoppingCart->>OrderStatus: orderStatus.setId(1) : void
activate OrderStatus
OrderStatus->>OrderStatus: this.id = id
deactivate OrderStatus
ShoppingCart->>CustomerOrder: order.setDateCreated(Calendar.getInstance().getTime()) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.dateCreated = dateCreated
deactivate CustomerOrder
ShoppingCart->>CustomerOrder: order.setOrderStatus(orderStatus) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderStatus = orderStatus
deactivate CustomerOrder
ShoppingCart->>CustomerOrder: order.setAmount(getTotal()) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.amount = amount
deactivate CustomerOrder
ShoppingCart->>CustomerOrder: order.setCustomer(user) : void
activate CustomerOrder
deactivate CustomerOrder
ShoppingCart->>OrderBean: facade.create(order) : void
activate OrderBean
deactivate OrderBean
loop for Product p : getCartItems()
ShoppingCart->>OrderDetail: detail = new OrderDetail() : OrderDetail
activate OrderDetail
OrderDetail->>ShoppingCart: detail
deactivate OrderDetail
ShoppingCart->>OrderDetailPK: pk = new OrderDetailPK(order.getId(), p.getId()) : OrderDetailPK
activate OrderDetailPK
OrderDetailPK->>ShoppingCart: pk
deactivate OrderDetailPK
ShoppingCart->>OrderDetail: detail.setQty(1) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.qty = qty
deactivate OrderDetail
ShoppingCart->>OrderDetail: detail.setProduct(p) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.product = product
deactivate OrderDetail
ShoppingCart->>OrderDetail: detail.setOrderDetailPK(pk) : void
activate OrderDetail
OrderDetail->>OrderDetail: this.orderDetailPK = orderDetailPK
deactivate OrderDetail
ShoppingCart->>List: details.add(detail) : void
activate List
deactivate List
end
ShoppingCart->>CustomerOrder: order.setOrderDetailList(details) : void
activate CustomerOrder
CustomerOrder->>CustomerOrder: this.orderDetailList = orderDetailList
deactivate CustomerOrder
ShoppingCart->>OrderBean: facade.edit(order) : void
activate OrderBean
deactivate OrderBean
ShoppingCart->>ShoppingCart: event = orderToEvent(order) : OrderEvent
activate ShoppingCart
ShoppingCart->>OrderEvent: event = new OrderEvent() : OrderEvent
activate OrderEvent
OrderEvent->>ShoppingCart: event
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setAmount(order.getAmount()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.amount = amount
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setCustomerID(order.getCustomer().getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.customerID = customerID
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setDateCreated(order.getDateCreated()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.dateCreated = dateCreated
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setStatusID(order.getOrderStatus().getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.statusID = statusID
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setOrderID(order.getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.orderID = orderID
deactivate OrderEvent
ShoppingCart->>ShoppingCart: return event;
ShoppingCart->>ShoppingCart: event
deactivate ShoppingCart
ShoppingCart->>Logger: LOGGER.log(Level.FINEST, "{0} Sending event from ShoppingCart", Thread.currentThread().getName()) : void
activate Logger
deactivate Logger
ShoppingCart->>EventDispatcherBean: eventDispatcher.publish(event) : void
activate EventDispatcherBean
EventDispatcherBean->>Logger: logger.log(Level.FINEST, "{0} Sending event from EJB", Thread.currentThread().getName()) : void
activate Logger
deactivate Logger
EventDispatcherBean->>Event: eventManager.fire(event) : void
activate Event
deactivate Event
deactivate EventDispatcherBean
ShoppingCart->>JsfUtil: JsfUtil.addSuccessMessage(JsfUtil.getStringFromBundle("bundles.Bundle", "Cart_Checkout_Success")) : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
ShoppingCart->>ShoppingCart: clear() : void
activate ShoppingCart
ShoppingCart->>List: cartItems.clear() : void
activate List
deactivate List
deactivate ShoppingCart
end
ShoppingCart->>Caller: return PageNavigation.INDEX;
deactivate ShoppingCart
