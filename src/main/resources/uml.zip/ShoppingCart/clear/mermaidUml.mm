sequenceDiagram
participant Caller
participant ShoppingCart
participant List

Caller->>ShoppingCart: clear() : void
activate ShoppingCart
ShoppingCart->>List: cartItems.clear() : void
activate List
deactivate List
deactivate ShoppingCart
