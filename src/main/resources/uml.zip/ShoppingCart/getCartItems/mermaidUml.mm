sequenceDiagram
participant Caller
participant ShoppingCart

Caller->>ShoppingCart: getCartItems() : List<Product>
activate ShoppingCart
ShoppingCart->>Caller: return cartItems;
deactivate ShoppingCart
