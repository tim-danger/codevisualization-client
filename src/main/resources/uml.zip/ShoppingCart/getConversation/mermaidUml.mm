sequenceDiagram
participant Caller
participant ShoppingCart

Caller->>ShoppingCart: getConversation() : Conversation
activate ShoppingCart
ShoppingCart->>Caller: return conversation;
deactivate ShoppingCart
