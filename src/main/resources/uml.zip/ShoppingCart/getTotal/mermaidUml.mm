sequenceDiagram
participant Caller
participant ShoppingCart
participant Product
participant Logger

Caller->>ShoppingCart: getTotal() : double
activate ShoppingCart
alt cartItems == null || cartItems.isEmpty()
ShoppingCart->>Caller: return 0f;
end
ShoppingCart->>ShoppingCart: double total = 0f
loop for Product item : cartItems
ShoppingCart->>Product: total += item.getPrice() : double
activate Product
Product->>Product: return price;
Product->>ShoppingCart: total
deactivate Product
end
ShoppingCart->>Logger: LOGGER.log(Level.FINEST, "Actual Total:{0}", total) : void
activate Logger
deactivate Logger
ShoppingCart->>Caller: return total;
deactivate ShoppingCart
