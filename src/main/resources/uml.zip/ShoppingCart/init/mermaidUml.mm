sequenceDiagram
participant Caller
participant ShoppingCart
participant ArrayList

Caller->>ShoppingCart: init() : void
activate ShoppingCart
ShoppingCart->>ArrayList: cartItems = new ArrayList<>() : ArrayList<>
activate ArrayList
ArrayList->>ShoppingCart: cartItems
deactivate ArrayList
deactivate ShoppingCart
