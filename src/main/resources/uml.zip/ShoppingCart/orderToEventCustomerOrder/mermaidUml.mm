sequenceDiagram
participant Caller
participant ShoppingCart
participant OrderEvent

Caller->>ShoppingCart: orderToEvent(order) : OrderEvent
activate ShoppingCart
ShoppingCart->>OrderEvent: event = new OrderEvent() : OrderEvent
activate OrderEvent
OrderEvent->>ShoppingCart: event
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setAmount(order.getAmount()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.amount = amount
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setCustomerID(order.getCustomer().getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.customerID = customerID
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setDateCreated(order.getDateCreated()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.dateCreated = dateCreated
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setStatusID(order.getOrderStatus().getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.statusID = statusID
deactivate OrderEvent
ShoppingCart->>OrderEvent: event.setOrderID(order.getId()) : void
activate OrderEvent
OrderEvent->>OrderEvent: this.orderID = orderID
deactivate OrderEvent
ShoppingCart->>Caller: return event;
deactivate ShoppingCart
