sequenceDiagram
participant Caller
participant ShoppingCart

Caller->>ShoppingCart: removeItem(p) : boolean
activate ShoppingCart
alt cartItems.contains(p)
ShoppingCart->>Caller: return cartItems.remove(p);
else
ShoppingCart->>Caller: return false;
end
deactivate ShoppingCart
