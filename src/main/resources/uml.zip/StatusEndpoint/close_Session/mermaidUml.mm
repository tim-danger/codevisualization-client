sequenceDiagram
participant Caller
participant StatusEndpoint
participant Set

Caller->>StatusEndpoint: close(session) : void
activate StatusEndpoint
StatusEndpoint->>Set: sessions.remove(session) : void
activate Set
deactivate Set
deactivate StatusEndpoint
