sequenceDiagram
participant Caller
participant StatusEndpoint
participant Set
participant RequestBean
participant EntityManager
participant CriteriaQuery
participant StringWriter
participant Json
participant JsonGenerator
participant Session
participant Logger

Caller->>StatusEndpoint: open(session) : void
activate StatusEndpoint
StatusEndpoint->>Set: sessions.add(session) : void
activate Set
deactivate Set
StatusEndpoint->>RequestBean: students = requestBean.getAllStudents() : List<Student>
activate RequestBean
RequestBean->>EntityManager: cq = em.getCriteriaBuilder().createQuery(Student.class) : CriteriaQuery<Student>
activate EntityManager
EntityManager->>RequestBean: cq
deactivate EntityManager
RequestBean->>CriteriaQuery: student = cq.from(Student.class) : Root<Student>
activate CriteriaQuery
CriteriaQuery->>RequestBean: student
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.select(student) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.where(cb.isTrue(student.get(Student_.active))) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>CriteriaQuery: cq.distinct(true) : void
activate CriteriaQuery
deactivate CriteriaQuery
RequestBean->>EntityManager: q = em.createQuery(cq) : TypedQuery<Student>
activate EntityManager
EntityManager->>RequestBean: q
deactivate EntityManager
RequestBean->>RequestBean: return q.getResultList();
RequestBean->>StatusEndpoint: students
deactivate RequestBean
StatusEndpoint->>StatusEndpoint: studentList = jsonStudentList(students) : String
activate StatusEndpoint
StatusEndpoint->>StringWriter: swriter = new StringWriter() : StringWriter
activate StringWriter
StringWriter->>StatusEndpoint: swriter
deactivate StringWriter
opt try
StatusEndpoint->>Json: gen = Json.createGenerator(swriter) : JsonGenerator
activate Json
Json->>StatusEndpoint: gen
deactivate Json
StatusEndpoint->>JsonGenerator: gen.writeStartObject() : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("type", "list") : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeStartArray("body") : void
activate JsonGenerator
deactivate JsonGenerator
loop for Student student : students
StatusEndpoint->>JsonGenerator: gen.writeStartObject() : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("name", student.getName()) : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("status", student.getStatus().toString()) : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeEnd() : void
activate JsonGenerator
deactivate JsonGenerator
end
StatusEndpoint->>JsonGenerator: gen.writeEnd() : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeEnd() : void
activate JsonGenerator
deactivate JsonGenerator
end
StatusEndpoint->>StatusEndpoint: return swriter.toString();
StatusEndpoint->>StatusEndpoint: studentList
deactivate StatusEndpoint
opt try
StatusEndpoint->>Session: session.getBasicRemote().sendText(studentList) : void
activate Session
deactivate Session
opt catch IOException e
StatusEndpoint->>Logger: log.log(Level.INFO, "[StatusEndpoint] {0}", e.getMessage()) : void
activate Logger
deactivate Logger
end
end
deactivate StatusEndpoint
