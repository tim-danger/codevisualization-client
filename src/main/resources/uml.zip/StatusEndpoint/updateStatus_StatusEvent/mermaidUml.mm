sequenceDiagram
participant Caller
participant StatusEndpoint
participant Logger
participant StringWriter
participant Json
participant JsonGenerator
participant Session

Caller->>StatusEndpoint: updateStatus(event) : void
activate StatusEndpoint
StatusEndpoint->>Logger: log.info("updateStatus") : void
activate Logger
deactivate Logger
loop for Session s : sessions
alt s.isOpen()
opt try
StatusEndpoint->>StatusEndpoint: studentUpdate = jsonStudentUpdate(event.getStudent()) : String
activate StatusEndpoint
StatusEndpoint->>StringWriter: swriter = new StringWriter() : StringWriter
activate StringWriter
StringWriter->>StatusEndpoint: swriter
deactivate StringWriter
opt try
StatusEndpoint->>Json: gen = Json.createGenerator(swriter) : JsonGenerator
activate Json
Json->>StatusEndpoint: gen
deactivate Json
StatusEndpoint->>JsonGenerator: gen.writeStartObject() : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("type", "update") : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeStartObject("body") : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("name", student.getName()) : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.write("status", student.getStatus().toString()) : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeEnd() : void
activate JsonGenerator
deactivate JsonGenerator
StatusEndpoint->>JsonGenerator: gen.writeEnd() : void
activate JsonGenerator
deactivate JsonGenerator
end
StatusEndpoint->>StatusEndpoint: return swriter.toString();
StatusEndpoint->>StatusEndpoint: studentUpdate
deactivate StatusEndpoint
StatusEndpoint->>Session: s.getBasicRemote().sendText(studentUpdate) : void
activate Session
deactivate Session
StatusEndpoint->>Logger: log.log(Level.INFO, "[StatusEndpoint] {0} is now {1}", new Object[] { event.getStudent().getName(), event.getStudent().getStatus() }) : void
activate Logger
deactivate Logger
opt catch IOException e
StatusEndpoint->>Logger: log.log(Level.INFO, "[StatusEndpoint] {0}", e.getMessage()) : void
activate Logger
deactivate Logger
end
end
end
end
deactivate StatusEndpoint
