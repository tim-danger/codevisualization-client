sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: equals(object) : boolean
activate StatusEntry
alt !(object instanceof StatusEntry)
StatusEntry->>Caller: return false;
end
StatusEntry->>StatusEntry: StatusEntry other = (StatusEntry) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
StatusEntry->>Caller: return false;
end
StatusEntry->>Caller: return true;
deactivate StatusEntry
