sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getCurrentStatusLabel() : String
activate StatusEntry
StatusEntry->>Caller: return currentStatus.toString();
deactivate StatusEntry
