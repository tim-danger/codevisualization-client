sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getCurrentStatus() : StatusType
activate StatusEntry
StatusEntry->>Caller: return currentStatus;
deactivate StatusEntry
