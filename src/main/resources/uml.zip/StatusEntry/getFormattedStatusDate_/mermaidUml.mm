sequenceDiagram
participant Caller
participant StatusEntry
participant SimpleDateFormat

Caller->>StatusEntry: getFormattedStatusDate() : String
activate StatusEntry
StatusEntry->>SimpleDateFormat: df = new SimpleDateFormat("EEE, d MMM yyyy HH:mm:ss z") : SimpleDateFormat
activate SimpleDateFormat
SimpleDateFormat->>StatusEntry: df
deactivate SimpleDateFormat
StatusEntry->>Caller: return df.format(this.statusDate.getTime());
deactivate StatusEntry
