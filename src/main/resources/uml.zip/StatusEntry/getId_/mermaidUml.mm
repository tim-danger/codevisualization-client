sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getId() : Long
activate StatusEntry
StatusEntry->>Caller: return id;
deactivate StatusEntry
