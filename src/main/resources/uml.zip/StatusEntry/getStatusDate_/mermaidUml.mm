sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getStatusDate() : Calendar
activate StatusEntry
StatusEntry->>Caller: return statusDate;
deactivate StatusEntry
