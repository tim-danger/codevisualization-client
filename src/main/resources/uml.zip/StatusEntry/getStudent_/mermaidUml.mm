sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getStudent() : Student
activate StatusEntry
StatusEntry->>Caller: return student;
deactivate StatusEntry
