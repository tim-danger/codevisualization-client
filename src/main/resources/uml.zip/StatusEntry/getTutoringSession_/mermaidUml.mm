sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: getTutoringSession() : TutoringSession
activate StatusEntry
StatusEntry->>Caller: return tutoringSession;
deactivate StatusEntry
