sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: hashCode() : int
activate StatusEntry
StatusEntry->>StatusEntry: int hash = 0
StatusEntry->>StatusEntry: hash += (id != null ? id.hashCode() : 0)
StatusEntry->>Caller: return hash;
deactivate StatusEntry
