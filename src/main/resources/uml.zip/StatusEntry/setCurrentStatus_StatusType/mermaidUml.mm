sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: setCurrentStatus(currentStatus) : void
activate StatusEntry
StatusEntry->>StatusEntry: this.currentStatus = currentStatus
deactivate StatusEntry
