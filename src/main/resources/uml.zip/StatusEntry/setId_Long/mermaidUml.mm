sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: setId(id) : void
activate StatusEntry
StatusEntry->>StatusEntry: this.id = id
deactivate StatusEntry
