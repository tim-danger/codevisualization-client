sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: setStatusDate(statusDate) : void
activate StatusEntry
StatusEntry->>StatusEntry: this.statusDate = statusDate
deactivate StatusEntry
