sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: setStudent(student) : void
activate StatusEntry
StatusEntry->>StatusEntry: this.student = student
deactivate StatusEntry
