sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: setTutoringSession(tutoringSession) : void
activate StatusEntry
StatusEntry->>StatusEntry: this.tutoringSession = tutoringSession
deactivate StatusEntry
