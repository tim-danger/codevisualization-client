sequenceDiagram
participant Caller
participant StatusEntry

Caller->>StatusEntry: toString() : String
activate StatusEntry
StatusEntry->>Caller: return "dukestutoring.entity.StatusEntry[id=" + id + "]";
deactivate StatusEntry
