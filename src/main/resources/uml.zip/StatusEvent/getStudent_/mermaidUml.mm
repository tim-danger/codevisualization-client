sequenceDiagram
participant Caller
participant StatusEvent

Caller->>StatusEvent: getStudent() : Student
activate StatusEvent
StatusEvent->>Caller: return student;
deactivate StatusEvent
