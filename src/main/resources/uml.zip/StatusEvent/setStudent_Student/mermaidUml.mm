sequenceDiagram
participant Caller
participant StatusEvent

Caller->>StatusEvent: setStudent(student) : void
activate StatusEvent
StatusEvent->>StatusEvent: this.student = student
deactivate StatusEvent
