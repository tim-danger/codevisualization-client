sequenceDiagram
participant Caller
participant StatusManager

Caller->>StatusManager: getLocalizedStatus(status) : String
activate StatusManager
StatusManager->>Caller: return status.toString(locale);
deactivate StatusManager
