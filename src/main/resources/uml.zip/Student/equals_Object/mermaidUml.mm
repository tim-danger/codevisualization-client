sequenceDiagram
participant Caller
participant Student

Caller->>Student: equals(object) : boolean
activate Student
alt !(object instanceof Student)
Student->>Caller: return false;
end
Student->>Student: Student other = (Student) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
Student->>Caller: return false;
end
Student->>Caller: return true;
deactivate Student
