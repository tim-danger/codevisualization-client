sequenceDiagram
participant Caller
participant Student

Caller->>Student: getGrade() : int
activate Student
Student->>Caller: return grade;
deactivate Student
