sequenceDiagram
participant Caller
participant Student

Caller->>Student: getGuardians() : List<Guardian>
activate Student
Student->>Caller: return guardians;
deactivate Student
