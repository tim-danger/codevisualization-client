sequenceDiagram
participant Caller
participant Student

Caller->>Student: getSchool() : String
activate Student
Student->>Caller: return school;
deactivate Student
