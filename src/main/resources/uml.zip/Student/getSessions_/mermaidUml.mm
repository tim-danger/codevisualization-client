sequenceDiagram
participant Caller
participant Student

Caller->>Student: getSessions() : List<TutoringSession>
activate Student
Student->>Caller: return sessions;
deactivate Student
