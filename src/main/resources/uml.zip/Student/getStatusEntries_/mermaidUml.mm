sequenceDiagram
participant Caller
participant Student

Caller->>Student: getStatusEntries() : List<StatusEntry>
activate Student
Student->>Caller: return statusEntries;
deactivate Student
