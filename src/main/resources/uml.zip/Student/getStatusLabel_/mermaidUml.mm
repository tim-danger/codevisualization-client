sequenceDiagram
participant Caller
participant Student

Caller->>Student: getStatusLabel() : String
activate Student
Student->>Caller: return this.status.toString();
deactivate Student
