sequenceDiagram
participant Caller
participant Student

Caller->>Student: getStatus() : StatusType
activate Student
Student->>Caller: return status;
deactivate Student
