sequenceDiagram
participant Caller
participant Student

Caller->>Student: hashCode() : int
activate Student
Student->>Student: int hash = 0
Student->>Student: hash += (id != null ? id.hashCode() : 0)
Student->>Caller: return hash;
deactivate Student
