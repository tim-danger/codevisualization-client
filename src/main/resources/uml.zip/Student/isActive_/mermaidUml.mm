sequenceDiagram
participant Caller
participant Student

Caller->>Student: isActive() : boolean
activate Student
Student->>Caller: return active;
deactivate Student
