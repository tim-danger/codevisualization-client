sequenceDiagram
participant Caller
participant Student

Caller->>Student: setActive(active) : void
activate Student
Student->>Student: this.active = active
deactivate Student
