sequenceDiagram
participant Caller
participant Student

Caller->>Student: setGrade(grade) : void
activate Student
Student->>Student: this.grade = grade
deactivate Student
