sequenceDiagram
participant Caller
participant Student

Caller->>Student: setGuardians(guardians) : void
activate Student
Student->>Student: this.guardians = guardians
deactivate Student
