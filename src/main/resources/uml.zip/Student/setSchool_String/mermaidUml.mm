sequenceDiagram
participant Caller
participant Student

Caller->>Student: setSchool(school) : void
activate Student
Student->>Student: this.school = school
deactivate Student
