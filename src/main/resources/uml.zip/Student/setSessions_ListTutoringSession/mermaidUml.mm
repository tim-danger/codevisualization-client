sequenceDiagram
participant Caller
participant Student

Caller->>Student: setSessions(sessions) : void
activate Student
Student->>Student: this.sessions = sessions
deactivate Student
