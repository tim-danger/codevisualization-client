sequenceDiagram
participant Caller
participant Student

Caller->>Student: setStatusEntries(statusEntries) : void
activate Student
Student->>Student: this.statusEntries = statusEntries
deactivate Student
