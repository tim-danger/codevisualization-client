sequenceDiagram
participant Caller
participant Student

Caller->>Student: setStatus(status) : void
activate Student
Student->>Student: this.status = status
deactivate Student
