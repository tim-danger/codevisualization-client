sequenceDiagram
participant Caller
participant Student

Caller->>Student: toString() : String
activate Student
Student->>Caller: return "dukestutoring.entity.Student[id=" + id + "]";
deactivate Student
