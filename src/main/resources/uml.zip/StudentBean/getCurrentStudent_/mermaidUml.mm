sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getCurrentStudent() : Student
activate StudentBean
StudentBean->>StudentBean: currentStudent = adminManager.currentStudent
StudentBean->>Caller: return currentStudent;
deactivate StudentBean
