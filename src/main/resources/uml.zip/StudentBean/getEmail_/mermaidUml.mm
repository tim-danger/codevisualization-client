sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getEmail() : String
activate StudentBean
StudentBean->>Caller: return email;
deactivate StudentBean
