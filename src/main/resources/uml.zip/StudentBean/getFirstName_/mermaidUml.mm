sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getFirstName() : String
activate StudentBean
StudentBean->>Caller: return firstName;
deactivate StudentBean
