sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getGrade() : int
activate StudentBean
StudentBean->>Caller: return grade;
deactivate StudentBean
