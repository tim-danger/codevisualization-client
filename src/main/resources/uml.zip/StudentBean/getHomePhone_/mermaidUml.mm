sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getHomePhone() : String
activate StudentBean
StudentBean->>Caller: return homePhone;
deactivate StudentBean
