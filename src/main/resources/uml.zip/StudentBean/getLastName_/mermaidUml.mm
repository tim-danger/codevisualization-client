sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getLastName() : String
activate StudentBean
StudentBean->>Caller: return lastName;
deactivate StudentBean
