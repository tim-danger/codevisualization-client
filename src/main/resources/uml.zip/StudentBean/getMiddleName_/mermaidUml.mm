sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getMiddleName() : String
activate StudentBean
StudentBean->>Caller: return middleName;
deactivate StudentBean
