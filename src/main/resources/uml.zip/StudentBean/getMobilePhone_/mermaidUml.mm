sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getMobilePhone() : String
activate StudentBean
StudentBean->>Caller: return mobilePhone;
deactivate StudentBean
