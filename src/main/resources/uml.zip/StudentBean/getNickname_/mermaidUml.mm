sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getNickname() : String
activate StudentBean
StudentBean->>Caller: return nickname;
deactivate StudentBean
