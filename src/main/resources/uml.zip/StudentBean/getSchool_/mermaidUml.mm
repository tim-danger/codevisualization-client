sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getSchool() : String
activate StudentBean
StudentBean->>Caller: return school;
deactivate StudentBean
