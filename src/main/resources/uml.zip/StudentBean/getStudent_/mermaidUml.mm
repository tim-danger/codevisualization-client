sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getStudent() : Student
activate StudentBean
StudentBean->>Caller: return student;
deactivate StudentBean
