sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: getSuffix() : String
activate StudentBean
StudentBean->>Caller: return suffix;
deactivate StudentBean
