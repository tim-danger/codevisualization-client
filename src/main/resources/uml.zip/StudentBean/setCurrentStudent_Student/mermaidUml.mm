sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setCurrentStudent(currentStudent) : void
activate StudentBean
StudentBean->>StudentBean: this.currentStudent = currentStudent
deactivate StudentBean
