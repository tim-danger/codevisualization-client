sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setEmail(email) : void
activate StudentBean
StudentBean->>StudentBean: this.email = email
deactivate StudentBean
