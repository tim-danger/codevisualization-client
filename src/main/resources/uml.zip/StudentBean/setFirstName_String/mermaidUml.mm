sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setFirstName(firstName) : void
activate StudentBean
StudentBean->>StudentBean: this.firstName = firstName
deactivate StudentBean
