sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setGrade(grade) : void
activate StudentBean
StudentBean->>StudentBean: this.grade = grade
deactivate StudentBean
