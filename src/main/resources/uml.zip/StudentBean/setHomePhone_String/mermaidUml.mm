sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setHomePhone(homePhone) : void
activate StudentBean
StudentBean->>StudentBean: this.homePhone = homePhone
deactivate StudentBean
