sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setLastName(lastName) : void
activate StudentBean
StudentBean->>StudentBean: this.lastName = lastName
deactivate StudentBean
