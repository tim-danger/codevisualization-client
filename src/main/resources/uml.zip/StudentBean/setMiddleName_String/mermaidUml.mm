sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setMiddleName(middleName) : void
activate StudentBean
StudentBean->>StudentBean: this.middleName = middleName
deactivate StudentBean
