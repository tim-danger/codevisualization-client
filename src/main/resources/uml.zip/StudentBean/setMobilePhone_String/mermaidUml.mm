sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setMobilePhone(mobilePhone) : void
activate StudentBean
StudentBean->>StudentBean: this.mobilePhone = mobilePhone
deactivate StudentBean
