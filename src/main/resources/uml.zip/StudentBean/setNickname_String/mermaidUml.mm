sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setNickname(nickname) : void
activate StudentBean
StudentBean->>StudentBean: this.nickname = nickname
deactivate StudentBean
