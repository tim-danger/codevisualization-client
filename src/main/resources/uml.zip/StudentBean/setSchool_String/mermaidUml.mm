sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setSchool(school) : void
activate StudentBean
StudentBean->>StudentBean: this.school = school
deactivate StudentBean
