sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setStudent(student) : void
activate StudentBean
StudentBean->>StudentBean: this.student = student
deactivate StudentBean
