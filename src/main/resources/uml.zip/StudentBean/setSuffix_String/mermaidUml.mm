sequenceDiagram
participant Caller
participant StudentBean

Caller->>StudentBean: setSuffix(suffix) : void
activate StudentBean
StudentBean->>StudentBean: this.suffix = suffix
deactivate StudentBean
