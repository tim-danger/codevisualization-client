sequenceDiagram
participant Caller
participant StudentBean
participant AdminBean
participant Logger
participant Student
participant EntityManager

Caller->>StudentBean: submit() : String
activate StudentBean
StudentBean->>AdminBean: this.student = adminBean.createStudent(firstName, middleName, lastName, nickname, suffix, school, grade, email, homePhone, mobilePhone)
activate AdminBean
AdminBean->>Logger: logger.log(Level.INFO, "AdminBean.createStudent(10 args): Persisting new student.") : void
activate Logger
deactivate Logger
AdminBean->>Student: student = new Student() : Student
activate Student
Student->>AdminBean: student
deactivate Student
AdminBean->>Student: student.setFirstName(firstName) : void
activate Student
deactivate Student
AdminBean->>Student: student.setMiddleName(middleName) : void
activate Student
deactivate Student
AdminBean->>Student: student.setLastName(lastName) : void
activate Student
deactivate Student
AdminBean->>Student: student.setNickname(nickname) : void
activate Student
deactivate Student
AdminBean->>Student: student.setSuffix(suffix) : void
activate Student
deactivate Student
AdminBean->>Student: student.setSchool(school) : void
activate Student
Student->>Student: this.school = school
deactivate Student
AdminBean->>Student: student.setGrade(grade) : void
activate Student
Student->>Student: this.grade = grade
deactivate Student
AdminBean->>Student: student.setEmail(email) : void
activate Student
deactivate Student
AdminBean->>Student: student.setHomePhone(homePhone) : void
activate Student
deactivate Student
AdminBean->>Student: student.setMobilePhone(mobilePhone) : void
activate Student
deactivate Student
AdminBean->>EntityManager: em.persist(student) : void
activate EntityManager
deactivate EntityManager
AdminBean->>AdminBean: return student;
AdminBean->>StudentBean: this.student
deactivate AdminBean
StudentBean->>Caller: return "createdStudent";
deactivate StudentBean
