sequenceDiagram
participant Caller
participant StudentConverter

Caller->>StudentConverter: getAsObject(context, component, value) : Object
activate StudentConverter
alt value.isEmpty()
StudentConverter->>Caller: return null;
end
StudentConverter->>Caller: return this.getViewMap(context).get(value);
deactivate StudentConverter
