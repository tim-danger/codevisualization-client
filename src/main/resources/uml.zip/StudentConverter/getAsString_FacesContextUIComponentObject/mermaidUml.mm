sequenceDiagram
participant Caller
participant StudentConverter
participant Student
participant String

Caller->>StudentConverter: getAsString(context, component, object) : String
activate StudentConverter
alt object == null
StudentConverter->>Caller: return "";
end
StudentConverter->>StudentConverter: Student student = (Student) object
StudentConverter->>Student: id = student.getId() : Long
activate Student
Student->>StudentConverter: id
deactivate Student
alt id != null
StudentConverter->>String: stringId = String.valueOf(id.longValue()) : String
activate String
String->>StudentConverter: stringId
deactivate String
StudentConverter->>StudentConverter: this.getViewMap(context).put(stringId, object) : void
activate StudentConverter
deactivate StudentConverter
StudentConverter->>Caller: return stringId;
else
StudentConverter->>Caller: return "0";
end
deactivate StudentConverter
