sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: equals(object) : boolean
activate TutoringSession
alt !(object instanceof TutoringSession)
TutoringSession->>Caller: return false;
end
TutoringSession->>TutoringSession: TutoringSession other = (TutoringSession) object
alt (this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))
TutoringSession->>Caller: return false;
end
TutoringSession->>Caller: return true;
deactivate TutoringSession
