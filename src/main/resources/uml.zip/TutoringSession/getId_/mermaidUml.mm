sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: getId() : Long
activate TutoringSession
TutoringSession->>Caller: return id;
deactivate TutoringSession
