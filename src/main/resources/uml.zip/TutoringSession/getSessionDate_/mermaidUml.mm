sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: getSessionDate() : Calendar
activate TutoringSession
TutoringSession->>Caller: return sessionDate;
deactivate TutoringSession
