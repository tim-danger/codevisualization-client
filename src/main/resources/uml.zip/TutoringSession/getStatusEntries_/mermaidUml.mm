sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: getStatusEntries() : List<StatusEntry>
activate TutoringSession
TutoringSession->>Caller: return statusEntries;
deactivate TutoringSession
