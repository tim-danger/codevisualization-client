sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: getStudents() : List<Student>
activate TutoringSession
TutoringSession->>Caller: return students;
deactivate TutoringSession
