sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: hashCode() : int
activate TutoringSession
TutoringSession->>TutoringSession: int hash = 0
TutoringSession->>TutoringSession: hash += (id != null ? id.hashCode() : 0)
TutoringSession->>Caller: return hash;
deactivate TutoringSession
