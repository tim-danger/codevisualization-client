sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: setId(id) : void
activate TutoringSession
TutoringSession->>TutoringSession: this.id = id
deactivate TutoringSession
