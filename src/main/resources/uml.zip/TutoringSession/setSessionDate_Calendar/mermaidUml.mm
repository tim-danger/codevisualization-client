sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: setSessionDate(sessionDate) : void
activate TutoringSession
TutoringSession->>TutoringSession: this.sessionDate = sessionDate
deactivate TutoringSession
