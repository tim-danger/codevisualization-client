sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: setStatusEntries(statusEntries) : void
activate TutoringSession
TutoringSession->>TutoringSession: this.statusEntries = statusEntries
deactivate TutoringSession
