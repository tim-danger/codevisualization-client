sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: setStudents(students) : void
activate TutoringSession
TutoringSession->>TutoringSession: this.setStudents(students) : void
activate TutoringSession
deactivate TutoringSession
deactivate TutoringSession
