sequenceDiagram
participant Caller
participant TutoringSession

Caller->>TutoringSession: toString() : String
activate TutoringSession
TutoringSession->>Caller: return "dukestutoring.entity.Session[id=" + id + "]";
deactivate TutoringSession
