sequenceDiagram
participant Caller
participant UserBean

Caller->>UserBean: createUser(customer) : boolean
activate UserBean
alt getUserByEmail(customer.getEmail()) == null
UserBean->>UserBean: super.create(customer) : void
activate UserBean
deactivate UserBean
UserBean->>Caller: return true;
else
UserBean->>Caller: return false;
end
deactivate UserBean
