sequenceDiagram
participant Caller
participant UserBean

Caller->>UserBean: getEntityManager() : EntityManager
activate UserBean
UserBean->>Caller: return em;
deactivate UserBean
