sequenceDiagram
participant Caller
participant UserBean
participant Query

Caller->>UserBean: getUserByEmail(email) : Person
activate UserBean
UserBean->>UserBean: createNamedQuery = getEntityManager().createNamedQuery("Person.findByEmail") : Query
activate UserBean
UserBean->>UserBean: createNamedQuery
deactivate UserBean
UserBean->>Query: createNamedQuery.setParameter("email", email) : void
activate Query
deactivate Query
alt createNamedQuery.getResultList().size() > 0
UserBean->>Caller: return (Person) createNamedQuery.getSingleResult();
else
UserBean->>Caller: return null;
end
deactivate UserBean
