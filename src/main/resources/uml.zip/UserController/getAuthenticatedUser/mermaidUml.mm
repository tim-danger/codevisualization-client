sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: getAuthenticatedUser() : Person
activate UserController
UserController->>Caller: return user;
deactivate UserController
