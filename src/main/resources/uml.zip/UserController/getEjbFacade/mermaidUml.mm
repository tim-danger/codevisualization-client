sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: getEjbFacade() : UserBean
activate UserController
UserController->>Caller: return ejbFacade;
deactivate UserController
