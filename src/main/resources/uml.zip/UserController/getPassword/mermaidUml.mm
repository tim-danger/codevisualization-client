sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: getPassword() : String
activate UserController
UserController->>Caller: return password;
deactivate UserController
