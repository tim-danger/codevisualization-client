sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: getUser() : Person
activate UserController
UserController->>Caller: return user;
deactivate UserController
