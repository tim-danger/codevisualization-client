sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: getUsername() : String
activate UserController
UserController->>Caller: return username;
deactivate UserController
