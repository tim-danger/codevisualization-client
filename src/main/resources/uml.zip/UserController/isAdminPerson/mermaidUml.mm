sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: isAdmin(user) : boolean
activate UserController
loop for Groups g : user.getGroupsList()
alt g.getName().equals("ADMINS")
UserController->>UserController: return true;
end
end
UserController->>Caller: return false;
deactivate UserController
