sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: isLogged() : boolean
activate UserController
UserController->>Caller: return getUser() == null ? false : true;
deactivate UserController
