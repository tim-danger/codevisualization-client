sequenceDiagram
participant Caller
participant UserController
participant FacesContext
participant HttpServletRequest
participant com.forest.ejb.AdministratorBean
participant JsfUtil
participant FacesMessage
participant Logger

Caller->>UserController: login() : String
activate UserController
UserController->>FacesContext: context = FacesContext.getCurrentInstance() : FacesContext
activate FacesContext
FacesContext->>UserController: context
deactivate FacesContext
UserController->>UserController: HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest()
UserController->>UserController: String result
opt try
UserController->>HttpServletRequest: request.login(this.getUsername(), this.getPassword()) : void
activate HttpServletRequest
deactivate HttpServletRequest
UserController->>com.forest.ejb.AdministratorBean: this.user = ejbFacade.getUserByEmail(getUsername())
activate com.forest.ejb.AdministratorBean
com.forest.ejb.AdministratorBean->>UserController: this.user
deactivate com.forest.ejb.AdministratorBean
UserController->>UserController: this.getAuthenticatedUser() : void
activate UserController
UserController->>UserController: return user;
deactivate UserController
alt isAdmin(user)
UserController->>UserController: result = "/admin/index"
UserController->>JsfUtil: JsfUtil.addSuccessMessage("Login Success! Welcome back!") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
else
UserController->>JsfUtil: JsfUtil.addErrorMessage("You're not a system administrator and cannot access this page.") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
UserController->>UserController: result = this.logout() : String
activate UserController
UserController->>FacesContext: context = FacesContext.getCurrentInstance() : FacesContext
activate FacesContext
FacesContext->>UserController: context
deactivate FacesContext
UserController->>UserController: HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest()
opt try
UserController->>UserController: this.user = null
UserController->>UserController: ((HttpSession) context.getExternalContext().getSession(false)).invalidate() : void
activate UserController
deactivate UserController
UserController->>HttpServletRequest: request.logout() : void
activate HttpServletRequest
deactivate HttpServletRequest
UserController->>JsfUtil: JsfUtil.addSuccessMessage("User successfully logged out! ") : void
activate JsfUtil
deactivate JsfUtil
opt catch ServletException ex
UserController->>Logger: Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
UserController->>JsfUtil: JsfUtil.addErrorMessage("Critical error during logout process.") : void
activate JsfUtil
deactivate JsfUtil
end
end
UserController->>UserController: return "/index";
UserController->>UserController: result
deactivate UserController
end
opt catch ServletException ex
UserController->>Logger: Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
UserController->>JsfUtil: JsfUtil.addErrorMessage("Invalid user or password. Login invalid!") : void
activate JsfUtil
deactivate JsfUtil
UserController->>UserController: result = "/login"
end
end
UserController->>Caller: return result;
deactivate UserController
