sequenceDiagram
participant Caller
participant UserController
participant FacesContext
participant HttpServletRequest
participant JsfUtil
participant FacesMessage
participant Logger

Caller->>UserController: logout() : String
activate UserController
UserController->>FacesContext: context = FacesContext.getCurrentInstance() : FacesContext
activate FacesContext
FacesContext->>UserController: context
deactivate FacesContext
UserController->>UserController: HttpServletRequest request = (HttpServletRequest) context.getExternalContext().getRequest()
opt try
UserController->>UserController: this.user = null
UserController->>UserController: ((HttpSession) context.getExternalContext().getSession(false)).invalidate() : void
activate UserController
deactivate UserController
UserController->>HttpServletRequest: request.logout() : void
activate HttpServletRequest
deactivate HttpServletRequest
UserController->>JsfUtil: JsfUtil.addSuccessMessage("User successfully logged out! ") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_INFO, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage("successInfo", facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
opt catch ServletException ex
UserController->>Logger: Logger.getLogger(UserController.class.getName()).log(Level.SEVERE, null, ex) : void
activate Logger
deactivate Logger
UserController->>JsfUtil: JsfUtil.addErrorMessage("Critical error during logout process.") : void
activate JsfUtil
JsfUtil->>FacesMessage: facesMsg = new FacesMessage(FacesMessage.SEVERITY_ERROR, msg, msg) : FacesMessage
activate FacesMessage
FacesMessage->>JsfUtil: facesMsg
deactivate FacesMessage
JsfUtil->>FacesContext: FacesContext.getCurrentInstance().addMessage(null, facesMsg) : void
activate FacesContext
deactivate FacesContext
deactivate JsfUtil
end
end
UserController->>Caller: return "/index";
deactivate UserController
