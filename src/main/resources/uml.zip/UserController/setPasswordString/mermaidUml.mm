sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: setPassword(password) : void
activate UserController
UserController->>UserController: this.password = password
deactivate UserController
