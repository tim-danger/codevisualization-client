sequenceDiagram
participant Caller
participant UserController

Caller->>UserController: setUsername(username) : void
activate UserController
UserController->>UserController: this.username = username
deactivate UserController
